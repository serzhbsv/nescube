//	========================================================================
//	Nescube Startup Demo Class by Dr.Lion/RSM
//	========================================================================
import javax.microedition.lcdui.game.GameCanvas;
import javax.microedition.lcdui.*;

public class demo extends GameCanvas implements Runnable {
//	========================================================================
//	Class Variables
//	========================================================================
	private boolean key_pressed = false;
    private Image img = null;
    private nescube parent;
    private	Thread thread;
	private Graphics g;
//	========================================================================
//	Class Constructor
//	========================================================================
	public demo(nescube parent){
		super(false); this.parent = parent;
		g = getGraphics(); setFullScreenMode(true);
        try { 
            img = Image.createImage("/resource/images/nescube.png");
            if(img.getHeight() > getHeight()) img = null;
		} catch (Exception e) {}
	}
//	========================================================================
//	Main Tread Control
//	========================================================================
	protected final void hideNotify(){ thread = null; }
	protected final void showNotify(){ thread = new Thread(this); thread.start(); }
//	========================================================================
//	Main Tread
//	========================================================================
	public final void run(){
        g.setColor(0x000000);
		g.fillRect(0, 0, getWidth(), getHeight());
        g.translate(getWidth() / 2,  getHeight() / 2);
        boolean flash = false;
        while(!key_pressed) {
            if(img == null) {
                g.translate(-getWidth() / 2, -getHeight() / 2);
                g.setColor(0); g.fillRect(0, 0, getWidth(), getHeight());
                g.translate(getWidth() / 2,  getHeight() / 2);
                draw_string("NESCUBE", -40, 1);
                draw_string("NES emulator for J2ME", +40, 2);
            } else g.drawImage(img, 0, 0, g.VCENTER + g.HCENTER);
            if(flash = !flash) draw_string("press any key", 0, 0);
			flushGraphics();
            try  { Thread.currentThread().sleep(500L); }
            catch( InterruptedException e ){ }
        }
        parent.returnFromDemo();
    }
//	======================================================================== 
    private void draw_string(String text, int y_offset, int font_style) {
        switch(font_style) {
            case 0: g.setFont(Font.getFont(Font.FACE_MONOSPACE, Font.STYLE_PLAIN, Font.SIZE_MEDIUM)); break;
            case 1: g.setFont(Font.getFont(Font.FACE_MONOSPACE, Font.STYLE_BOLD, Font.SIZE_LARGE)); break;
            case 2: g.setFont(Font.getFont(Font.FACE_MONOSPACE, Font.STYLE_PLAIN, Font.SIZE_SMALL));
        }
        g.setColor(0x666666); g.drawString(text, 1, 1 + y_offset, g.BASELINE + g.HCENTER);
        g.setColor(0xFFFFFF); g.drawString(text, 0, 0 + y_offset, g.BASELINE + g.HCENTER);
    }
//	======================================================================== 
    protected final void keyPressed(int keyCode) { key_pressed = true; }
}