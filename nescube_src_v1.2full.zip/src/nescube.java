//	============================================================================
//	Nescube v1.1 beta [05.12.2006] nes gui class by Dr. Lion/RSM
//	============================================================================
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import java.lang.Runtime.*;
import java.io.*;

public class nescube extends MIDlet implements CommandListener {
//	============================================================================
//	[+]	NES GUI Class Variables
//	============================================================================
	private List  OpenGame, MainMenu, Settings, AboutInf;
	private Form  FrmDispl, FrmContr, FrmEngin, FrmSound, FrmOther, FrmAbout;
	private Alert AlertMsg;
	private ChoiceGroup  choisegroupitem;
	private TextField textfield;
	private Gauge gauge;
//	----------------------------------------------------------------------------	
	private Display display;   
	private engine nes;
	private boolean emu_config;
	private Displayable temp_disp = null;
//	============================================================================
//	[+]	NES GUI Class Constants
//	============================================================================
	private final String PHONE_KEYS[] = {
		"Joystick [UP]", "Joystick [DOWN]", "Joystick [LEFT]", "Joystick [RIGHT]", "Joystick [PRESS]", "Key [*]", "Key [#]",
        "Key [0]", "Key [1]", "Key [2]", "Key [3]", "Key [4]", "Key [5]", "Key [6]", "Key [7]", "Key [8]", "Key [9]",
        "Key [C] (Clear)", "Special gaming key A", "Special gaming key B", "Volume+ (Zoom+) key", "Volume- (Zoom-) key"
	};
//	----------------------------------------------------------------------------
	private final String CONTROL[] = {
		"Not defined",
		"Right", "Left", "Down", "Up","Select",	"Start", "A (jump)", "B (fire)",
		"Switch camera", "Scale mode", "Rotate",
	};
//	----------------------------------------------------------------------------    
	private final String path_mainmenu = "/resource/icons/mainmenu";
	private final String path_settings = "/resource/icons/settings";
	private final String path_about = "/resource/icons/about";
	private final String path_other = "/resource/icons/other";
//	============================================================================
//	[+]	NES GUI commands for soft keys
//	============================================================================
	private Command minimize = new Command("Minimize", Command.SCREEN, 2);
	private Command sstate = new Command("Save state", Command.SCREEN, 2);
	private Command lstate = new Command("Load state", Command.SCREEN, 3);
	private Command config = new Command("Settings", Command.SCREEN, 1);
	private Command defaul = new Command("Default", Command.SCREEN, 1);
	private Command resume = new Command("Resume", Command.BACK, 1);
	private Command cancel = new Command("Cancel", Command.BACK, 1);
	private Command reset = new Command("Reset", Command.SCREEN, 4);
	private Command mmenu = new Command("Menu", Command.SCREEN, 5);
	private Command save = new Command("Save", Command.SCREEN, 1);
	private Command ok = new Command("OK", Command.SCREEN, 1);
//	============================================================================
//	[+]	NES GUI Class Constructor
//	============================================================================
	public nescube() {
		display = Display.getDisplay(this);
		nes = new engine(this);
		nes.addCommand(config);
		nes.addCommand(sstate);
		nes.addCommand(lstate);
		nes.addCommand(reset );
		nes.addCommand(mmenu );
		nes.setCommandListener(this);
        temp_disp = new demo(this);
	}
//	============================================================================
//	[+]	NES Emulator main access points
//	============================================================================
	public void startApp() {
		if(temp_disp == null) ShowMainMenu();
		else display.setCurrent(temp_disp);
	}
	public void pauseApp() {
		temp_disp = display.getCurrent();
	}
	public void destroyApp(boolean unconditional) {
        nes.unload_curr_rom();
		notifyDestroyed();
	}
	public void returnFromDemo() {
        temp_disp = null; startApp();
	}
//	============================================================================
//	[+]	NES GUI show menu objects
//	============================================================================
	private void ShowMainMenu() {
		String sArray[] = { "Open game", "Settings", "About", "Exit" };
		Image  iArray[] = new Image[4];
		try {
			iArray[0] = Image.createImage(path_mainmenu + "/open.png");
			iArray[1] = Image.createImage(path_mainmenu + "/settings.png");
			iArray[2] = Image.createImage(path_mainmenu + "/about.png");
			iArray[3] = Image.createImage(path_mainmenu + "/exit.png");
		} catch (Exception e) {}
		MainMenu = new List("Main menu", Choice.IMPLICIT, sArray, iArray);
		if(nes.engine_ok && nes.nes_name != null) MainMenu.addCommand(resume);  // ???
		MainMenu.addCommand(minimize);
		MainMenu.setCommandListener(this);
		OpenGame = Settings = AboutInf = null;
		FrmDispl = FrmContr = FrmEngin = FrmSound = FrmOther = null;
		FrmAbout = null;
		System.gc();
		display.setCurrent(MainMenu);
		emu_config = false;
	}
//	============================================================================
	private void ShowOpenGame() {
		String sArray[] = GetFileList("/games/nes_list.txt");
		Image  iArray[] = new Image[sArray.length];
		Image  cart_img = null;
		try {
			cart_img = Image.createImage(path_other + "/cart.png");
		} catch (Exception e) {}
		for(int i = 0; i < iArray.length; i++) iArray[i] = cart_img;
		OpenGame = new List("Select game", Choice.IMPLICIT, sArray, iArray);
		if(nes.nes_name != null)
            for(int i = 0; i < OpenGame.size(); i++)
                if(nes.nes_name.equals(OpenGame.getString(i))) OpenGame.setSelectedIndex(i, true);
		OpenGame.addCommand(cancel);
		OpenGame.setCommandListener(this);
		MainMenu = Settings = AboutInf = null;
		FrmDispl = FrmContr = FrmEngin = FrmSound = FrmOther = null;
		FrmAbout = null;
		System.gc();
		display.setCurrent(OpenGame);
	}
//	============================================================================
	private void ShowSettings() {
        String sArray[] = { "Display", "Control", "Engine", "Sound", "Other" };
        Image  iArray[] = new Image[5];
        try {
            iArray[0] = Image.createImage(path_settings + "/display.png");
            iArray[1] = Image.createImage(path_settings + "/control.png");
            iArray[2] = Image.createImage(path_settings + "/engine.png");
            iArray[3] = Image.createImage(path_settings + "/sound.png");
            iArray[4] = Image.createImage(path_settings + "/other.png");
        } catch (Exception e) {}
		Settings = new List("Settings", Choice.IMPLICIT, sArray, iArray);
		Settings.addCommand(cancel);
		Settings.setCommandListener(this);
		MainMenu = OpenGame = AboutInf = null;
		FrmDispl = FrmContr = FrmEngin = FrmSound = FrmOther = null;
		FrmAbout = null;
		System.gc();
		display.setCurrent(Settings);
	}
//	============================================================================
	private void ShowAbout() {
		String sArray[] = { "Cartridge", "Emulator", "System" };
		Image  iArray[] = new Image[3];
		try {
            iArray[0] = Image.createImage(path_about + "/rom.png");
			iArray[1] = Image.createImage(path_about + "/help.png");
			iArray[2] = Image.createImage(path_about + "/system.png");
		} catch (Exception e) {}
		AboutInf = new List("About", Choice.IMPLICIT, sArray, iArray);
		AboutInf.addCommand(cancel);
		AboutInf.setCommandListener(this);
		MainMenu = OpenGame = Settings = null;
		FrmDispl = FrmContr = FrmEngin = FrmSound = FrmOther = null;
		FrmAbout = null;
		System.gc();
		display.setCurrent(AboutInf);
	}
//	============================================================================
	private void ShowDisplay(boolean def) {
		FrmDispl = new Form("Display sets");
	{	String sArray[] = nes.CAMERA;
		choisegroupitem = new ChoiceGroup("Camera type", ChoiceGroup.EXCLUSIVE, sArray, null);
		choisegroupitem.setSelectedIndex(def ? nes.def_vmode : nes.vmode, true);
	}	FrmDispl.append(choisegroupitem);
	{	String sArray[] = { "Disabled", "Enabled" };
		choisegroupitem = new ChoiceGroup("Fullscreen scale", ChoiceGroup.EXCLUSIVE, sArray, null);
		choisegroupitem.setSelectedIndex((def ? nes.def_full_scr : nes.full_scr) ? 1 : 0, true);
	}	FrmDispl.append(choisegroupitem);
	{	String sArray[] = { "Fast", "Normal", "Slow" };
		choisegroupitem = new ChoiceGroup("Camera reaction", ChoiceGroup.EXCLUSIVE, sArray, null);
		choisegroupitem.setSelectedIndex(def ? nes.def_reaction : nes.reaction, true);
	}	FrmDispl.append(choisegroupitem);
	{	String sArray[] = { "Not rotate", "Clockwise", "Counterclockwise" };
		choisegroupitem = new ChoiceGroup("Rotate screen", ChoiceGroup.EXCLUSIVE, sArray, null);
		choisegroupitem.setSelectedIndex(def ? nes.def_rmode : nes.rmode, true);
	}	FrmDispl.append(choisegroupitem);
	{	String sArray[] = GetFileList("/resource/palettes/pal_list.txt");
		Image  iArray[] = new Image[sArray.length];
		Image  pal_img  = null;
		try {
			pal_img = Image.createImage(path_other + "/palette.png");
		} catch (Exception e) {}
		for(int i = 0; i < iArray.length; i++) iArray[i] = pal_img;
		choisegroupitem = new ChoiceGroup("Palette", ChoiceGroup.EXCLUSIVE, sArray, iArray);
		String pal_name = def ? nes.def_pal_name : nes.pal_name;
		for(int i = 0; i < choisegroupitem.size(); i++)
			if(pal_name.equals(choisegroupitem.getString(i))) choisegroupitem.setSelectedIndex(i, true);
	}	FrmDispl.append(choisegroupitem);
	{	gauge = new Gauge("Saturation, %", true, 200, 100);
		gauge.setValue(def ? nes.def_saturation : nes.saturation);
	}	FrmDispl.append(gauge);
	{	gauge = new Gauge("Brightness, %", true, 200, 100);
		gauge.setValue(def ? nes.def_brightness : nes.brightness);
	}	FrmDispl.append(gauge);
		FrmDispl.addCommand(save); FrmDispl.addCommand(cancel); FrmDispl.addCommand(defaul);
		FrmDispl.setCommandListener(this);
		MainMenu = OpenGame = Settings = AboutInf = null;
		FrmContr = FrmEngin = FrmSound = FrmOther = null;
		FrmAbout = null;
		System.gc();
		display.setCurrent(FrmDispl);
	}
//	============================================================================
	private void ShowControl(boolean def) {
		FrmContr = new Form("Control sets");
	{	String sArray[] = { "Turbo A (Jump)", "Turbo B (Fire)" };
		choisegroupitem = new ChoiceGroup("Turbo buttons", ChoiceGroup.MULTIPLE, sArray, null);
		boolean selected[] = { def ? nes.def_turboen_a : nes.turboen_a,	def ? nes.def_turboen_b : nes.turboen_b	};
		choisegroupitem.setSelectedFlags(selected);
	}	FrmContr.append(choisegroupitem);
		for(int i = 0; i < PHONE_KEYS.length; i++) {
			choisegroupitem = new ChoiceGroup(PHONE_KEYS[i], ChoiceGroup.EXCLUSIVE, CONTROL, null);
			choisegroupitem.setSelectedIndex(def ? nes.def_keys_map[nes.rmode][i] : nes.keys_map[nes.rmode][i], true);
			FrmContr.append(choisegroupitem);
		}
		FrmContr.addCommand(save); FrmContr.addCommand(cancel);	FrmContr.addCommand(defaul);
		FrmContr.setCommandListener(this);
		MainMenu = OpenGame = Settings = AboutInf = null;
		FrmDispl = FrmEngin = FrmSound = FrmOther = null;
		FrmAbout = null;
		System.gc();
		display.setCurrent(FrmContr);
	}
//	============================================================================
	private void ShowEngine(boolean def) {
		FrmEngin = new Form("Engine sets");
	{	gauge = new Gauge("Skip frames", true, 8, 4);
		gauge.setValue((def ? nes.def_frameskip : nes.frameskip) - 1);
	}	FrmEngin.append(gauge);
    {	String sArray[] = { "Fast fullscreen rendering", "Accurate Sprite 0 detect", "Emulate disabled screen", "224 lines in frame" };                                             
		choisegroupitem = new ChoiceGroup("Video rendering", ChoiceGroup.MULTIPLE, sArray, null);
		boolean selected[] = { 
            def ? nes.def_fastvideo : nes.fastvideo, def ? nes.def_accuS0hit : nes.accuS0hit,
            def ? nes.def_emuscroff : nes.emuscroff, def ? nes.def_ntsc_mode : nes.ntsc_mode
        };
		choisegroupitem.setSelectedFlags(selected);
	}	FrmEngin.append(choisegroupitem);
    {	String sArray[] = { "Restart on low FPS", "Without restart", "Disabled" };
		choisegroupitem = new ChoiceGroup("Smart CPU acceleration", ChoiceGroup.EXCLUSIVE, sArray, null);
		choisegroupitem.setSelectedIndex(2 - (def ? nes.def_cpu_accel : nes.cpu_accel), true);
	}	FrmEngin.append(choisegroupitem);
    {   gauge = new Gauge("Frame delay", true, 20, 0);
		gauge.setValue(def ? nes.def_frame_del : nes.frame_del);
    }	FrmEngin.append(gauge);
		FrmEngin.addCommand(save); FrmEngin.addCommand(cancel); FrmEngin.addCommand(defaul);
		FrmEngin.setCommandListener(this);
		MainMenu = OpenGame = Settings = AboutInf = null;
		FrmDispl = FrmContr = FrmSound = FrmOther = null;
		FrmAbout = null;
		System.gc();
		display.setCurrent(FrmEngin);
	}
//	============================================================================
	private void ShowSound(boolean def) {
        if(nes.midi_device) {    
        	FrmSound = new Form("Sound sets");
        {	String sArray[] = { "Disabled", "Enabled" };
            choisegroupitem = new ChoiceGroup("APU emulation", ChoiceGroup.EXCLUSIVE, sArray, null);
            choisegroupitem.setSelectedIndex((def ? nes.def_apu_enabl : nes.apu_enabl) ? 1 : 0, true);
        }	FrmSound.append(choisegroupitem);
        {	String sArray[] = { "Square 1", "Square 2", "Triangle" };
            choisegroupitem = new ChoiceGroup("APU channels", ChoiceGroup.MULTIPLE, sArray, null);
            boolean selected[] = { 
                def ? nes.def_sq1_enabl : nes.sq1_enabl,
                def ? nes.def_sq2_enabl : nes.sq2_enabl,
                def ? nes.def_tri_enabl : nes.tri_enabl
            };
            choisegroupitem.setSelectedFlags(selected);
        }	FrmSound.append(choisegroupitem);
        {	textfield = new TextField("Triangle patch", String.valueOf(def ? nes.def_apu_tri_patch : nes.apu_tri_patch), 3, TextField.NUMERIC);
        }	FrmSound.append(textfield);
        {	textfield = new TextField("Square patch", String.valueOf(def ? nes.def_apu_sqr_patch : nes.apu_sqr_patch), 3, TextField.NUMERIC);
        }	FrmSound.append(textfield);
            FrmSound.addCommand(save); FrmSound.addCommand(cancel); FrmSound.addCommand(defaul);
            FrmSound.setCommandListener(this);
            MainMenu = OpenGame = Settings = AboutInf = null;
            FrmDispl = FrmContr = FrmEngin = FrmOther = null;
            FrmAbout = null;
            System.gc();
            display.setCurrent(FrmSound);
        } else show_error("The sound output is not supported on this device");
	}
//	============================================================================
	private void ShowOther(boolean def) {
		FrmOther = new Form("Other sets");
	{	String sArray[] = { "Enable OSD", "Show FPS" };
		choisegroupitem = new ChoiceGroup("Video features", ChoiceGroup.MULTIPLE, sArray, null);
		boolean selected[] = { 
			def ? nes.def_osd_enable : nes.osd_enable, def ? nes.def_fps_enable : nes.fps_enable
		};
		choisegroupitem.setSelectedFlags(selected);
	}	FrmOther.append(choisegroupitem);	
	{	String sArray[] = { "White", "Yellow", "Cyan", "Blue" };
		choisegroupitem = new ChoiceGroup("OSD colour", ChoiceGroup.EXCLUSIVE, sArray, null);
		choisegroupitem.setSelectedIndex(def ? nes.def_osd_colour : nes.osd_colour, true);
	}	FrmOther.append(choisegroupitem);	
	{	String sArray[] = { "Small", "Medium", "Large" };
		choisegroupitem = new ChoiceGroup("OSD size", ChoiceGroup.EXCLUSIVE, sArray, null);
		choisegroupitem.setSelectedIndex(def ? nes.def_osd_font : nes.osd_font, true);
	}	FrmOther.append(choisegroupitem);
    {	String sArray[] = { "Keep game settings", "Unceasing play" };
		choisegroupitem = new ChoiceGroup("Game features", ChoiceGroup.MULTIPLE, sArray, null);
		boolean selected[] = { 
			def ? nes.def_keep_sets  : nes.keep_sets, def ? nes.def_auto_sload : nes.auto_sload
		};
		choisegroupitem.setSelectedFlags(selected);
	}	FrmOther.append(choisegroupitem);	
		FrmOther.addCommand(save); FrmOther.addCommand(cancel);	FrmOther.addCommand(defaul);
		FrmOther.setCommandListener(this);
		MainMenu = OpenGame = Settings = AboutInf = null;
		FrmDispl = FrmContr = FrmEngin = FrmSound = null;
		FrmAbout = null;
		System.gc();
		display.setCurrent(FrmOther);
	}
//	============================================================================
	private void ShowInformation(int index) {
		String title = "";
		String text  = "";
		switch (index) {
			case 0:
				title = "Cartridge info";
				if(nes.engine_ok && nes.nes_name != null) { //  ????
					String mirroring = "";
					if(nes.mir_four)  mirroring = "Four screen";
					else
					if(!nes.mir_vert) mirroring = "Horizontal";
					else
					if(nes.mir_vert)  mirroring = "Vertical";
					text += "Cartridge: " + nes.nes_name + "\n";
					text += "Mirroring: " + mirroring + "\n";
					text += "PRG-ROM: " + nes.prg_size / 1024 + "K" + "\n";
					if(nes.chr_size != 0)
					text += "CHR-ROM: " + nes.chr_size / 1024 + "K" + "\n";
					text += "Mapper: " + nes.mapper + "\n";
					text += "Save SRAM: " + (nes.bat_sram ? "Yes" : "No");
				} else
					text = "There is no cartridge! You must go to \"Open game\" and select the game!";
				break;
			case 1:
				title = "About emulator";
				text += "Nescube v1.2" + "\n\n";
				text += "Nintendo Entertainment System emulator for mobile phones with J2ME. ";
				text += "Suppurted mappers: 0, 1, 2, 3, 4, 6, 7, 8, 11, 15" + "\n\n";
				text += "Main idea, code, gfx:" + "\n";
				text += "Dr.Lion/RSM" + "\n\n";
				text += "mail: lion_rsm@mail.ru" + "\n";
				text += "web: http://rsm.pud.ru" + "\n";
				text += "icq: 347279524" + "\n\n";
				text += "Real Soft Makers 2007";
				break;
			case 2:
				Runtime r = Runtime.getRuntime();
				long total = (r.totalMemory() + 512) / 1024;
				long free  = (r.freeMemory()  + 512) / 1024;
				title = "System info";
				text += "J2ME platform: " + System.getProperty("microedition.platform") + "\n";
				text += "Total memory: " + total + "K\n";
				text += "Used memory: " + (total - free) + "K\n";
                break;	
				
				
		}
		StringItem stringitem = new StringItem(null, text);
		stringitem.setFont(Font.getFont(Font.FACE_MONOSPACE, Font.STYLE_PLAIN, Font.SIZE_SMALL));
		FrmAbout = new Form(title);
		FrmAbout.append(stringitem);
		FrmAbout.addCommand(ok);
		FrmAbout.setCommandListener(this);
		MainMenu = OpenGame = Settings = AboutInf = null;
		FrmDispl = FrmContr = FrmEngin = FrmSound = FrmOther = null;
		System.gc();
		display.setCurrent(FrmAbout);
	}
//	============================================================================	
	private void ShowNes() {
		OpenGame = MainMenu = Settings = AboutInf = null;
		FrmDispl = FrmContr = FrmEngin = FrmSound = FrmOther = null;
		FrmAbout = null;
		System.gc();
		if(nes.engine_ok) display.setCurrent(nes);
		emu_config = true;
	}
//	============================================================================
//	[+]	Put variables to NES hardware emulator
//	============================================================================
	private void SaveSetsDisplay() {
		choisegroupitem = (ChoiceGroup)(FrmDispl.get(0)); nes.vmode    = choisegroupitem.getSelectedIndex();
		choisegroupitem = (ChoiceGroup)(FrmDispl.get(1)); nes.full_scr = choisegroupitem.getSelectedIndex() == 1;
		choisegroupitem = (ChoiceGroup)(FrmDispl.get(2)); nes.reaction = choisegroupitem.getSelectedIndex();
		choisegroupitem = (ChoiceGroup)(FrmDispl.get(3)); nes.rmode    = choisegroupitem.getSelectedIndex();
		choisegroupitem = (ChoiceGroup)(FrmDispl.get(4)); nes.pal_name = choisegroupitem.getString(choisegroupitem.getSelectedIndex());
		gauge = (Gauge)(FrmDispl.get(5)); nes.saturation = gauge.getValue();
		gauge = (Gauge)(FrmDispl.get(6)); nes.brightness = gauge.getValue();
		nes.apply_settings();
		if(nes.engine_ok) if(emu_config) ShowNes(); else ShowMainMenu();
	}
//	============================================================================
	private void SaveSetsControl() {
        boolean selected[] = null;
		choisegroupitem = (ChoiceGroup)(FrmContr.get(0)); selected = new boolean[choisegroupitem.size()];
		choisegroupitem.getSelectedFlags(selected);
		nes.turboen_a = selected[0];
		nes.turboen_b = selected[1];
		for(int i = 0; i < PHONE_KEYS.length; i++) {
			choisegroupitem = (ChoiceGroup)(FrmContr.get(1 + i));
			nes.keys_map[nes.rmode][i] = (byte)choisegroupitem.getSelectedIndex();
		}
		nes.apply_settings();
		if(nes.engine_ok) if(emu_config) ShowNes(); else ShowMainMenu();
	}
//	============================================================================	
	private void SaveSetsEngine() {
        boolean selected[] = null;
		gauge = (Gauge)(FrmEngin.get(0)); nes.frameskip = gauge.getValue() + 1;
        choisegroupitem = (ChoiceGroup)(FrmEngin.get(1)); selected = new boolean[choisegroupitem.size()];
		choisegroupitem.getSelectedFlags(selected);
        nes.fastvideo = selected[0];
        nes.accuS0hit = selected[1];
        nes.emuscroff = selected[2];
        nes.ntsc_mode = selected[3];
        choisegroupitem = (ChoiceGroup)(FrmEngin.get(2)); nes.cpu_accel = 2 - choisegroupitem.getSelectedIndex();
        gauge = (Gauge)(FrmEngin.get(3)); nes.frame_del = gauge.getValue();
		nes.apply_settings();
		if(nes.engine_ok) if(emu_config) ShowNes(); else ShowMainMenu();
	}
//	============================================================================
	private void SaveSetsSound() {
        boolean selected[] = null;
		choisegroupitem = (ChoiceGroup)(FrmSound.get(0)); nes.apu_enabl = choisegroupitem.getSelectedIndex() == 1;
		choisegroupitem = (ChoiceGroup)(FrmSound.get(1)); selected = new boolean[choisegroupitem.size()];
		choisegroupitem.getSelectedFlags(selected);
		nes.sq1_enabl = selected[0];
		nes.sq2_enabl = selected[1];
		nes.tri_enabl = selected[2];
		textfield = (TextField)(FrmSound.get(2)); nes.apu_tri_patch = Integer.parseInt(textfield.getString());
		textfield = (TextField)(FrmSound.get(3)); nes.apu_sqr_patch = Integer.parseInt(textfield.getString());
		nes.apply_settings();
		if(nes.engine_ok) if(emu_config) ShowNes(); else ShowMainMenu();
	}
//	============================================================================
	private void SaveSetsOther() {
        boolean selected[] = null;
		choisegroupitem = (ChoiceGroup)(FrmOther.get(0)); selected = new boolean[choisegroupitem.size()];
		choisegroupitem.getSelectedFlags(selected);
		nes.osd_enable  = selected[0];
		nes.fps_enable  = selected[1];
		choisegroupitem = (ChoiceGroup)(FrmOther.get(1)); nes.osd_colour = choisegroupitem.getSelectedIndex();
		choisegroupitem = (ChoiceGroup)(FrmOther.get(2)); nes.osd_font   = choisegroupitem.getSelectedIndex();
        choisegroupitem = (ChoiceGroup)(FrmOther.get(3)); selected = new boolean[choisegroupitem.size()];
		choisegroupitem.getSelectedFlags(selected);
		nes.keep_sets  = selected[0];
		nes.auto_sload = selected[1];
		nes.apply_settings();
		if(nes.engine_ok) if(emu_config) ShowNes(); else ShowMainMenu();
	}
//	============================================================================
//	[+]	NES GUI other procedures
//	============================================================================
	private String[] GetFileList(String listfile) {
        String FileList[] = null; InputStream is = null; int i, k;
		try {
//          �������� �� ������� �����-������            
			is = this.getClass().getResourceAsStream(listfile);
			if(is == null) throw new IOException("\n\n" + listfile + "\n\n" + "File not found");
//          ������� ���������� ���� � �����-������  
            for(i = k = 0; k != -1; k = is.read()) if(k > 32) { i++; while((k = is.read()) > 31) {} }
			if(i == 0) throw new IOException("\n\n" + listfile +"\n\n" + "Wrong file format");
//          ������ ���� �� �����-������ � �� ����������� � �������         
            is = this.getClass().getResourceAsStream(listfile);
			FileList = new String[i];
            for(i = k = 0; k != -1; k = is.read())
                if(k > 32) {
                    StringBuffer sb = new StringBuffer();
                    do sb.append((char)k); while((k = is.read()) > 31);
                    FileList[i++] = new String(sb);
                }
		} catch (Exception e) {	show_error(e.toString()); }
		return FileList;
	}
//	============================================================================
	public void show_error(String err_msg) {
        AlertMsg = null;
		AlertMsg = new Alert("Error message", err_msg + "!", null, AlertType.ERROR);
		AlertMsg.setTimeout(Alert.FOREVER);
		AlertMsg.addCommand(ok);
		AlertMsg.setCommandListener(this);
		display.setCurrent(AlertMsg);
	}
//	============================================================================
//	NES GUI Processor
//	============================================================================
	public void commandAction(Command c, Displayable d) {
		if(d.equals(nes)) {
			if(c == config) ShowSettings();
            if(c == sstate) nes.SaveState(0);
            if(c == lstate) nes.LoadState(0);
			if(c == reset ) nes.reset_system();
			if(c == mmenu ) ShowMainMenu();
		} else
//	----------------------------------------------------------------------------
		if(d.equals(MainMenu)) {
			if(c == List.SELECT_COMMAND) {
				switch (MainMenu.getSelectedIndex()) {
					case 0:	ShowOpenGame();
						break;
					case 1:	ShowSettings();
						break;
					case 2:	ShowAbout();
						break;
					case 3:	destroyApp(false);
						break;
				}
			}
			if(c == minimize) {
				temp_disp = display.getCurrent();
				display.setCurrent(null);
			}
			if(c == resume) ShowNes();
		} else
//	----------------------------------------------------------------------------
		if(d.equals(OpenGame)) {
			if(c == List.SELECT_COMMAND) {
				nes.start_emulation(OpenGame.getString(OpenGame.getSelectedIndex()));
				ShowNes();
			}
			if(c == cancel) ShowMainMenu();
		} else
//	----------------------------------------------------------------------------
		if(d.equals(Settings)) {
			if(c == List.SELECT_COMMAND) {
				switch (Settings.getSelectedIndex()) {
					case 0:	ShowDisplay(false); break;
					case 1: ShowControl(false); break;
					case 2: ShowEngine(false);  break;
					case 3: ShowSound(false);   break;
					case 4: ShowOther(false);   break;
				}
			}
			if(c == cancel)
				if(emu_config) ShowNes(); else ShowMainMenu();
		} else
//	----------------------------------------------------------------------------
		if(d.equals(FrmDispl)) {
			if(c == save  ) SaveSetsDisplay();
			if(c == cancel) ShowSettings();
			if(c == defaul) ShowDisplay(true);
		} else
//	----------------------------------------------------------------------------
		if(d.equals(FrmContr)) {
			if(c == save  ) SaveSetsControl();
			if(c == cancel) ShowSettings();
			if(c == defaul) ShowControl(true);
		} else
//	----------------------------------------------------------------------------
		if(d.equals(FrmEngin)) {
			if(c == save  ) SaveSetsEngine();
			if(c == cancel) ShowSettings();
			if(c == defaul) ShowEngine(true);
		} else
//	----------------------------------------------------------------------------
		if(d.equals(FrmSound)) {
			if(c == save  ) SaveSetsSound();
			if(c == cancel) ShowSettings();
			if(c == defaul) ShowSound(true);
		} else
//	----------------------------------------------------------------------------
		if(d.equals(FrmOther)) {
			if(c == save  ) SaveSetsOther();
			if(c == cancel) ShowSettings();
			if(c == defaul) ShowOther(true);
		} else
//	----------------------------------------------------------------------------
		if(d.equals(AboutInf)) {
			if(c == List.SELECT_COMMAND)
				ShowInformation(AboutInf.getSelectedIndex());
			if(c == cancel) ShowMainMenu();
		} else
//	----------------------------------------------------------------------------
		if(d.equals(FrmAbout)) {
			if(c == ok) ShowAbout();
		} else
//	----------------------------------------------------------------------------   
		if(d.equals(AlertMsg)) {
			if(c == ok) {
				ShowMainMenu();
			}
		}
	}
//  ============================================================================
}
