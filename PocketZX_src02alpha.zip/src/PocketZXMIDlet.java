import com.rsm.filesystem.*;
import java.io.InputStream;
import java.util.Hashtable;
import javax.microedition.lcdui.*;
import javax.microedition.midlet.MIDlet;

public class PocketZXMIDlet extends MIDlet implements CommandListener {
    
    private Display currDisplay;
    
    private TextBox textbox;
    
    private Command
            cmdOpenImage = new Command("Open image", Command.SCREEN, 1),
            cmdFrameSkip = new Command("Frame skip", Command.SCREEN, 1),
            cmdReset     = new Command("Reset"     , Command.SCREEN, 1),
            cmdAbout     = new Command("About"     , Command.SCREEN, 1),
            cmdExit      = new Command("Exit"      , Command.SCREEN, 1);
    
    private Command cmdCancel = new Command("Cancel", Command.BACK, 1);
    private Command cmdDone   = new Command("Done"  , Command.OK  , 1);
    
    
    private EngineGameCanvas engine;
    
    private boolean fbrowserActive;
    
    public PocketZXMIDlet() {
        currDisplay = Display.getDisplay(this);
        
        textbox = new TextBox("Frame skip (0-8)", "", 1, TextField.NUMERIC);
        textbox.addCommand(cmdDone);
        textbox.setCommandListener(this);        
        
        engine  = new EngineGameCanvas();
        engine.addCommand(cmdOpenImage);
        engine.addCommand(cmdFrameSkip);
        engine.addCommand(cmdReset);
        engine.addCommand(cmdAbout);
        engine.addCommand(cmdExit);
        engine.setCommandListener(this);
    }
    
    public void startApp() {
        currDisplay.setCurrent(engine);
    }
    
    public void pauseApp() {
    }
    
    public void destroyApp(boolean unconditional) {
        engine = null;
        notifyDestroyed();
    }
    
    public void commandAction(Command command, Displayable displayable) {
        if(fbrowserActive) {            
            if(command.equals(List.SELECT_COMMAND)) {
                new Thread() {
                    public void run() {
                        String romname = showFileBrowser(true);
                        if(romname != null) {
                            Form waitForm = new Form("Waiting");
                            waitForm.append(new Gauge(null, false, Gauge.INDEFINITE, Gauge.CONTINUOUS_RUNNING));
                            currDisplay.setCurrent(waitForm);
                            InputStream is;
                            try {
                                is = filesystem.getInputStream(romname);
                                if(romname.toLowerCase().endsWith(Filter[0])) engine.loadSNA(is);
                                else
                                if(romname.toLowerCase().endsWith(Filter[1])) engine.loadZ80(is);  
                            } catch(Exception ex) {                                
                                //  ...
                                engine.resetSystem();
                            }
                            currDisplay.setCurrent(engine);
                            fbrowserActive = false;
                        }
                    }
                }.start();
            } else {
                currDisplay.setCurrent(engine);
                fbrowserActive = false;
            }            
            return;
        } else {
            if(command.equals(cmdOpenImage)) {
                fbrowserActive = true;                
                new Thread() {
                    public void run() {
                        showFileBrowser(false);
                    }
                }.start();
                return;
            }
            if(command.equals(cmdFrameSkip)) {
                textbox.setString(Integer.toString(engine.frameskip));
                currDisplay.setCurrent(textbox);
                return;
            }
            if(command.equals(cmdDone)) {
                if(displayable instanceof TextBox) {
                    engine.frameskip = Integer.parseInt(textbox.getString());
                    engine.refreshSettings();
                }
                currDisplay.setCurrent(engine);
                return;
            }
            if(command.equals(cmdReset)) {
                engine.resetSystem();
                return;
            }
            if(command.equals(cmdAbout)) {
                Form form = new Form("About emulator");
                StringItem si;
                si = new StringItem("PocketZX v0.2 alpha", "");
                si.setFont(Font.getFont(Font.FACE_MONOSPACE, Font.STYLE_UNDERLINED, Font.SIZE_LARGE));
                si.setLayout(Item.LAYOUT_CENTER); form.append(si);
                String text = "ZX-Spectrum 48/128K emulator for mobile devices with J2ME technology.";
                si = new StringItem("\n", text);
                si.setFont(Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_SMALL));
                si.setLayout(Item.LAYOUT_EXPAND); form.append(si);
                si = new StringItem("\nIdea, code:\n", "Dr.Lion/RSM");
                si.setFont(Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_SMALL));
                si.setLayout(Item.LAYOUT_LEFT); form.append(si);
                si = new StringItem("\n" + "mail: ", "lion_rsm@mail.ru");
                si.setFont(Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_SMALL));
                si.setLayout(Item.LAYOUT_LEFT); form.append(si);
                si = new StringItem("web: ", "http://rsm.hocom.by");
                si.setFont(Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_SMALL));
                si.setLayout(Item.LAYOUT_LEFT); form.append(si);
                si = new StringItem("icq: ", "347279524");
                si.setFont(Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_SMALL));
                si.setLayout(Item.LAYOUT_LEFT); form.append(si);
                si = new StringItem("\n" + "Real Soft Makers 2008", "");
                si.setFont(Font.getFont(Font.FACE_SYSTEM, Font.STYLE_ITALIC, Font.SIZE_MEDIUM));
                si.setLayout(Item.LAYOUT_CENTER); form.append(si);
                form.addCommand(cmdDone);
                form.setCommandListener(this);
                currDisplay.setCurrent(form);
                return;
            }
            if(command.equals(cmdExit)) {
                destroyApp(false);
                return;
            }
            
        }
        
    }

//  ============================================================================
    private final String RES_IMAGES_FOLDER = "/images/";
    
    private final String FILESYSTEM_ICONS  = "/res/icons/filesystem/";
    private final String[] FS_ICONS_NAMES  = { 
        "device.png", "folder.png", "upfolder.png", null, "snapshot.png", "snapshot.png", "zip.png", "zip.png", "zip.png", null
    };
    private final String[] Filter = { "sna", "z80" };
    
    FileSystem filesystem = FileSystemManager.getFileSystem(true, Filter, RES_IMAGES_FOLDER);
    
    
    private String showFileBrowser(boolean refresh) {
        String filename = "";
        try {
            List last = (List)currDisplay.getCurrent();
            if(refresh) filename = last.getString(last.getSelectedIndex());
        } catch(Throwable t) {}
        String files[] = filesystem.getFileList(filename);
        if(files == null) return filename;
        List list = new List("Open image", List.IMPLICIT);
        Image[] icons = new Image[FS_ICONS_NAMES.length];
        try {
        
        for(int i = 0; i < icons.length; i++) icons[i] = GetIcon(FILESYSTEM_ICONS + FS_ICONS_NAMES[i]);
        
        } catch(Throwable t) {
            t.printStackTrace();
        }
        for(int i = 0; i < files.length; i++) {
            String file = files[i];
            list.append(file, icons[filesystem.getFileTypeIndex(file) + 4]);
            if(file.equals(filesystem.getCurrentFile())) list.setSelectedIndex(i, true);
        }
        list.addCommand(cmdCancel);
        list.setCommandListener(this);
        currDisplay.setCurrent(list);
        return null;
    }
    
//  ============================================================================
//  ������� ����������� ������������ � �������� ������                30.01.2008
//  ============================================================================    
    private Hashtable icons_cache = null;
    private final int MAX_IC_SIZE = 10;
//  ----------------------------------------------------------------------------    
    private Image GetIcon(String iconPath) {
        if(iconPath == null) return null;
        Image icon = getCachedIcon(iconPath);
        if(icon == null) {
            try {
                icon = Image.createImage(iconPath);
                setCachedIcon(iconPath, icon);
            } catch(Throwable t) {}
        }
        return icon;
    }
//  ----------------------------------------------------------------------------
    private Image GetIcon(int color) {
        String key = Integer.toString(color);
        Image icon = getCachedIcon(key);
        if(icon == null) {
            int[] rgbimg = new int[16 * 16];
            for(int i = 0; i < rgbimg.length; i++) rgbimg[i] = color;
            for(int i = 0; i < 16; i++) rgbimg[i] = rgbimg[16 * 15 + i] = rgbimg[16 * i] = rgbimg[16 * i + 15] = 0x00FFFFFF;
            icon = Image.createRGBImage(rgbimg, 16, 16, false);
            setCachedIcon(key, icon);
        }
        return icon;        
    }
//  ----------------------------------------------------------------------------    
    private Image getCachedIcon(String key) {
        return icons_cache != null ? (Image)icons_cache.get(key) : null;        
    }
//  ----------------------------------------------------------------------------    
    private void setCachedIcon(String key, Image icon) {
        if(icons_cache == null || icons_cache.size() == MAX_IC_SIZE) icons_cache = new Hashtable();
        icons_cache.put(key, icon);       
    }    
    
    
}
