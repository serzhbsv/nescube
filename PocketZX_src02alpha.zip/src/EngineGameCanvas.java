import java.io.*;
import java.util.Random;
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.GameCanvas;

public class EngineGameCanvas extends GameCanvas implements Runnable {

    private String osd_text = "";
    private long osdstart = 0;
    
    private final int[]     OSD_COLOR   = { 0xFFFFFF, 0xFFFF00, 0x00FFFF, 0x0000FF };
    private final long      OSD_TIME    = 2000;
    

//  ============================================================================
    private final int   ROM = 0x00, RAM = 0x03;
    private byte[][]    MEM, RDMEM, WRMEM;
    private byte[]      TRASH;        
//  ============================================================================    
    
    
    public EngineGameCanvas() {
        super(false);
        
        MEM = new byte[(3 + 8) * 64][256];        
        RDMEM = new byte[256][];
        WRMEM = new byte[256][];
        TRASH = new byte[256];        
        
        try {
            InputStream is = getClass().getResourceAsStream("/res/rom/basic128.rom");
            loadROM(0, is);
            is.close();
            System.gc();
        } catch(Exception e) {}
        
        try {
            InputStream is = getClass().getResourceAsStream("/res/rom/basic48.rom");
            loadROM(1, is);
            is.close();
            System.gc();
        } catch(Exception e) {}
        
        try {
            InputStream is = getClass().getResourceAsStream("/res/rom/trdos.rom");
            loadROM(2, is);
            is.close();
            System.gc();
        } catch(Exception e) {}
        
        refreshSettings();
        prepareEmulation();
        System.gc();        
    }
    
    public void loadROM(int page, InputStream is) {       
        try {
            for(int i = 0; i < 64; i++) is.read(MEM[(ROM + page) * 64 + i]);              
        } catch(Exception e) {}
    }
        

    
    private int P7FFD = 0;
    private int last_rom = -1;
    private int last_ram = -1;
    private boolean tr_dos = false;
    
    
    private final void setupROMpage() {
        int bank = (ROM + (tr_dos ? 0x02 : (P7FFD & 0x10) >> 4)) * 64;
        if(bank != last_rom) {
            last_rom = bank;
            RDMEM[0x00] = MEM[bank++]; RDMEM[0x01] = MEM[bank++]; RDMEM[0x02] = MEM[bank++]; RDMEM[0x03] = MEM[bank++];
            RDMEM[0x04] = MEM[bank++]; RDMEM[0x05] = MEM[bank++]; RDMEM[0x06] = MEM[bank++]; RDMEM[0x07] = MEM[bank++];            
            RDMEM[0x08] = MEM[bank++]; RDMEM[0x09] = MEM[bank++]; RDMEM[0x0A] = MEM[bank++]; RDMEM[0x0B] = MEM[bank++];
            RDMEM[0x0C] = MEM[bank++]; RDMEM[0x0D] = MEM[bank++]; RDMEM[0x0E] = MEM[bank++]; RDMEM[0x0F] = MEM[bank++];            
            RDMEM[0x10] = MEM[bank++]; RDMEM[0x11] = MEM[bank++]; RDMEM[0x12] = MEM[bank++]; RDMEM[0x13] = MEM[bank++];
            RDMEM[0x14] = MEM[bank++]; RDMEM[0x15] = MEM[bank++]; RDMEM[0x16] = MEM[bank++]; RDMEM[0x17] = MEM[bank++];
            RDMEM[0x18] = MEM[bank++]; RDMEM[0x19] = MEM[bank++]; RDMEM[0x1A] = MEM[bank++]; RDMEM[0x1B] = MEM[bank++];
            RDMEM[0x1C] = MEM[bank++]; RDMEM[0x1D] = MEM[bank++]; RDMEM[0x1E] = MEM[bank++]; RDMEM[0x1F] = MEM[bank++];            
            RDMEM[0x20] = MEM[bank++]; RDMEM[0x21] = MEM[bank++]; RDMEM[0x22] = MEM[bank++]; RDMEM[0x23] = MEM[bank++];
            RDMEM[0x24] = MEM[bank++]; RDMEM[0x25] = MEM[bank++]; RDMEM[0x26] = MEM[bank++]; RDMEM[0x27] = MEM[bank++];            
            RDMEM[0x28] = MEM[bank++]; RDMEM[0x29] = MEM[bank++]; RDMEM[0x2A] = MEM[bank++]; RDMEM[0x2B] = MEM[bank++];
            RDMEM[0x2C] = MEM[bank++]; RDMEM[0x2D] = MEM[bank++]; RDMEM[0x2E] = MEM[bank++]; RDMEM[0x2F] = MEM[bank++];
            RDMEM[0x30] = MEM[bank++]; RDMEM[0x31] = MEM[bank++]; RDMEM[0x32] = MEM[bank++]; RDMEM[0x33] = MEM[bank++];
            RDMEM[0x34] = MEM[bank++]; RDMEM[0x35] = MEM[bank++]; RDMEM[0x36] = MEM[bank++]; RDMEM[0x37] = MEM[bank++];
            RDMEM[0x38] = MEM[bank++]; RDMEM[0x39] = MEM[bank++]; RDMEM[0x3A] = MEM[bank++]; RDMEM[0x3B] = MEM[bank++];
            RDMEM[0x3C] = MEM[bank++]; RDMEM[0x3D] = MEM[bank++]; RDMEM[0x3E] = MEM[bank++]; RDMEM[0x3F] = MEM[bank  ];            
        }
    }
 
    private final void setupRAMpage() {
        int bank = (RAM + (P7FFD & 0x07)) * 64;
        if(bank != last_ram) {
            last_ram = bank;
            RDMEM[0xC0] = WRMEM[0xC0] = MEM[bank++]; RDMEM[0xC1] = WRMEM[0xC1] = MEM[bank++]; RDMEM[0xC2] = WRMEM[0xC2] = MEM[bank++]; RDMEM[0xC3] = WRMEM[0xC3] = MEM[bank++];
            RDMEM[0xC4] = WRMEM[0xC4] = MEM[bank++]; RDMEM[0xC5] = WRMEM[0xC5] = MEM[bank++]; RDMEM[0xC6] = WRMEM[0xC6] = MEM[bank++]; RDMEM[0xC7] = WRMEM[0xC7] = MEM[bank++];
            RDMEM[0xC8] = WRMEM[0xC8] = MEM[bank++]; RDMEM[0xC9] = WRMEM[0xC9] = MEM[bank++]; RDMEM[0xCA] = WRMEM[0xCA] = MEM[bank++]; RDMEM[0xCB] = WRMEM[0xCB] = MEM[bank++];
            RDMEM[0xCC] = WRMEM[0xCC] = MEM[bank++]; RDMEM[0xCD] = WRMEM[0xCD] = MEM[bank++]; RDMEM[0xCE] = WRMEM[0xCE] = MEM[bank++]; RDMEM[0xCF] = WRMEM[0xCF] = MEM[bank++];            
            RDMEM[0xD0] = WRMEM[0xD0] = MEM[bank++]; RDMEM[0xD1] = WRMEM[0xD1] = MEM[bank++]; RDMEM[0xD2] = WRMEM[0xD2] = MEM[bank++]; RDMEM[0xD3] = WRMEM[0xD3] = MEM[bank++];
            RDMEM[0xD4] = WRMEM[0xD4] = MEM[bank++]; RDMEM[0xD5] = WRMEM[0xD5] = MEM[bank++]; RDMEM[0xD6] = WRMEM[0xD6] = MEM[bank++]; RDMEM[0xD7] = WRMEM[0xD7] = MEM[bank++];
            RDMEM[0xD8] = WRMEM[0xD8] = MEM[bank++]; RDMEM[0xD9] = WRMEM[0xD9] = MEM[bank++]; RDMEM[0xDA] = WRMEM[0xDA] = MEM[bank++]; RDMEM[0xDB] = WRMEM[0xDB] = MEM[bank++];
            RDMEM[0xDC] = WRMEM[0xDC] = MEM[bank++]; RDMEM[0xDD] = WRMEM[0xDD] = MEM[bank++]; RDMEM[0xDE] = WRMEM[0xDE] = MEM[bank++]; RDMEM[0xDF] = WRMEM[0xDF] = MEM[bank++];            
            RDMEM[0xE0] = WRMEM[0xE0] = MEM[bank++]; RDMEM[0xE1] = WRMEM[0xE1] = MEM[bank++]; RDMEM[0xE2] = WRMEM[0xE2] = MEM[bank++]; RDMEM[0xE3] = WRMEM[0xE3] = MEM[bank++];
            RDMEM[0xE4] = WRMEM[0xE4] = MEM[bank++]; RDMEM[0xE5] = WRMEM[0xE5] = MEM[bank++]; RDMEM[0xE6] = WRMEM[0xE6] = MEM[bank++]; RDMEM[0xE7] = WRMEM[0xE7] = MEM[bank++];
            RDMEM[0xE8] = WRMEM[0xE8] = MEM[bank++]; RDMEM[0xE9] = WRMEM[0xE9] = MEM[bank++]; RDMEM[0xEA] = WRMEM[0xEA] = MEM[bank++]; RDMEM[0xEB] = WRMEM[0xEB] = MEM[bank++];
            RDMEM[0xEC] = WRMEM[0xEC] = MEM[bank++]; RDMEM[0xED] = WRMEM[0xED] = MEM[bank++]; RDMEM[0xEE] = WRMEM[0xEE] = MEM[bank++]; RDMEM[0xEF] = WRMEM[0xEF] = MEM[bank++];            
            RDMEM[0xF0] = WRMEM[0xF0] = MEM[bank++]; RDMEM[0xF1] = WRMEM[0xF1] = MEM[bank++]; RDMEM[0xF2] = WRMEM[0xF2] = MEM[bank++]; RDMEM[0xF3] = WRMEM[0xF3] = MEM[bank++];
            RDMEM[0xF4] = WRMEM[0xF4] = MEM[bank++]; RDMEM[0xF5] = WRMEM[0xF5] = MEM[bank++]; RDMEM[0xF6] = WRMEM[0xF6] = MEM[bank++]; RDMEM[0xF7] = WRMEM[0xF7] = MEM[bank++];
            RDMEM[0xF8] = WRMEM[0xF8] = MEM[bank++]; RDMEM[0xF9] = WRMEM[0xF9] = MEM[bank++]; RDMEM[0xFA] = WRMEM[0xFA] = MEM[bank++]; RDMEM[0xFB] = WRMEM[0xFB] = MEM[bank++];
            RDMEM[0xFC] = WRMEM[0xFC] = MEM[bank++]; RDMEM[0xFD] = WRMEM[0xFD] = MEM[bank++]; RDMEM[0xFE] = WRMEM[0xFE] = MEM[bank++]; RDMEM[0xFF] = WRMEM[0xFF] = MEM[bank  ];
        }
    }
    
    
    
    
    public final void resetSystem() {
        String res_type = "";
        for(int i = 0; i < 64; i++) {
            WRMEM[0x00 + i] = TRASH;
            RDMEM[0x40 + i] = WRMEM[0x40 + i] = MEM[(RAM + 0x05) * 64 + i];
            RDMEM[0x80 + i] = WRMEM[0x80 + i] = MEM[(RAM + 0x02) * 64 + i];
            last_rom = last_ram = -1;
        }
        switch(res_mode) {
            case 0: tr_dos = false; P7FFD = 0x00; res_type = "BASIC128"; break;
            case 1: tr_dos = false; P7FFD = 0x30; res_type = "BASIC48";  break;
            case 2: tr_dos = true;  P7FFD = 0x10; res_type = "TR-DOS";   break;
        }
        cur_brd = pal1[0];
        setupROMpage();
        setupRAMpage();
        resetCPU();        
        print_osd("Reset to " + res_type);
    }
    
    
    
    
    
    protected final void showNotify() {
        if(engine_ok) emulThreadControl(ACT_START);
        System.gc();
        
    }

    protected final void hideNotify() {
        emulThreadControl(ACT_STOP);
        System.gc();
    }
    

    
//  ============================================================================
//  ���������� ������� ��������
//  ============================================================================
    private boolean   isRunning  = false;
    private final int ACT_START  = 0;
    private final int ACT_PAUSE  = 1;
    private final int ACT_RESUME = 2;
    private final int ACT_STOP   = 3;
    private Thread thread;
//  ============================================================================
    private void emulThreadControl(int action) {
        Thread.currentThread().setPriority(Thread.MAX_PRIORITY);
        switch(action) {
//          --------------------------------------------------------------------            
            case ACT_START:                
                if(thread == null) {
                    isRunning = true;
                    thread = new Thread(this);
                    thread.start();                    
                }
                return;
//          --------------------------------------------------------------------                
            case ACT_PAUSE:                
                if(thread != null && isRunning) {
                    isRunning = false;
                    try { 
                        thread.join();
                    } catch(InterruptedException e) {}
                }
                return;
//          --------------------------------------------------------------------                
            case ACT_RESUME:                
                if(thread != null && !isRunning) {
                    isRunning = true;
                    thread = new Thread(this);
                    thread.start();             
                }
                return;
//          --------------------------------------------------------------------                
            case ACT_STOP:                
                if(thread != null) {
                    isRunning = false;
                    try { 
                        thread.join();
                    } catch(InterruptedException e) {}
                    thread = null;
                }
                return;
        }
    }    
    
//  ============================================================================
//  [-] ���������� ���� � �������� (���������� ��������, �������� ���� � �.�.)
//  ============================================================================    
    public final void prepareEmulation() {
        engine_ok = true;
        try {            
//            refreshSettings();
//            loadImageFile();
            resetSystem();
        } catch(Exception e) {
            showErrorMsg(e.toString());
        }
    }    
    
//  ============================================================================
//  [-] ���������� ����� ��������
//  ============================================================================
    public final void applySettings() {
        engine_ok = true;
        try {            
            refreshSettings();
        } catch(Exception e) {
            showErrorMsg(e.toString());
        }
    }
    
//  ============================================================================
//  [-] ����� ��������� ��������
//  ============================================================================
    private final void showErrorMsg(String err_msg) {
        engine_ok = false;
//      bridge.showErrorMsg(err_msg);
    }    
    
    
    
    public void run() {
        try {
            Thread.currentThread().setPriority(Thread.MIN_PRIORITY);
            System.gc();
            engineThread();
        } catch(Exception e) {
            e.printStackTrace();
            
        }
    }
    
    private final void resetCPU() {
        emulThreadControl(ACT_PAUSE);        
        LPC = HPC = I = IM = 0;
        IFF1 = IFF2 = false;
        emulThreadControl(ACT_RESUME);
    }
    
    private final void print_osd(String text){
        osdstart = System.currentTimeMillis();
        osd_text = text;
    }
    

    
//  ============================================================================    
//  ����������� ���������, ����� ������ Z80, ��������������� ��������� ������
//  ============================================================================    
    private int     LPC, HPC, LSP, HSP, LIX, HIX, LIY, HIY, I, IM;
    private int     B, C, D, E, H, L, A, F, B2, C2, D2, E2, H2, L2, A2, F2;
    private boolean IFF1, IFF2, CPU_HALTED;
    private int     tstates;
//  ----------------------------------------------------------------------------  
    private int[]   SZHV_INC_T, SZHV_DEC_T, PARITY_T, SZP_T, SZ_T;  
    private int[]   INC, DEC;
    private int[]   RLC, RRC;
    private int[][] SZHVC_SUB_ADD_T;
//  ----------------------------------------------------------------------------
    private final int F_C  = 0x01;
    private final int F_N  = 0x02;
    private final int F_PV = 0x04;
    private final int F_H  = 0x10;
    private final int F_Z  = 0x40;
    private final int F_S  = 0x80;
//  ----------------------------------------------------------------------------      
    private final int F_ZHPV = F_Z | F_H | F_PV;
    private final int F_SZPV = F_S | F_Z | F_PV;
    private final int F_SH   = F_S | F_H;
    private final int F_SZC  = F_S | F_Z | F_C;
//  ----------------------------------------------------------------------------      
    private final int T_STATES = 71680;    
    
//  ============================================================================    
//  �������� ������/������ ������� �������� �������
//  ============================================================================     
    private final int M7FFD = ~0x7FFD;
    private final int MXXFE = ~0xFFFE;
    private final int MXX1F = ~0xFF1F;
    private int lst_brd     = -1;
    private int cur_brd     =  0;
    private int KempstJoy   =  0;
    private ZXKey Keyboard  = new ZXKey();
    
    private final void WRPORT(int addr, int value) {
        if(tr_dos) {
            //  System.out.println("WRPORT[ #" + Integer.toHexString(addr & 0xFF) + " ][ #" + Integer.toHexString(value) + " ]");
            //  ...
        } else {
            if((addr & M7FFD) == 0) {
                if((P7FFD & 0x20) == 0) { P7FFD = value; setupROMpage(); setupRAMpage(); }
                return;
            }        
            if((addr & MXXFE) == 0) { cur_brd = pal1[value & 0x07]; }
        }
    }
    
    private final int RDPORT(int addr) {
        if(tr_dos) {
            //  System.out.println("RDPORT[ #" + Integer.toHexString(addr & 0xFF) + " ]");
            //  ...
        } else {
            if((addr & MXX1F) == 0) return (KempstJoy | 0xE0);
            if((addr & MXXFE) == 0) {
                int ret = 0xFF;
                if((addr & 0x0100) == 0) ret &= Keyboard.getPart(0);
                if((addr & 0x0200) == 0) ret &= Keyboard.getPart(1);
                if((addr & 0x0400) == 0) ret &= Keyboard.getPart(2);
                if((addr & 0x0800) == 0) ret &= Keyboard.getPart(3);
                if((addr & 0x1000) == 0) ret &= Keyboard.getPart(4);
                if((addr & 0x2000) == 0) ret &= Keyboard.getPart(5);
                if((addr & 0x4000) == 0) ret &= Keyboard.getPart(6);
                if((addr & 0x8000) == 0) ret &= Keyboard.getPart(7);
                return ret;
            }
        }
        return 0xFF;
    }
 
    private final void checkTrdos(int HPC) {
        if(tr_dos) {  
            if(HPC >= 0x40) {
                tr_dos = false;
                setupROMpage();
            }
        } else {
            if(HPC == 0x3D && (P7FFD & 0x10) != 0) {
                tr_dos = true;
                setupROMpage();
            }
        }
    }    
    

    
//  ============================================================================    
//  �������� ���� ���������� �������� �������
//  ============================================================================
    private boolean flash = false;
    private int MID_ZOOM;   //  ������� ���������� �������� zoom � ��������� �� 0 - max_zoom;
    private int new_zoom;   //  ����� �������� zoom, � �������� ����� ���������� �������� ��� �������������� ������� ����    
    
    protected void engineThread() {
        generateCPUTables();
//  ----------------------------------------------------------------------------        
        int[]   screen      = this.screen;
        int[]   pal1        = this.pal1;
        int[]   pal2        = this.pal2;
//  ----------------------------------------------------------------------------        
        int     zoom = new_zoom = MID_ZOOM = (mid_zoom * max_zoom) / 100;
//  ----------------------------------------------------------------------------        
        int     frameskip   = this.frameskip;
        int     VFrames     = -1;
        int     fps;
//  ----------------------------------------------------------------------------
        int     scanline, attr, bri, ink1, ink2, pap1, pap2, bit1, bit2;
        boolean filter = false, lst_scr = false, cur_scr = false;
//  ----------------------------------------------------------------------------        
        long lasttime = System.currentTimeMillis();
        while(isRunning) {
            
            if(getWidth() != LastW || getHeight() != LastH) screenSizeChanged();
            
            boolean[] scanline_visible = this.scanline_visible[zoom];
            boolean[] ver_line_visible = this.ver_line_visible[zoom];
            char[] scry_addr = this.scry_addr[zoom];
            char[] scrx_addr = this.scrx_addr[zoom];
            
            for(int gr_frame = frameskip; gr_frame >= 0; gr_frame--) {
                if(!CPU_HALTED) {
                    execute(T_STATES);
                    if(IFF1) {
                        IFF1 = IFF2 = CPU_HALTED = false;
                        if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; }
                        WRMEM[HSP][LSP] = (byte)HPC;
                        if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; }
                        WRMEM[HSP][LSP] = (byte)LPC;
                        if(IM < 2) {
                            HPC = 0x00; LPC = 0x38;
                            tstates -= 13;
                        } else {
                            LPC = 0x00FF & RDMEM[I][0xFF];
                            HPC = 0x00FF & RDMEM[INC[I]][0];
                            tstates -= 19;
                        }
                    }
                } else {
                    print_osd("CPU HALTED!");
                }
//  ----------------------------------------------------------------------------
//  ��������� �������� � ������
//  ----------------------------------------------------------------------------
                if((++VFrames % 25) == 0) flash = !flash;
//                filter = (cur_scr = (P7FFD & 0x08) != 0) != lst_scr && !filter;
//                lst_scr = cur_scr;
            }
//  ----------------------------------------------------------------------------                       
            if(filter) {
                int LBM = 0, HBM = (RAM + 0x05) * 64;
                int LAT = 0, HAT = HBM + 0x18;
                for(int yp = 0; yp < 0xC0; yp += 0x40) {
                    for(int y = 0; y < 0x40; y += 0x08) {
                        for(int dy = 0; dy < 0x08; dy++) {
                            if(scanline_visible[scanline = dy | y | yp]) {
                                for(int x = -1; x < 255;) {                                    
                                    attr = MEM[HAT][LAT];
                                    bri  = attr >> 3 & 0x08;
                                    ink1 = bri | (attr & 0x07);
                                    pap1 = bri | (attr & 0x38) >> 3;
                                    bit1 = MEM[HBM][LBM];
                                    if(flash && (attr & 0x80) != 0) bit1 = ~bit1;                                    
                                    attr = MEM[HAT | 0x80][LAT++];
                                    bri  = attr >> 3 & 0x08;
                                    ink2 = bri | (attr & 0x07);
                                    pap2 = bri | (attr & 0x38) >> 3;
                                    bit2 = MEM[HBM | 0x80][LBM++];
                                    if(flash && (attr & 0x80) != 0) bit2 = ~bit2;                                    
                                    if(ver_line_visible[++x]) screen[scry_addr[scanline] + scrx_addr[x]] = pal1[(bit1 & 0x80) != 0 ? ink1 : pap1] + pal2[(bit2 & 0x80) != 0 ? ink2 : pap2];
                                    if(ver_line_visible[++x]) screen[scry_addr[scanline] + scrx_addr[x]] = pal1[(bit1 & 0x40) != 0 ? ink1 : pap1] + pal2[(bit2 & 0x40) != 0 ? ink2 : pap2];
                                    if(ver_line_visible[++x]) screen[scry_addr[scanline] + scrx_addr[x]] = pal1[(bit1 & 0x20) != 0 ? ink1 : pap1] + pal2[(bit2 & 0x20) != 0 ? ink2 : pap2];
                                    if(ver_line_visible[++x]) screen[scry_addr[scanline] + scrx_addr[x]] = pal1[(bit1 & 0x10) != 0 ? ink1 : pap1] + pal2[(bit2 & 0x10) != 0 ? ink2 : pap2];
                                    if(ver_line_visible[++x]) screen[scry_addr[scanline] + scrx_addr[x]] = pal1[(bit1 & 0x08) != 0 ? ink1 : pap1] + pal2[(bit2 & 0x08) != 0 ? ink2 : pap2];
                                    if(ver_line_visible[++x]) screen[scry_addr[scanline] + scrx_addr[x]] = pal1[(bit1 & 0x04) != 0 ? ink1 : pap1] + pal2[(bit2 & 0x04) != 0 ? ink2 : pap2];
                                    if(ver_line_visible[++x]) screen[scry_addr[scanline] + scrx_addr[x]] = pal1[(bit1 & 0x02) != 0 ? ink1 : pap1] + pal2[(bit2 & 0x02) != 0 ? ink2 : pap2];
                                    if(ver_line_visible[++x]) screen[scry_addr[scanline] + scrx_addr[x]] = pal1[(bit1 & 0x01) != 0 ? ink1 : pap1] + pal2[(bit2 & 0x01) != 0 ? ink2 : pap2];
                                }
                                LBM -= 32; LAT -= 32;
                            }
                            HBM++;
                        }   
                        LBM += 32; LAT += 32; HBM -= 8;
                    }
                    LBM = LAT = 0; HBM += 8; HAT++;
                }
                filter = false;
            } else {
//                int LBM = 0, HBM = cur_scr ? 0x01C0 : 0x0140;
                int LBM = 0, HBM = (RAM + 0x05 + ((P7FFD & 0x08) >> 2)) * 64;
                int LAT = 0, HAT = HBM + 0x18;
                for(int yp = 0; yp < 0xC0; yp += 0x40) {
                    for(int y = 0; y < 0x40; y += 0x08) {
                        for(int dy = 0; dy < 0x08; dy++) {
                            if(scanline_visible[scanline = dy | y | yp]) {
                                for(int x = -1; x < 255;) {
                                    attr = MEM[HAT][LAT++];
                                    bri  = attr >> 3 & 0x08;
                                    ink1 = bri | (attr & 0x07);
                                    pap1 = bri | (attr & 0x38) >> 3;
                                    bit1 = MEM[HBM][LBM++];
                                    if(flash && (attr & 0x80) != 0) bit1 = ~bit1;
                                    if(bit1 == 0) {
                                        if(ver_line_visible[++x]) screen[scry_addr[scanline] + scrx_addr[x]] = pal1[pap1];
                                        if(ver_line_visible[++x]) screen[scry_addr[scanline] + scrx_addr[x]] = pal1[pap1];
                                        if(ver_line_visible[++x]) screen[scry_addr[scanline] + scrx_addr[x]] = pal1[pap1];
                                        if(ver_line_visible[++x]) screen[scry_addr[scanline] + scrx_addr[x]] = pal1[pap1];
                                        if(ver_line_visible[++x]) screen[scry_addr[scanline] + scrx_addr[x]] = pal1[pap1];
                                        if(ver_line_visible[++x]) screen[scry_addr[scanline] + scrx_addr[x]] = pal1[pap1];
                                        if(ver_line_visible[++x]) screen[scry_addr[scanline] + scrx_addr[x]] = pal1[pap1];
                                        if(ver_line_visible[++x]) screen[scry_addr[scanline] + scrx_addr[x]] = pal1[pap1];
                                    } else {                                        
                                        if(ver_line_visible[++x]) screen[scry_addr[scanline] + scrx_addr[x]] = pal1[(bit1 & 0x80) != 0 ? ink1 : pap1];
                                        if(ver_line_visible[++x]) screen[scry_addr[scanline] + scrx_addr[x]] = pal1[(bit1 & 0x40) != 0 ? ink1 : pap1];
                                        if(ver_line_visible[++x]) screen[scry_addr[scanline] + scrx_addr[x]] = pal1[(bit1 & 0x20) != 0 ? ink1 : pap1];
                                        if(ver_line_visible[++x]) screen[scry_addr[scanline] + scrx_addr[x]] = pal1[(bit1 & 0x10) != 0 ? ink1 : pap1];
                                        if(ver_line_visible[++x]) screen[scry_addr[scanline] + scrx_addr[x]] = pal1[(bit1 & 0x08) != 0 ? ink1 : pap1];
                                        if(ver_line_visible[++x]) screen[scry_addr[scanline] + scrx_addr[x]] = pal1[(bit1 & 0x04) != 0 ? ink1 : pap1];
                                        if(ver_line_visible[++x]) screen[scry_addr[scanline] + scrx_addr[x]] = pal1[(bit1 & 0x02) != 0 ? ink1 : pap1];
                                        if(ver_line_visible[++x]) screen[scry_addr[scanline] + scrx_addr[x]] = pal1[(bit1 & 0x01) != 0 ? ink1 : pap1];
                                    }
                                }
                                LBM -= 32; LAT -= 32;
                            }
                            HBM++;
                        }   
                        LBM += 32; LAT += 32; HBM -= 8;
                    }
                    LBM = LAT = 0; HBM += 8; HAT++;
                }
            }
//  ----------------------------------------------------------------------------           
            if(cur_brd != lst_brd) {
                for(int i = 0; i < screen.length; i++) screen[i] = cur_brd;
                lst_brd = cur_brd;
            }            
//  ----------------------------------------------------------------------------            
            graphics.drawRGB(screen, 0, SW, DX, DY, SW, SH, false);
            long currtime = System.currentTimeMillis();
            long framtime = currtime - lasttime + 1;
            lasttime = currtime;
            if(osd_enable && currtime - osdstart < OSD_TIME) {
                graphics.setColor(OSD_COLOR[osd_colour]);
                graphics.drawString(osd_text, DX + 1, DY + 1, 0);
            } else
            if(fps_enable) {
                fps = (int)((long)(1000 * (frameskip + 1)) / framtime);                
                graphics.setColor((fps >= 20 && fps <= 50) ? (fps >= 40 ? 0x00FF00 : 0xFFFF00) : 0xFF0000);
                graphics.drawString("FPS: " + fps, DX + 1, DY + 1, 0);
            }
            flushGraphics();
//  ----------------------------------------------------------------------------                        
            if(zoom > new_zoom) {
                for(int i = 255; i >= 0; i--) if(ver_line_visible[i]) {
                    screen[scry_addr[fst_visible[zoom]] + scrx_addr[i]] = cur_brd;
                    screen[scry_addr[lst_visible[zoom]] + scrx_addr[i]] = cur_brd;
                }
                zoom--;
            } else
            if(zoom < new_zoom) zoom++;
//  ----------------------------------------------------------------------------
            Thread.yield();
        }
        destroyCPUTables();
    }    
    
                

    
//  ============================================================================    
//  �������� ������� ���������� Z80 �� �������� ������� �������
//  ============================================================================    
    Random RND = new Random();
    
    private void execute(int TIME) {
//  ----------------------------------------------------------------------------
//  ��� �������� ��������� ������ ������� CPU Z80 � ������������� cb, dd, ed, fd         
//  ----------------------------------------------------------------------------        
//        byte[][] RDMEM = this.RDMEM;
//        byte[][] WRMEM = this.WRMEM;
//        int[][] SZHVC_SUB_ADD_T = this.SZHVC_SUB_ADD_T;
//        int[] INC = this.INC;
//        int[] DEC = this.DEC;
//        int[] SZHV_INC_T = this.SZHV_INC_T;
//        int[] SZHV_DEC_T = this.SZHV_DEC_T;
//        int[] SZP_T = this.SZP_T;
//        int[] SZ_T = this.SZ_T;        
        int LHPC = -1, OP = 0, BL, BH, LAD, HAD;
        
        for(tstates += TIME; tstates > 0;) {
            if(HPC != LHPC) checkTrdos(LHPC = HPC);
            OP = RDMEM[HPC][LPC];            
            if(LPC++ == 0xFF) { LPC = 0x00; HPC = INC[HPC]; }            
            switch(OP) {
//  ----------------------------------------------------------------------------             
/* NOP          */  case 0x00000000:
/* LD B,B       */  case 0x00000040:
/* LD C,C       */  case 0x00000049:
/* LD D,D       */  case 0x00000052:
/* LD E,E       */  case 0x0000005B:
/* LD H,H       */  case 0x00000064:
/* LD L,L       */  case 0x0000006D:
/* LD A,A       */  case 0x0000007F: tstates -=  4; continue;
//  ----------------------------------------------------------------------------
/* LD (BC),A    */  case 0x00000002: tstates -=  7; WRMEM[B][C] = (byte)A; continue;
/* INC BC       */  case 0x00000003: tstates -=  6; if(C++ == 0xFF) { C = 0x00; B = INC[B]; } continue;
/* INC B        */  case 0x00000004: tstates -=  4; F = (F & F_C) | SZHV_INC_T[B = INC[B]]; continue;
/* DEC B        */  case 0x00000005: tstates -=  4; F = (F & F_C) | SZHV_DEC_T[B = DEC[B]]; continue;
/* RLCA        !*/  case 0x00000007: tstates -=  4; F = F & F_SZPV | (A >> 7); A = RLC[A]; continue;
//  ----------------------------------------------------------------------------
/* EX AF,AF'    */  case 0x00000008: tstates -=  4; { int V0 = A; A = A2; A2 = V0; V0 = F; F = F2; F2 = V0; } continue;
/* ADD HL,BC    */  case 0x00000009: tstates -= 11; { int V0 = H << 8 | L; int V1 = B << 8 | C; int V2 = V0 + V1; F = (F & F_SZPV) | (((V0 ^ V2 ^ V1) >> 8) & 0x10) | ((V2 >> 16) & 1); H = V2 >> 8 & 0xFF; L = V2 & 0xFF; } continue;
/* LD A,{BC)    */  case 0x0000000A: tstates -=  7; A = 0x00FF & RDMEM[B][C]; continue;
/* DEC BC       */  case 0x0000000B: tstates -=  6; if(C-- == 0x00) { C = 0xFF; B = DEC[B]; } continue;
/* INC C        */  case 0x0000000C: tstates -=  4; F = (F & F_C) | SZHV_INC_T[C = INC[C]]; continue;
/* DEC C        */  case 0x0000000D: tstates -=  4; F = (F & F_C) | SZHV_DEC_T[C = DEC[C]]; continue;
/* RRCA         */  case 0x0000000F: tstates -=  4; F = F & F_SZPV | (A & 1); A = RRC[A]; continue;
//  ----------------------------------------------------------------------------
/* LD (DE),A    */  case 0x00000012: tstates -=  7; WRMEM[D][E] = (byte)A; continue;    
/* INC DE       */  case 0x00000013: tstates -=  6; if(E++ == 0xFF) { E = 0x00; D = INC[D]; } continue;
/* INC D        */  case 0x00000014: tstates -=  4; F = (F & F_C) | SZHV_INC_T[D = INC[D]]; continue;
/* DEC D        */  case 0x00000015: tstates -=  4; F = (F & F_C) | SZHV_DEC_T[D = DEC[D]]; continue;
/* RLA         !*/  case 0x00000017: tstates -=  4; { int V0 = A >> 7; A = (A << 1 | (F & F_C)) & 0xFF; F = F & F_SZPV | V0; } continue;
//  ----------------------------------------------------------------------------
/* ADD HL,DE    */  case 0x00000019: tstates -= 11; { int V0 = H << 8 | L; int V1 = D << 8 | E; int V2 = V0 + V1; F = (F & F_SZPV) | (((V0 ^ V2 ^ V1) >> 8) & 0x10) | ((V2 >> 16) & 1); H = V2 >> 8 & 0xFF; L = V2 & 0xFF; } continue;
/* LD A,{DE)    */  case 0x0000001A: tstates -=  7; A = 0x00FF & RDMEM[D][E]; continue;
/* DEC DE       */  case 0x0000001B: tstates -=  6; if(E-- == 0x00) { E = 0xFF; D = DEC[D]; } continue;
/* INC E        */  case 0x0000001C: tstates -=  4; F = (F & F_C) | SZHV_INC_T[E = INC[E]]; continue;
/* DEC E        */  case 0x0000001D: tstates -=  4; F = (F & F_C) | SZHV_DEC_T[E = DEC[E]]; continue;
/* RRA          */  case 0x0000001F: tstates -=  4; { int V0 = A & 1; A = A >> 1 | (F & F_C) << 7; F = F & F_SZPV | V0; } continue;
//  ----------------------------------------------------------------------------
/* INC HL       */  case 0x00000023: tstates -=  6; if(L++ == 0xFF) { L = 0x00; H = INC[H]; } continue;
/* INC H        */  case 0x00000024: tstates -=  4; F = (F & F_C) | SZHV_INC_T[H = INC[H]]; continue;
/* DEC H        */  case 0x00000025: tstates -=  4; F = (F & F_C) | SZHV_DEC_T[H = DEC[H]]; continue;
/* DAA          */  case 0x00000027: tstates -=  4; daa(); continue;
//  ----------------------------------------------------------------------------
/* ADD HL,HL    */  case 0x00000029: tstates -= 11; { int V0 = H << 8 | L; int V1 = V0 << 1; F = (F & F_SZPV) | (((V0 ^ V1 ^ V0) >> 8) & 0x10) | ((V1 >> 16) & 1); H = V1 >> 8 & 0xFF; L = V1 & 0xFF; } continue;
/* DEC HL       */  case 0x0000002B: tstates -=  6; if(L-- == 0x00) { L = 0xFF; H = DEC[H]; } continue;
/* INC L        */  case 0x0000002C: tstates -=  4; F = (F & F_C) | SZHV_INC_T[L = INC[L]]; continue;
/* DEC L        */  case 0x0000002D: tstates -=  4; F = (F & F_C) | SZHV_DEC_T[L = DEC[L]]; continue;
/* CPL          */  case 0x0000002F: tstates -=  4; A ^= 0xFF; F |= F_N | F_H; continue;
//  ----------------------------------------------------------------------------
/* INC SP       */  case 0x00000033: tstates -=  6; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } continue;
/* INC (HL)     */  case 0x00000034: tstates -= 11; F = (F & F_C) | SZHV_INC_T[0xFF & ++WRMEM[H][L]]; continue;
/* DEC (HL)     */  case 0x00000035: tstates -= 11; F = (F & F_C) | SZHV_DEC_T[0xFF & --WRMEM[H][L]]; continue;
/* SCF          */  case 0x00000037: tstates -=  4; F = F & F_SZPV | F_C; continue;
//  ----------------------------------------------------------------------------
/* ADD HL,SP    */  case 0x00000039: tstates -= 11; { int V0 = H << 8 | L; int V1 = HSP << 8 | LSP; int V2 = V0 + V1; F = (F & F_SZPV) | (((V0 ^ V2 ^ V1) >> 8) & 0x10) | ((V2 >> 16) & 1); H = V2 >> 8 & 0xFF; L = V2 & 0xFF; } continue;
/* DEC SP       */  case 0x0000003B: tstates -=  6; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } continue;
/* INC A        */  case 0x0000003C: tstates -=  4; F = (F & F_C) | SZHV_INC_T[A = INC[A]]; continue;
/* DEC A        */  case 0x0000003D: tstates -=  4; F = (F & F_C) | SZHV_DEC_T[A = DEC[A]]; continue;
/* CCF         !*/  case 0x0000003F: tstates -=  4; if((F & F_C) != 0) { F &= ~F_C; F |= F_H; } else { F |= F_C; F &= ~F_H; } F &= ~F_N; continue;
//  ----------------------------------------------------------------------------
/* LD B,C       */  case 0x00000041: tstates -=  4; B = C; continue;
/* LD B,D       */  case 0x00000042: tstates -=  4; B = D; continue;
/* LD B,E       */  case 0x00000043: tstates -=  4; B = E; continue;
/* LD B,H       */  case 0x00000044: tstates -=  4; B = H; continue;
/* LD B,L       */  case 0x00000045: tstates -=  4; B = L; continue;
/* LD B,(HL)    */  case 0x00000046: tstates -=  7; B = 0x00FF & RDMEM[H][L]; continue;
/* LD B,A       */  case 0x00000047: tstates -=  4; B = A; continue;
//  ----------------------------------------------------------------------------
/* LD C,B       */  case 0x00000048: tstates -=  4; C = B; continue;                
/* LD C,D       */  case 0x0000004A: tstates -=  4; C = D; continue;
/* LD C,E       */  case 0x0000004B: tstates -=  4; C = E; continue;
/* LD C,H       */  case 0x0000004C: tstates -=  4; C = H; continue;
/* LD C,L       */  case 0x0000004D: tstates -=  4; C = L; continue;
/* LD C,(HL)    */  case 0x0000004E: tstates -=  7; C = 0x00FF & RDMEM[H][L]; continue;
/* LD C,A       */  case 0x0000004F: tstates -=  4; C = A; continue;  
//  ----------------------------------------------------------------------------
/* LD D,B       */  case 0x00000050: tstates -=  4; D = B; continue;
/* LD D,C       */  case 0x00000051: tstates -=  4; D = C; continue;
/* LD D,E       */  case 0x00000053: tstates -=  4; D = E; continue;
/* LD D,H       */  case 0x00000054: tstates -=  4; D = H; continue;
/* LD D,L       */  case 0x00000055: tstates -=  4; D = L; continue;
/* LD D,(HL)    */  case 0x00000056: tstates -=  7; D = 0x00FF & RDMEM[H][L]; continue;
/* LD D,A       */  case 0x00000057: tstates -=  4; D = A; continue;
//  ----------------------------------------------------------------------------
/* LD E,B       */  case 0x00000058: tstates -=  4; E = B; continue;
/* LD E,C       */  case 0x00000059: tstates -=  4; E = C; continue;
/* LD E,D       */  case 0x0000005A: tstates -=  4; E = D; continue;               
/* LD E,H       */  case 0x0000005C: tstates -=  4; E = H; continue;
/* LD E,L       */  case 0x0000005D: tstates -=  4; E = L; continue;
/* LD E,(HL)    */  case 0x0000005E: tstates -=  7; E = 0x00FF & RDMEM[H][L]; continue;
/* LD E,A       */  case 0x0000005F: tstates -=  4; E = A; continue; 
//  ----------------------------------------------------------------------------
/* LD H,B       */  case 0x00000060: tstates -=  4; H = B; continue;
/* LD H,C       */  case 0x00000061: tstates -=  4; H = C; continue;
/* LD H,D       */  case 0x00000062: tstates -=  4; H = D; continue;
/* LD H,E       */  case 0x00000063: tstates -=  4; H = E; continue;                
/* LD H,L       */  case 0x00000065: tstates -=  4; H = L; continue;
/* LD H,(HL)    */  case 0x00000066: tstates -=  7; H = 0x00FF & RDMEM[H][L]; continue;
/* LD H,A       */  case 0x00000067: tstates -=  4; H = A; continue;
//  ----------------------------------------------------------------------------
/* LD L,B       */  case 0x00000068: tstates -=  4; L = B; continue;
/* LD L,C       */  case 0x00000069: tstates -=  4; L = C; continue;
/* LD L,D       */  case 0x0000006A: tstates -=  4; L = D; continue;
/* LD L,E       */  case 0x0000006B: tstates -=  4; L = E; continue;
/* LD L,H       */  case 0x0000006C: tstates -=  4; L = H; continue;               
/* LD L,(HL)    */  case 0x0000006E: tstates -=  7; L = 0x00FF & RDMEM[H][L]; continue;
/* LD L,A       */  case 0x0000006F: tstates -=  4; L = A; continue;
//  ----------------------------------------------------------------------------
/* LD (HL),B    */  case 0x00000070: tstates -=  7; WRMEM[H][L] = (byte)B; continue;
/* LD (HL),C    */  case 0x00000071: tstates -=  7; WRMEM[H][L] = (byte)C; continue;
/* LD (HL),D    */  case 0x00000072: tstates -=  7; WRMEM[H][L] = (byte)D; continue;
/* LD (HL),E    */  case 0x00000073: tstates -=  7; WRMEM[H][L] = (byte)E; continue;
/* LD (HL),H    */  case 0x00000074: tstates -=  7; WRMEM[H][L] = (byte)H; continue;
/* LD (HL),L    */  case 0x00000075: tstates -=  7; WRMEM[H][L] = (byte)L; continue;
/* HALT         */  case 0x00000076: tstates  =  0; CPU_HALTED = true; continue;
/* LD (HL),A    */  case 0x00000077: tstates -=  7; WRMEM[H][L] = (byte)A; continue;
//  ----------------------------------------------------------------------------
/* LD A,B       */  case 0x00000078: tstates -=  4; A = B; continue;
/* LD A,C       */  case 0x00000079: tstates -=  4; A = C; continue;
/* LD A,D       */  case 0x0000007A: tstates -=  4; A = D; continue;
/* LD A,E       */  case 0x0000007B: tstates -=  4; A = E; continue;
/* LD A,H       */  case 0x0000007C: tstates -=  4; A = H; continue;
/* LD A,L       */  case 0x0000007D: tstates -=  4; A = L; continue;
/* LD A,(HL)    */  case 0x0000007E: tstates -=  7; A = 0x00FF & RDMEM[H][L]; continue;
//  ----------------------------------------------------------------------------
/* ADD A,B     !*/  case 0xFFFFFF80: tstates -=  4; { int V0 = (char)(SZHVC_SUB_ADD_T[A][B] >> 16); F = V0 & 0xFF; A = V0 >> 8; } continue;
/* ADD A,C     !*/  case 0xFFFFFF81: tstates -=  4; { int V0 = (char)(SZHVC_SUB_ADD_T[A][C] >> 16); F = V0 & 0xFF; A = V0 >> 8; } continue;
/* ADD A,D     !*/  case 0xFFFFFF82: tstates -=  4; { int V0 = (char)(SZHVC_SUB_ADD_T[A][D] >> 16); F = V0 & 0xFF; A = V0 >> 8; } continue;
/* ADD A,E     !*/  case 0xFFFFFF83: tstates -=  4; { int V0 = (char)(SZHVC_SUB_ADD_T[A][E] >> 16); F = V0 & 0xFF; A = V0 >> 8; } continue;
/* ADD A,H     !*/  case 0xFFFFFF84: tstates -=  4; { int V0 = (char)(SZHVC_SUB_ADD_T[A][H] >> 16); F = V0 & 0xFF; A = V0 >> 8; } continue;
/* ADD A,L     !*/  case 0xFFFFFF85: tstates -=  4; { int V0 = (char)(SZHVC_SUB_ADD_T[A][L] >> 16); F = V0 & 0xFF; A = V0 >> 8; } continue;
/* ADD A,(HL)  !*/  case 0xFFFFFF86: tstates -=  7; { int V0 = (char)(SZHVC_SUB_ADD_T[A][0x00FF & RDMEM[H][L]] >> 16); F = V0 & 0xFF; A = V0 >> 8; } continue;
/* ADD A,A     !*/  case 0xFFFFFF87: tstates -=  4; { int V0 = (char)(SZHVC_SUB_ADD_T[A][A] >> 16); F = V0 & 0xFF; A = V0 >> 8; } continue;
//  ----------------------------------------------------------------------------
/* ADC A,B     !*/  case 0xFFFFFF88: tstates -=  4; { int V0 = F & F_C, V1 = A + B + V0; F = (V1 >> 8) | SZ_T[V1 &= 0xFF] | (((A ^ ~B) & (A ^ V1)) >> 5 & F_PV) | ((A & 0xF) + (B & 0xF) + V0 & F_H); A = V1; } continue;
/* ADC A,C     !*/  case 0xFFFFFF89: tstates -=  4; { int V0 = F & F_C, V1 = A + C + V0; F = (V1 >> 8) | SZ_T[V1 &= 0xFF] | (((A ^ ~C) & (A ^ V1)) >> 5 & F_PV) | ((A & 0xF) + (C & 0xF) + V0 & F_H); A = V1; } continue;
/* ADC A,D     !*/  case 0xFFFFFF8A: tstates -=  4; { int V0 = F & F_C, V1 = A + D + V0; F = (V1 >> 8) | SZ_T[V1 &= 0xFF] | (((A ^ ~D) & (A ^ V1)) >> 5 & F_PV) | ((A & 0xF) + (D & 0xF) + V0 & F_H); A = V1; } continue;
/* ADC A,E     !*/  case 0xFFFFFF8B: tstates -=  4; { int V0 = F & F_C, V1 = A + E + V0; F = (V1 >> 8) | SZ_T[V1 &= 0xFF] | (((A ^ ~E) & (A ^ V1)) >> 5 & F_PV) | ((A & 0xF) + (E & 0xF) + V0 & F_H); A = V1; } continue;
/* ADC A,H     !*/  case 0xFFFFFF8C: tstates -=  4; { int V0 = F & F_C, V1 = A + H + V0; F = (V1 >> 8) | SZ_T[V1 &= 0xFF] | (((A ^ ~H) & (A ^ V1)) >> 5 & F_PV) | ((A & 0xF) + (H & 0xF) + V0 & F_H); A = V1; } continue;
/* ADC A,L     !*/  case 0xFFFFFF8D: tstates -=  4; { int V0 = F & F_C, V1 = A + L + V0; F = (V1 >> 8) | SZ_T[V1 &= 0xFF] | (((A ^ ~L) & (A ^ V1)) >> 5 & F_PV) | ((A & 0xF) + (L & 0xF) + V0 & F_H); A = V1; } continue;
/* ADC A,(HL)  !*/  case 0xFFFFFF8E: tstates -=  7; { int V0 = 0x00FF & RDMEM[H][L], V1 = F & F_C, V2 = A + V0 + V1; F = (V2 >> 8) | SZ_T[V2 &= 0xFF] | (((A ^ ~V0) & (A ^ V2)) >> 5 & F_PV) | ((A & 0xF) + (V0 & 0xF) + V1 & F_H); A = V2; } continue;
/* ADC A,A     !*/  case 0xFFFFFF8F: tstates -=  4; { int V0 = F & F_C, V1 = A + A + V0; F = (V1 >> 8) | SZ_T[V1 &= 0xFF] | (((A ^ ~A) & (A ^ V1)) >> 5 & F_PV) | ((A & 0xF) + (A & 0xF) + V0 & F_H); A = V1; } continue;
//  ----------------------------------------------------------------------------
/* SUB B       !*/  case 0xFFFFFF90: tstates -=  4; { int V0 = (char)SZHVC_SUB_ADD_T[A][B]; F = V0 & 0xFF; A = V0 >> 8; } continue;
/* SUB C       !*/  case 0xFFFFFF91: tstates -=  4; { int V0 = (char)SZHVC_SUB_ADD_T[A][C]; F = V0 & 0xFF; A = V0 >> 8; } continue;
/* SUB D       !*/  case 0xFFFFFF92: tstates -=  4; { int V0 = (char)SZHVC_SUB_ADD_T[A][D]; F = V0 & 0xFF; A = V0 >> 8; } continue;
/* SUB E       !*/  case 0xFFFFFF93: tstates -=  4; { int V0 = (char)SZHVC_SUB_ADD_T[A][E]; F = V0 & 0xFF; A = V0 >> 8; } continue;
/* SUB H       !*/  case 0xFFFFFF94: tstates -=  4; { int V0 = (char)SZHVC_SUB_ADD_T[A][H]; F = V0 & 0xFF; A = V0 >> 8; } continue;
/* SUB L       !*/  case 0xFFFFFF95: tstates -=  4; { int V0 = (char)SZHVC_SUB_ADD_T[A][L]; F = V0 & 0xFF; A = V0 >> 8; } continue;
/* SUB (HL)    !*/  case 0xFFFFFF96: tstates -=  7; { int V0 = (char)SZHVC_SUB_ADD_T[A][0x00FF & RDMEM[H][L]]; F = V0 & 0xFF; A = V0 >> 8; } continue;
/* SUB A       !*/  case 0xFFFFFF97: tstates -=  4; { int V0 = (char)SZHVC_SUB_ADD_T[A][A]; F = V0 & 0xFF; A = V0 >> 8; } continue;
//  ----------------------------------------------------------------------------
/* SBC A,B     !*/  case 0xFFFFFF98: tstates -=  4; { int V0 = F & F_C, V1 = A - B - V0; F = (V1 >> 8 & F_C) | SZ_T[V1 &= 0xFF] | (((A ^ B) & (A ^ V1)) >> 5 & F_PV) | ((A & 0xF) - (B & 0xF) - V0 & F_H) | F_N; A = V1; } continue;
/* SBC A,C     !*/  case 0xFFFFFF99: tstates -=  4; { int V0 = F & F_C, V1 = A - C - V0; F = (V1 >> 8 & F_C) | SZ_T[V1 &= 0xFF] | (((A ^ C) & (A ^ V1)) >> 5 & F_PV) | ((A & 0xF) - (C & 0xF) - V0 & F_H) | F_N; A = V1; } continue;
/* SBC A,D     !*/  case 0xFFFFFF9A: tstates -=  4; { int V0 = F & F_C, V1 = A - D - V0; F = (V1 >> 8 & F_C) | SZ_T[V1 &= 0xFF] | (((A ^ D) & (A ^ V1)) >> 5 & F_PV) | ((A & 0xF) - (D & 0xF) - V0 & F_H) | F_N; A = V1; } continue;
/* SBC A,E     !*/  case 0xFFFFFF9B: tstates -=  4; { int V0 = F & F_C, V1 = A - E - V0; F = (V1 >> 8 & F_C) | SZ_T[V1 &= 0xFF] | (((A ^ E) & (A ^ V1)) >> 5 & F_PV) | ((A & 0xF) - (E & 0xF) - V0 & F_H) | F_N; A = V1; } continue;
/* SBC A,H     !*/  case 0xFFFFFF9C: tstates -=  4; { int V0 = F & F_C, V1 = A - H - V0; F = (V1 >> 8 & F_C) | SZ_T[V1 &= 0xFF] | (((A ^ H) & (A ^ V1)) >> 5 & F_PV) | ((A & 0xF) - (H & 0xF) - V0 & F_H) | F_N; A = V1; } continue;
/* SBC A,L     !*/  case 0xFFFFFF9D: tstates -=  4; { int V0 = F & F_C, V1 = A - L - V0; F = (V1 >> 8 & F_C) | SZ_T[V1 &= 0xFF] | (((A ^ L) & (A ^ V1)) >> 5 & F_PV) | ((A & 0xF) - (L & 0xF) - V0 & F_H) | F_N; A = V1; } continue;
/* SBC A,(HL)  !*/  case 0xFFFFFF9E: tstates -=  7; { int V0 = 0x00FF & RDMEM[H][L], V1 = F & F_C, V2 = A - V0 - V1; F = (V2 >> 8 & F_C) | SZ_T[V2 &= 0xFF] | (((A ^ V0) & (A ^ V2)) >> 5 & F_PV) | ((A & 0xF) - (V0 & 0xF) - V1 & F_H) | F_N; A = V2; } continue;
/* SBC A,A     !*/  case 0xFFFFFF9F: tstates -=  4; { int V0 = F & F_C, V1 = A - A - V0; F = (V1 >> 8 & F_C) | SZ_T[V1 &= 0xFF] | (((A ^ A) & (A ^ V1)) >> 5 & F_PV) | ((A & 0xF) - (A & 0xF) - V0 & F_H) | F_N; A = V1; } continue;
//  ----------------------------------------------------------------------------
/* AND B        */  case 0xFFFFFFA0: tstates -=  4; F = SZP_T[A &= B] | F_H; continue;
/* AND C        */  case 0xFFFFFFA1: tstates -=  4; F = SZP_T[A &= C] | F_H; continue;
/* AND D        */  case 0xFFFFFFA2: tstates -=  4; F = SZP_T[A &= D] | F_H; continue;
/* AND E        */  case 0xFFFFFFA3: tstates -=  4; F = SZP_T[A &= E] | F_H; continue;
/* AND H        */  case 0xFFFFFFA4: tstates -=  4; F = SZP_T[A &= H] | F_H; continue;
/* AND L        */  case 0xFFFFFFA5: tstates -=  4; F = SZP_T[A &= L] | F_H; continue;
/* AND (HL)     */  case 0xFFFFFFA6: tstates -=  7; F = SZP_T[A &= 0x00FF & RDMEM[H][L]] | F_H; continue; // 0xff - ?
/* AND A        */  case 0xFFFFFFA7: tstates -=  4; F = SZP_T[A] | F_H; continue;
//  ----------------------------------------------------------------------------
/* XOR B        */  case 0xFFFFFFA8: tstates -=  4; F = SZP_T[A ^= B]; continue;
/* XOR C        */  case 0xFFFFFFA9: tstates -=  4; F = SZP_T[A ^= C]; continue;
/* XOR D        */  case 0xFFFFFFAA: tstates -=  4; F = SZP_T[A ^= D]; continue;
/* XOR E        */  case 0xFFFFFFAB: tstates -=  4; F = SZP_T[A ^= E]; continue;
/* XOR H        */  case 0xFFFFFFAC: tstates -=  4; F = SZP_T[A ^= H]; continue;
/* XOR L        */  case 0xFFFFFFAD: tstates -=  4; F = SZP_T[A ^= L]; continue;
/* XOR (HL)     */  case 0xFFFFFFAE: tstates -=  7; F = SZP_T[A ^= 0x00FF & RDMEM[H][L]]; continue;
/* XOR A        */  case 0xFFFFFFAF: tstates -=  4; F = SZP_T[A = 0]; continue;
//  ----------------------------------------------------------------------------
/* OR B         */  case 0xFFFFFFB0: tstates -=  4; F = SZP_T[A |= B]; continue;
/* OR C         */  case 0xFFFFFFB1: tstates -=  4; F = SZP_T[A |= C]; continue;
/* OR D         */  case 0xFFFFFFB2: tstates -=  4; F = SZP_T[A |= D]; continue;
/* OR E         */  case 0xFFFFFFB3: tstates -=  4; F = SZP_T[A |= E]; continue;
/* OR H         */  case 0xFFFFFFB4: tstates -=  4; F = SZP_T[A |= H]; continue;
/* OR L         */  case 0xFFFFFFB5: tstates -=  4; F = SZP_T[A |= L]; continue;
/* OR {HL}      */  case 0xFFFFFFB6: tstates -=  7; F = SZP_T[A |= 0x00FF & RDMEM[H][L]]; continue;
/* OR A         */  case 0xFFFFFFB7: tstates -=  4; F = SZP_T[A]; continue;
//  ----------------------------------------------------------------------------
/* CP B        !*/  case 0xFFFFFFB8: tstates -=  4; F = SZHVC_SUB_ADD_T[A][B] & 0xFF; continue;
/* CP C        !*/  case 0xFFFFFFB9: tstates -=  4; F = SZHVC_SUB_ADD_T[A][C] & 0xFF; continue;
/* CP D        !*/  case 0xFFFFFFBA: tstates -=  4; F = SZHVC_SUB_ADD_T[A][D] & 0xFF; continue;
/* CP E        !*/  case 0xFFFFFFBB: tstates -=  4; F = SZHVC_SUB_ADD_T[A][E] & 0xFF; continue;
/* CP H        !*/  case 0xFFFFFFBC: tstates -=  4; F = SZHVC_SUB_ADD_T[A][H] & 0xFF; continue;
/* CP L        !*/  case 0xFFFFFFBD: tstates -=  4; F = SZHVC_SUB_ADD_T[A][L] & 0xFF; continue;
/* CP (HL)     !*/  case 0xFFFFFFBE: tstates -=  7; F = SZHVC_SUB_ADD_T[A][0x00FF & RDMEM[H][L]] & 0xFF; continue;
/* CP A        !*/  case 0xFFFFFFBF: tstates -=  4; F = SZHVC_SUB_ADD_T[A][A] & 0xFF; continue;
//  ----------------------------------------------------------------------------
/* RET NZ       */  case 0xFFFFFFC0: if((F & F_Z) == 0) { tstates -= 11; LPC = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } HPC = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } } else tstates -= 5; continue;
/* POP BC       */  case 0xFFFFFFC1: tstates -= 10; C = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } B = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } continue;
/* PUSH BC      */  case 0xFFFFFFC5: tstates -= 11; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)B; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)C; continue;
/* RST 00       */  case 0xFFFFFFC7: tstates -= 11; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)HPC; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)LPC; LPC = HPC = 0; continue;
//  ----------------------------------------------------------------------------
/* RET Z        */  case 0xFFFFFFC8: if((F & F_Z) != 0) { tstates -= 11; LPC = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } HPC = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } } else tstates -= 5; continue;
/* RET          */  case 0xFFFFFFC9: tstates -= 10; LPC = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } HPC = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } continue;
/* prefix CB    */  case 0xFFFFFFCB: tstates -= execute_cb(/*RDMEM, WRMEM*/); continue;
/* RST 08       */  case 0xFFFFFFCF: tstates -= 11; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)HPC; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)LPC; LPC = 0x08; HPC = 0; continue;
//  ----------------------------------------------------------------------------
/* RET NC       */  case 0xFFFFFFD0: if((F & F_C) == 0) { tstates -= 11; LPC = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } HPC = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } } else tstates -= 5; continue;
/* POP DE       */  case 0xFFFFFFD1: tstates -= 10; E = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } D = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } continue;
/* PUSH DE      */  case 0xFFFFFFD5: tstates -= 11; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)D; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)E; continue;
/* RST 10       */  case 0xFFFFFFD7: tstates -= 11; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)HPC; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)LPC; LPC = 0x10; HPC = 0; continue;
//  ----------------------------------------------------------------------------
/* RET C        */  case 0xFFFFFFD8: if((F & F_C) != 0) { tstates -= 11; LPC = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } HPC = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } } else tstates -= 5; continue;
/* EXX          */  case 0xFFFFFFD9: tstates -=  4; { int V0 = B; B = B2; B2 = V0; V0 = C; C = C2; C2 = V0; V0 = D; D = D2; D2 = V0; V0 = E; E = E2; E2 = V0; V0 = H; H = H2; H2 = V0; V0 = L; L = L2; L2 = V0; } continue;
/* prefix DD    */  case 0xFFFFFFDD: 
{    
//  ============================================================================
//  ����� �������� ������ CPU Z80 � ��������� DD    
//  ============================================================================
        OP = RDMEM[HPC][LPC]; if(LPC++ == 0xFF) { LPC = 0x00; HPC = INC[HPC]; }
        switch(OP) {
//  ----------------------------------------------------------------------------
/* LD HX,HX     */  case 0x00000064:
/* LD LX,LX     */  case 0x0000006D: tstates -=  8;
/* ADD IX,BC    */  case 0x00000009: tstates -= 15; { int V0 = HIX << 8 | LIX, V1 = B << 8 | C, V2 = V0 + V1; F = (F & F_SZPV) | (((V0 ^ V2 ^ V1) >> 8) & 0x10) | ((V2 >> 16) & 1); HIX = V2 >> 8 & 0xFF; LIX = V2 & 0xFF; } continue;
/* ADD IX,DE    */  case 0x00000019: tstates -= 15; { int V0 = HIX << 8 | LIX, V1 = D << 8 | E, V2 = V0 + V1; F = (F & F_SZPV) | (((V0 ^ V2 ^ V1) >> 8) & 0x10) | ((V2 >> 16) & 1); HIX = V2 >> 8 & 0xFF; LIX = V2 & 0xFF; } continue;
/* INC IX       */  case 0x00000023: tstates -= 10; if(LIX++ == 0xFF) { LIX = 0x00; HIX = INC[HIX]; } continue;
/* INC HX       */  case 0x00000024: tstates -=  8; F = (F & F_C) | SZHV_INC_T[HIX = INC[HIX]]; continue;
/* DEC HX       */  case 0x00000025: tstates -=  8; F = (F & F_C) | SZHV_DEC_T[HIX = DEC[HIX]]; continue;
/* ADD IX,IX    */  case 0x00000029: tstates -= 15; { int V0 = HIX << 8 | LIX, V1 = V0 << 1; F = (F & F_SZPV) | (((V0 ^ V1 ^ V0) >> 8) & 0x10) | ((V1 >> 16) & 1); HIX = V1 >> 8 & 0xFF; LIX = V1 & 0xFF; } continue;
/* DEC IX       */  case 0x0000002B: tstates -= 10; if(LIX-- == 0x00) { LIX = 0xFF; HIX = DEC[HIX]; } continue;
/* INC LX       */  case 0x0000002C: tstates -=  8; F = (F & F_C) | SZHV_INC_T[LIX = INC[LIX]]; continue;
/* DEC LX       */  case 0x0000002D: tstates -=  8; F = (F & F_C) | SZHV_DEC_T[LIX = DEC[LIX]]; continue;
/* ADD IX,SP    */  case 0x00000039: tstates -= 15; { int V0 = HIX << 8 | LIX, V1 = HSP << 8 | LSP, V2 = V0 + V1; F = (F & F_SZPV) | (((V0 ^ V2 ^ V1) >> 8) & 0x10) | ((V2 >> 16) & 1); HIX = V2 >> 8 & 0xFF; LIX = V2 & 0xFF; } continue;
/* LD B,HX      */  case 0x00000044: tstates -=  8; B = HIX; continue;
/* LD B,LX      */  case 0x00000045: tstates -=  8; B = LIX; continue;
/* LD C,HX      */  case 0x0000004C: tstates -=  8; C = HIX; continue;
/* LD C,LX      */  case 0x0000004D: tstates -=  8; C = LIX; continue;
/* LD D,HX      */  case 0x00000054: tstates -=  8; D = HIX; continue;
/* LD D,LX      */  case 0x00000055: tstates -=  8; D = LIX; continue;
/* LD E,HX      */  case 0x0000005C: tstates -=  8; E = HIX; continue;
/* LD E,LX      */  case 0x0000005D: tstates -=  8; E = LIX; continue;
/* LD HX,B      */  case 0x00000060: tstates -=  8; HIX = B; continue;
/* LD HX,C      */  case 0x00000061: tstates -=  8; HIX = C; continue;
/* LD HX,D      */  case 0x00000062: tstates -=  8; HIX = D; continue;
/* LD HX,E      */  case 0x00000063: tstates -=  8; HIX = E; continue;         
/* LD HX,LX     */  case 0x00000065: tstates -=  8; HIX = LIX; continue;
/* LD HX,A      */  case 0x00000067: tstates -=  8; HIX = A; continue;
/* LD LX,B      */  case 0x00000068: tstates -=  8; LIX = B; continue;
/* LD LX,C      */  case 0x00000069: tstates -=  8; LIX = C; continue;
/* LD LX,D      */  case 0x0000006A: tstates -=  8; LIX = D; continue;
/* LD LX,E      */  case 0x0000006B: tstates -=  8; LIX = E; continue;
/* LD LX,H      */  case 0x0000006C: tstates -=  8; LIX = HIX; continue;
/* LD LX,A      */  case 0x0000006F: tstates -=  8; LIX = A; continue;
/* LD A,HX      */  case 0x0000007C: tstates -=  8; A = HIX; continue;
/* LD A,LX      */  case 0x0000007D: tstates -=  8; A = LIX; continue;
/* ADD A,HY    !*/  case 0xFFFFFF84: tstates -=  8; { int V0 = (char)(SZHVC_SUB_ADD_T[A][HIX] >> 16); F = V0 & 0xFF; A = V0 >> 8; } continue;
/* ADD A,LY    !*/  case 0xFFFFFF85: tstates -=  8; { int V0 = (char)(SZHVC_SUB_ADD_T[A][LIX] >> 16); F = V0 & 0xFF; A = V0 >> 8; } continue;
/* ADC A,HX    !*/  case 0xFFFFFF8C: tstates -=  8; { int V0 = F & F_C, V1 = A + HIX + V0; F = (V1 >> 8) | SZ_T[V1 &= 0xFF] | (((A ^ ~HIX) & (A ^ V1)) >> 5 & F_PV) | ((A & 0xF) + (HIX & 0xF) + V0 & F_H); A = V1; } continue;
/* ADC A,LX    !*/  case 0xFFFFFF8D: tstates -=  8; { int V0 = F & F_C, V1 = A + LIX + V0; F = (V1 >> 8) | SZ_T[V1 &= 0xFF] | (((A ^ ~LIX) & (A ^ V1)) >> 5 & F_PV) | ((A & 0xF) + (LIX & 0xF) + V0 & F_H); A = V1; } continue;
/* SUB HX      !*/  case 0xFFFFFF94: tstates -=  8; { int V0 = (char)SZHVC_SUB_ADD_T[A][HIX]; F = V0 & 0xFF; A = V0 >> 8; } continue;
/* SUB LX      !*/  case 0xFFFFFF95: tstates -=  8; { int V0 = (char)SZHVC_SUB_ADD_T[A][LIX]; F = V0 & 0xFF; A = V0 >> 8; } continue;
/* SBC A,HX    !*/  case 0xFFFFFF9C: tstates -=  8; { int V0 = F & F_C, V1 = A - HIX - V0; F = (V1 >> 8 & F_C) | SZ_T[V1 &= 0xFF] | (((A ^ HIX) & (A ^ V1)) >> 5 & F_PV) | ((A & 0xF) - (HIX & 0xF) - V0 & F_H) | F_N; A = V1; } continue;
/* SBC A,LX    !*/  case 0xFFFFFF9D: tstates -=  8; { int V0 = F & F_C, V1 = A - LIX - V0; F = (V1 >> 8 & F_C) | SZ_T[V1 &= 0xFF] | (((A ^ LIX) & (A ^ V1)) >> 5 & F_PV) | ((A & 0xF) - (LIX & 0xF) - V0 & F_H) | F_N; A = V1; } continue;
/* AND HX       */  case 0xFFFFFFA4: tstates -=  8; F = SZP_T[A &= HIX] | F_H; continue;
/* AND LX       */  case 0xFFFFFFA5: tstates -=  8; F = SZP_T[A &= LIX] | F_H; continue;
/* XOR HX       */  case 0xFFFFFFAC: tstates -=  8; F = SZP_T[A ^= HIX]; continue;
/* XOR LX       */  case 0xFFFFFFAD: tstates -=  8; F = SZP_T[A ^= LIX]; continue;
/* OR HX        */  case 0xFFFFFFB4: tstates -=  8; F = SZP_T[A |= HIX]; continue;
/* OR LX        */  case 0xFFFFFFB5: tstates -=  8; F = SZP_T[A |= LIX]; continue;
/* CP HX       !*/  case 0xFFFFFFBC: tstates -=  8; F = SZHVC_SUB_ADD_T[A][HIX] & 0xFF; continue;
/* CP LX       !*/  case 0xFFFFFFBD: tstates -=  8; F = SZHVC_SUB_ADD_T[A][LIX] & 0xFF; continue;
/* POP IX       */  case 0xFFFFFFE1: tstates -= 14; LIX = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } HIX = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } continue;
/* EX (SP),IX   */  case 0xFFFFFFE3: tstates -= 23; { int V0 = LSP, V1 = HSP, V2 = LIX; LIX = 0x00FF & RDMEM[V1][V0]; WRMEM[V1][V0] = (byte)V2; if(V0++ == 0xFF) { V0 = 0x00; V1 = INC[V1]; } V2 = HIX; HIX = 0x00FF & RDMEM[V1][V0]; WRMEM[V1][V0] = (byte)V2; } continue;
/* PUSH IX      */  case 0xFFFFFFE5: tstates -= 15; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)HIX; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)LIX; continue;
/* JP (IX)     !*/  case 0xFFFFFFE9: tstates -=  8; LPC = LIX; HPC = HIX; continue;
/* LD SP,IX     */  case 0xFFFFFFF9: tstates -=  8; HSP = HIX; LSP = LIX; continue;
//  ----------------------------------------------------------------------------
        }            
        BL = 0x00FF & RDMEM[HPC][LPC];  if(LPC++ == 0xFF) { LPC = 0x00; HPC = INC[HPC]; }
        LAD = LIX + (byte)BL; HAD = (HIX + (LAD >>> 8)) & 0xFF; LAD &= 0xFF;
        switch(OP) {                                
//  ----------------------------------------------------------------------------
/* LD HX,n      */  case 0x00000026: tstates -= 11; HIX = BL; continue;
/* LD LX,n      */  case 0x0000002E: tstates -= 11; LIX = BL; continue;
/* INC (IX+d)   */  case 0x00000034: tstates -= 23; F = (F & F_C) | SZHV_INC_T[0xFF & ++WRMEM[HAD][LAD]]; continue;
/* DEC (IX+d)   */  case 0x00000035: tstates -= 23; F = (F & F_C) | SZHV_DEC_T[0xFF & --WRMEM[HAD][LAD]]; continue;
/* LD B,(IX+d)  */  case 0x00000046: tstates -= 19; B = 0x00FF & RDMEM[HAD][LAD]; continue;
/* LD C,(IX+d)  */  case 0x0000004E: tstates -= 19; C = 0x00FF & RDMEM[HAD][LAD]; continue;
/* LD D,(IX+d)  */  case 0x00000056: tstates -= 19; D = 0x00FF & RDMEM[HAD][LAD]; continue;
/* LD E,(IX+d)  */  case 0x0000005E: tstates -= 19; E = 0x00FF & RDMEM[HAD][LAD]; continue;
/* LD H,(IX+d)  */  case 0x00000066: tstates -= 19; H = 0x00FF & RDMEM[HAD][LAD]; continue;
/* LD L,(IX+d)  */  case 0x0000006E: tstates -= 19; L = 0x00FF & RDMEM[HAD][LAD]; continue;
/* LD (IX+d),B  */  case 0x00000070: tstates -= 19; WRMEM[HAD][LAD] = (byte)B; continue;
/* LD (IX+d),C  */  case 0x00000071: tstates -= 19; WRMEM[HAD][LAD] = (byte)C; continue;
/* LD (IX+d),D  */  case 0x00000072: tstates -= 19; WRMEM[HAD][LAD] = (byte)D; continue;
/* LD (IX+d),E  */  case 0x00000073: tstates -= 19; WRMEM[HAD][LAD] = (byte)E; continue;
/* LD (IX+d),H  */  case 0x00000074: tstates -= 19; WRMEM[HAD][LAD] = (byte)H; continue;
/* LD (IX+d),L  */  case 0x00000075: tstates -= 19; WRMEM[HAD][LAD] = (byte)L; continue;
/* LD (IX+d),A  */  case 0x00000077: tstates -= 19; WRMEM[HAD][LAD] = (byte)A; continue;
/* LD A,(IX+d)  */  case 0x0000007E: tstates -= 19; A = 0x00FF & RDMEM[HAD][LAD]; continue;
/* ADD A,(IX+d)!*/  case 0xFFFFFF86: tstates -= 19; { int V0 = (char)(SZHVC_SUB_ADD_T[A][0x00FF & RDMEM[HAD][LAD]] >> 16); F = V0 & 0xFF; A = V0 >> 8; } continue;
/* ADC A,(IX+d)!*/  case 0xFFFFFF8E: tstates -= 19; { int V0 = 0x00FF & RDMEM[HAD][LAD], V1 = F & F_C, V2 = A + V0 + V1; F = (V2 >> 8) | SZ_T[V2 &= 0xFF] | (((A ^ ~V0) & (A ^ V2)) >> 5 & F_PV) | ((A & 0xF) + (V0 & 0xF) + V1 & F_H); A = V2; } continue;
/* SUB (IX+d)  !*/  case 0xFFFFFF96: tstates -= 19; { int V0 = (char)SZHVC_SUB_ADD_T[A][0x00FF & RDMEM[HAD][LAD]]; F = V0 & 0xFF; A = V0 >> 8; } continue;
/* SBC A,(IX+d)!*/  case 0xFFFFFF9E: tstates -= 19; { int V0 = 0x00FF & RDMEM[HAD][LAD], V1 = F & F_C, V2 = A - V0 - V1; F = (V2 >> 8 & F_C) | SZ_T[V2 &= 0xFF] | (((A ^ V0) & (A ^ V2)) >> 5 & F_PV) | ((A & 0xF) - (V0 & 0xF) - V1 & F_H) | F_N; A = V2; } continue;
/* AND (IX+d)   */  case 0xFFFFFFA6: tstates -= 19; F = SZP_T[A &= 0x00FF & RDMEM[HAD][LAD]] | F_H; continue;
/* XOR (IX+d)   */  case 0xFFFFFFAE: tstates -= 19; F = SZP_T[A ^= 0x00FF & RDMEM[HAD][LAD]]; continue;
/* OR (IX+d)    */  case 0xFFFFFFB6: tstates -= 19; F = SZP_T[A |= 0x00FF & RDMEM[HAD][LAD]]; continue;
/* CP (IX+d)   !*/  case 0xFFFFFFBE: tstates -= 19; F = SZHVC_SUB_ADD_T[A][0x00FF & RDMEM[HAD][LAD]] & 0xFF; continue;
/* prefix CB    */  case 0xFFFFFFCB: tstates -= execute_dd_fd_cb(LAD, HAD); continue;
//  ----------------------------------------------------------------------------
        }            
        BH = 0x00FF & RDMEM[HPC][LPC]; if(LPC++ == 0xFF) { LPC = 0x00; HPC = INC[HPC]; }
        switch(OP) {
//  ----------------------------------------------------------------------------
/* LD IX,nn     */  case 0x00000021: tstates -= 14; LIX = BL; HIX = BH; continue;
/* LD (nn),IX   */  case 0x00000022: tstates -= 20; WRMEM[BH][BL] = (byte)LIX; if(BL == 0xFF) WRMEM[INC[BH]][0] = (byte)HIX; else WRMEM[BH][++BL] = (byte)HIX; continue;
/* LD IX,(nn)   */  case 0x0000002A: tstates -= 20; LIX = 0x00FF & RDMEM[BH][BL]; HIX = BL == 0xFF ? 0x00FF & RDMEM[INC[BH]][0] : 0x00FF & RDMEM[BH][++BL]; continue;
/* LD (IX+d),n  */  case 0x00000036: tstates -= 19; WRMEM[HAD][LAD] = (byte)BH; continue;
//  ----------------------------------------------------------------------------
        }
        tstates -=  4; if((LPC -= 3) < 0) { LPC &= 0xFF; HPC = DEC[HPC]; } continue;
//  ============================================================================
}
/* RST 18       */  case 0xFFFFFFDF: tstates -= 11; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)HPC; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)LPC; LPC = 0x18; HPC = 0; continue;
//  ----------------------------------------------------------------------------
/* RET PO       */  case 0xFFFFFFE0: if((F & F_PV) == 0) { tstates -= 11; LPC = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } HPC = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } } else tstates -= 5; continue;
/* POP HL       */  case 0xFFFFFFE1: tstates -= 10; L = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } H = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } continue;
/* EX (SP),HL   */  case 0xFFFFFFE3: tstates -= 19; { int V0 = LSP, V1 = HSP, V2 = L; L = 0x00FF & RDMEM[V1][V0]; WRMEM[V1][V0] = (byte)V2; if(V0++ == 0xFF) { V0 = 0x00; V1 = INC[V1]; } V2 = H; H = 0x00FF & RDMEM[V1][V0]; WRMEM[V1][V0] = (byte)V2; } continue;
/* PUSH HL      */  case 0xFFFFFFE5: tstates -= 11; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)H; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)L; continue;
/* RST 20       */  case 0xFFFFFFE7: tstates -= 11; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)HPC; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)LPC; LPC = 0x20; HPC = 0; continue;
//  ----------------------------------------------------------------------------
/* RET PE       */  case 0xFFFFFFE8: if((F & F_PV) != 0) { tstates -= 11; LPC = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } HPC = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } } else tstates -= 5; continue;
/* JP (HL)     !*/  case 0xFFFFFFE9: tstates -=  4; LPC = L; HPC = H; continue;
/* EX DE,HL     */  case 0xFFFFFFEB: tstates -=  4; { int V0 = D; D = H; H = V0; V0 = E; E = L; L = V0; } continue;
/* prefix ED    */  case 0xFFFFFFED: tstates -= execute_ed(); continue;
/* RST 28       */  case 0xFFFFFFEF: tstates -= 11; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)HPC; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)LPC; LPC = 0x28; HPC = 0; continue;
//  ----------------------------------------------------------------------------
/* RET P        */  case 0xFFFFFFF0: if((F & F_S) == 0) { tstates -= 11; LPC = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } HPC = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } } else tstates -= 5; continue;
/* POP AF       */  case 0xFFFFFFF1: tstates -= 10; F = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } A = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } continue;
/* DI           */  case 0xFFFFFFF3: tstates -=  4; IFF1 = IFF2 = false; continue;
/* PUSH AF      */  case 0xFFFFFFF5: tstates -= 11; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)A; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)F; continue;
/* RST 30       */  case 0xFFFFFFF7: tstates -= 11; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)HPC; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)LPC; LPC = 0x30; HPC = 0; continue;
//  ----------------------------------------------------------------------------
/* RET M        */  case 0xFFFFFFF8: if((F & F_S) != 0) { tstates -= 11; LPC = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } HPC = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } } else tstates -= 5; continue;
/* LD SP,HL     */  case 0xFFFFFFF9: tstates -=  6; HSP = H; LSP = L; continue;
/* EI           */  case 0xFFFFFFFB: tstates -=  4; IFF1 = IFF2 = true; continue;
/* prefix FD    */  case 0xFFFFFFFD:
{    
//  ============================================================================
//  ����� �������� ������ CPU Z80 � ��������� FD    
//  ============================================================================
        OP = RDMEM[HPC][LPC]; if(LPC++ == 0xFF) { LPC = 0x00; HPC = INC[HPC]; }
        switch(OP) {
//  ----------------------------------------------------------------------------
/* LD HY,HY     */  case 0x00000064:
/* LD LY,LY     */  case 0x0000006D: tstates -=  8;
/* ADD IY,BC    */  case 0x00000009: tstates -= 15; { int V0 = HIY << 8 | LIY, V1 = B << 8 | C, V2 = V0 + V1; F = (F & F_SZPV) | (((V0 ^ V2 ^ V1) >> 8) & 0x10) | ((V2 >> 16) & 1); HIY = V2 >> 8 & 0xFF; LIY = V2 & 0xFF; } continue;
/* ADD IY,DE    */  case 0x00000019: tstates -= 15; { int V0 = HIY << 8 | LIY, V1 = D << 8 | E, V2 = V0 + V1; F = (F & F_SZPV) | (((V0 ^ V2 ^ V1) >> 8) & 0x10) | ((V2 >> 16) & 1); HIY = V2 >> 8 & 0xFF; LIY = V2 & 0xFF; } continue;
/* INC IY       */  case 0x00000023: tstates -= 10; if(LIY++ == 0xFF) { LIY = 0x00; HIY = INC[HIY]; } continue;
/* INC HY       */  case 0x00000024: tstates -=  8; F = (F & F_C) | SZHV_INC_T[HIY = INC[HIY]]; continue;
/* DEC HY       */  case 0x00000025: tstates -=  8; F = (F & F_C) | SZHV_DEC_T[HIY = DEC[HIY]]; continue;
/* ADD IY,IY    */  case 0x00000029: tstates -= 15; { int V0 = HIY << 8 | LIY, V1 = V0 << 1; F = (F & F_SZPV) | (((V0 ^ V1 ^ V0) >> 8) & 0x10) | ((V1 >> 16) & 1); HIY = V1 >> 8 & 0xFF; LIY = V1 & 0xFF; } continue;
/* DEC IY       */  case 0x0000002B: tstates -= 10; if(LIY-- == 0x00) { LIY = 0xFF; HIY = DEC[HIY]; } continue;
/* INC LY       */  case 0x0000002C: tstates -=  8; F = (F & F_C) | SZHV_INC_T[LIY = INC[LIY]]; continue;
/* DEC LY       */  case 0x0000002D: tstates -=  8; F = (F & F_C) | SZHV_DEC_T[LIY = DEC[LIY]]; continue;
/* ADD IY,SP    */  case 0x00000039: tstates -= 15; { int V0 = HIY << 8 | LIY, V1 = HSP << 8 | LSP, V2 = V0 + V1; F = (F & F_SZPV) | (((V0 ^ V2 ^ V1) >> 8) & 0x10) | ((V2 >> 16) & 1); HIY = V2 >> 8 & 0xFF; LIY = V2 & 0xFF; } continue;
/* LD B,HY      */  case 0x00000044: tstates -=  8; B = HIY; continue;
/* LD B,LY      */  case 0x00000045: tstates -=  8; B = LIY; continue;
/* LD C,HY      */  case 0x0000004C: tstates -=  8; C = HIY; continue;
/* LD C,LY      */  case 0x0000004D: tstates -=  8; C = LIY; continue;
/* LD D,HY      */  case 0x00000054: tstates -=  8; D = HIY; continue;
/* LD D,LY      */  case 0x00000055: tstates -=  8; D = LIY; continue;
/* LD E,HY      */  case 0x0000005C: tstates -=  8; E = HIY; continue;
/* LD E,LY      */  case 0x0000005D: tstates -=  8; E = LIY; continue;
/* LD HY,B      */  case 0x00000060: tstates -=  8; HIY = B; continue;
/* LD HY,C      */  case 0x00000061: tstates -=  8; HIY = C; continue;
/* LD HY,D      */  case 0x00000062: tstates -=  8; HIY = D; continue;
/* LD HY,E      */  case 0x00000063: tstates -=  8; HIY = E; continue;         
/* LD HY,LY     */  case 0x00000065: tstates -=  8; HIY = LIY; continue;
/* LD HY,A      */  case 0x00000067: tstates -=  8; HIY = A; continue;
/* LD LY,B      */  case 0x00000068: tstates -=  8; LIY = B; continue;
/* LD LY,C      */  case 0x00000069: tstates -=  8; LIY = C; continue;
/* LD LY,D      */  case 0x0000006A: tstates -=  8; LIY = D; continue;
/* LD LY,E      */  case 0x0000006B: tstates -=  8; LIY = E; continue;
/* LD LY,H      */  case 0x0000006C: tstates -=  8; LIY = HIY; continue;
/* LD LY,A      */  case 0x0000006F: tstates -=  8; LIY = A; continue;
/* LD A,HY      */  case 0x0000007C: tstates -=  8; A = HIY; continue;
/* LD A,LY      */  case 0x0000007D: tstates -=  8; A = LIY; continue;
/* ADD A,HY    !*/  case 0xFFFFFF84: tstates -=  8; { int V0 = (char)(SZHVC_SUB_ADD_T[A][HIY] >> 16); F = V0 & 0xFF; A = V0 >> 8; } continue;
/* ADD A,LY    !*/  case 0xFFFFFF85: tstates -=  8; { int V0 = (char)(SZHVC_SUB_ADD_T[A][LIY] >> 16); F = V0 & 0xFF; A = V0 >> 8; } continue;
/* ADC A,HY    !*/  case 0xFFFFFF8C: tstates -=  8; { int V0 = F & F_C, V1 = A + HIY + V0; F = (V1 >> 8) | SZ_T[V1 &= 0xFF] | (((A ^ ~HIY) & (A ^ V1)) >> 5 & F_PV) | ((A & 0xF) + (HIY & 0xF) + V0 & F_H); A = V1; } continue;
/* ADC A,LY    !*/  case 0xFFFFFF8D: tstates -=  8; { int V0 = F & F_C, V1 = A + LIY + V0; F = (V1 >> 8) | SZ_T[V1 &= 0xFF] | (((A ^ ~LIY) & (A ^ V1)) >> 5 & F_PV) | ((A & 0xF) + (LIY & 0xF) + V0 & F_H); A = V1; } continue;
/* SUB HY      !*/  case 0xFFFFFF94: tstates -=  8; { int V0 = (char)SZHVC_SUB_ADD_T[A][HIY]; F = V0 & 0xFF; A = V0 >> 8; } continue;
/* SUB LY      !*/  case 0xFFFFFF95: tstates -=  8; { int V0 = (char)SZHVC_SUB_ADD_T[A][LIY]; F = V0 & 0xFF; A = V0 >> 8; } continue;
/* SBC A,HY    !*/  case 0xFFFFFF9C: tstates -=  8; { int V0 = F & F_C, V1 = A - HIY - V0; F = (V1 >> 8 & F_C) | SZ_T[V1 &= 0xFF] | (((A ^ HIY) & (A ^ V1)) >> 5 & F_PV) | ((A & 0xF) - (HIY & 0xF) - V0 & F_H) | F_N; A = V1; } continue;
/* SBC A,LY    !*/  case 0xFFFFFF9D: tstates -=  8; { int V0 = F & F_C, V1 = A - LIY - V0; F = (V1 >> 8 & F_C) | SZ_T[V1 &= 0xFF] | (((A ^ LIY) & (A ^ V1)) >> 5 & F_PV) | ((A & 0xF) - (LIY & 0xF) - V0 & F_H) | F_N; A = V1; } continue;
/* AND HY       */  case 0xFFFFFFA4: tstates -=  8; F = SZP_T[A &= HIY] | F_H; continue;
/* AND LY       */  case 0xFFFFFFA5: tstates -=  8; F = SZP_T[A &= LIY] | F_H; continue;
/* XOR HY       */  case 0xFFFFFFAC: tstates -=  8; F = SZP_T[A ^= HIY]; continue;
/* XOR LY       */  case 0xFFFFFFAD: tstates -=  8; F = SZP_T[A ^= LIY]; continue;
/* OR HY        */  case 0xFFFFFFB4: tstates -=  8; F = SZP_T[A |= HIY]; continue;
/* OR LY        */  case 0xFFFFFFB5: tstates -=  8; F = SZP_T[A |= LIY]; continue;
/* CP HY       !*/  case 0xFFFFFFBC: tstates -=  8; F = SZHVC_SUB_ADD_T[A][HIY] & 0xFF; continue;
/* CP LY       !*/  case 0xFFFFFFBD: tstates -=  8; F = SZHVC_SUB_ADD_T[A][LIY] & 0xFF; continue;
/* POP IY       */  case 0xFFFFFFE1: tstates -= 14; LIY = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } HIY = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } continue;
/* EX (SP),IY   */  case 0xFFFFFFE3: tstates -= 23; { int V0 = LSP, V1 = HSP, V2 = LIY; LIY = 0x00FF & RDMEM[V1][V0]; WRMEM[V1][V0] = (byte)V2; if(V0++ == 0xFF) { V0 = 0x00; V1 = INC[V1]; } V2 = HIY; HIY = 0x00FF & RDMEM[V1][V0]; WRMEM[V1][V0] = (byte)V2; } continue;
/* PUSH IY      */  case 0xFFFFFFE5: tstates -= 15; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)HIY; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)LIY; continue;
/* JP (IY)     !*/  case 0xFFFFFFE9: tstates -=  8; LPC = LIY; HPC = HIY; continue;
/* LD SP,IY     */  case 0xFFFFFFF9: tstates -=  8; HSP = HIY; LSP = LIY; continue;
//  ----------------------------------------------------------------------------
        }            
        BL = 0x00FF & RDMEM[HPC][LPC];  if(LPC++ == 0xFF) { LPC = 0x00; HPC = INC[HPC]; }
        LAD = LIY + (byte)BL; HAD = (HIY + (LAD >>> 8)) & 0xFF; LAD &= 0xFF;
        switch(OP) {                                
//  ----------------------------------------------------------------------------
/* LD HY,n      */  case 0x00000026: tstates -= 11; HIY = BL; continue;
/* LD LY,n      */  case 0x0000002E: tstates -= 11; LIY = BL; continue;
/* INC (IY+d)   */  case 0x00000034: tstates -= 23; F = (F & F_C) | SZHV_INC_T[0xFF & ++WRMEM[HAD][LAD]]; continue;
/* DEC (IY+d)   */  case 0x00000035: tstates -= 23; F = (F & F_C) | SZHV_DEC_T[0xFF & --WRMEM[HAD][LAD]]; continue;
/* LD B,(IY+d)  */  case 0x00000046: tstates -= 19; B = 0x00FF & RDMEM[HAD][LAD]; continue;
/* LD C,(IY+d)  */  case 0x0000004E: tstates -= 19; C = 0x00FF & RDMEM[HAD][LAD]; continue;
/* LD D,(IY+d)  */  case 0x00000056: tstates -= 19; D = 0x00FF & RDMEM[HAD][LAD]; continue;
/* LD E,(IY+d)  */  case 0x0000005E: tstates -= 19; E = 0x00FF & RDMEM[HAD][LAD]; continue;
/* LD H,(IY+d)  */  case 0x00000066: tstates -= 19; H = 0x00FF & RDMEM[HAD][LAD]; continue;
/* LD L,(IY+d)  */  case 0x0000006E: tstates -= 19; L = 0x00FF & RDMEM[HAD][LAD]; continue;
/* LD (IY+d),B  */  case 0x00000070: tstates -= 19; WRMEM[HAD][LAD] = (byte)B; continue;
/* LD (IY+d),C  */  case 0x00000071: tstates -= 19; WRMEM[HAD][LAD] = (byte)C; continue;
/* LD (IY+d),D  */  case 0x00000072: tstates -= 19; WRMEM[HAD][LAD] = (byte)D; continue;
/* LD (IY+d),E  */  case 0x00000073: tstates -= 19; WRMEM[HAD][LAD] = (byte)E; continue;
/* LD (IY+d),H  */  case 0x00000074: tstates -= 19; WRMEM[HAD][LAD] = (byte)H; continue;
/* LD (IY+d),L  */  case 0x00000075: tstates -= 19; WRMEM[HAD][LAD] = (byte)L; continue;
/* LD (IY+d),A  */  case 0x00000077: tstates -= 19; WRMEM[HAD][LAD] = (byte)A; continue;
/* LD A,(IY+d)  */  case 0x0000007E: tstates -= 19; A = 0x00FF & RDMEM[HAD][LAD]; continue;
/* ADD A,(IY+d)!*/  case 0xFFFFFF86: tstates -= 19; { int V0 = (char)(SZHVC_SUB_ADD_T[A][0x00FF & RDMEM[HAD][LAD]] >> 16); F = V0 & 0xFF; A = V0 >> 8; } continue;
/* ADC A,(IY+d)!*/  case 0xFFFFFF8E: tstates -= 19; { int V0 = 0x00FF & RDMEM[HAD][LAD], V1 = F & F_C, V2 = A + V0 + V1; F = (V2 >> 8) | SZ_T[V2 &= 0xFF] | (((A ^ ~V0) & (A ^ V2)) >> 5 & F_PV) | ((A & 0xF) + (V0 & 0xF) + V1 & F_H); A = V2; } continue;
/* SUB (IY+d)  !*/  case 0xFFFFFF96: tstates -= 19; { int V0 = (char)SZHVC_SUB_ADD_T[A][0x00FF & RDMEM[HAD][LAD]]; F = V0 & 0xFF; A = V0 >> 8; } continue;
/* SBC A,(IY+d)!*/  case 0xFFFFFF9E: tstates -= 19; { int V0 = 0x00FF & RDMEM[HAD][LAD], V1 = F & F_C, V2 = A - V0 - V1; F = (V2 >> 8 & F_C) | SZ_T[V2 &= 0xFF] | (((A ^ V0) & (A ^ V2)) >> 5 & F_PV) | ((A & 0xF) - (V0 & 0xF) - V1 & F_H) | F_N; A = V2; } continue;
/* AND (IY+d)   */  case 0xFFFFFFA6: tstates -= 19; F = SZP_T[A &= 0x00FF & RDMEM[HAD][LAD]] | F_H; continue;
/* XOR (IY+d)   */  case 0xFFFFFFAE: tstates -= 19; F = SZP_T[A ^= 0x00FF & RDMEM[HAD][LAD]]; continue;
/* OR (IY+d)    */  case 0xFFFFFFB6: tstates -= 19; F = SZP_T[A |= 0x00FF & RDMEM[HAD][LAD]]; continue;
/* CP (IY+d)   !*/  case 0xFFFFFFBE: tstates -= 19; F = SZHVC_SUB_ADD_T[A][0x00FF & RDMEM[HAD][LAD]] & 0xFF; continue;
/* prefix CB    */  case 0xFFFFFFCB: tstates -= execute_dd_fd_cb(LAD, HAD); continue;
//  ----------------------------------------------------------------------------
        }            
        BH = 0x00FF & RDMEM[HPC][LPC]; if(LPC++ == 0xFF) { LPC = 0x00; HPC = INC[HPC]; }
        switch(OP) {
//  ----------------------------------------------------------------------------
/* LD IY,nn     */  case 0x00000021: tstates -= 14; LIY = BL; HIY = BH; continue;
/* LD (nn),IY   */  case 0x00000022: tstates -= 20; WRMEM[BH][BL] = (byte)LIY; if(BL == 0xFF) WRMEM[INC[BH]][0] = (byte)HIY; else WRMEM[BH][++BL] = (byte)HIY; continue;
/* LD IY,(nn)   */  case 0x0000002A: tstates -= 20; LIY = 0x00FF & RDMEM[BH][BL]; HIY = BL == 0xFF ? 0x00FF & RDMEM[INC[BH]][0] : 0x00FF & RDMEM[BH][++BL]; continue;
/* LD (IY+d),n  */  case 0x00000036: tstates -= 19; WRMEM[HAD][LAD] = (byte)BH; continue;
//  ----------------------------------------------------------------------------
        }
        tstates -=  4; if((LPC -= 3) < 0) { LPC &= 0xFF; HPC = DEC[HPC]; } continue;
//  ============================================================================
}
/* RST 38       */  case 0xFFFFFFFF: tstates -= 11; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)HPC; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)LPC; LPC = 0x38; HPC = 0; continue;
//  ----------------------------------------------------------------------------
            }
            BL = 0x00FF & RDMEM[HPC][LPC]; if(LPC++ == 0xFF) { LPC = 0x00; HPC = INC[HPC]; }
            switch(OP) {
//  ----------------------------------------------------------------------------
/* LD B,n       */  case 0x00000006: tstates -=  7; B = BL; continue;
/* LD C,n       */  case 0x0000000E: tstates -=  7; C = BL; continue;
/* DJNZ d       */  case 0x00000010: if((B = DEC[B]) != 0) { tstates -= 13; HPC += (LPC+= (byte)BL) >>> 8; HPC &= 0xFF; LPC &= 0xFF; } else tstates -= 8; continue;
/* LD D,n       */  case 0x00000016: tstates -=  7; D = BL; continue;
/* JR d         */  case 0x00000018: tstates -= 12; HPC += (LPC+= (byte)BL) >>> 8; HPC &= 0xFF; LPC &= 0xFF;; continue;
/* LD E,n       */  case 0x0000001E: tstates -=  7; E = BL; continue;
/* JR NZ,d      */  case 0x00000020: if((F & F_Z) == 0) { tstates -= 12; HPC += (LPC+= (byte)BL) >>> 8; HPC &= 0xFF; LPC &= 0xFF;; } else tstates -= 7; continue;
/* LD H,n       */  case 0x00000026: tstates -=  7; H = BL; continue;
/* JR Z,d       */  case 0x00000028: if((F & F_Z) != 0) { tstates -= 12; HPC += (LPC+= (byte)BL) >>> 8; HPC &= 0xFF; LPC &= 0xFF;; } else tstates -= 7; continue;
/* LD L,n       */  case 0x0000002E: tstates -=  7; L = BL; continue;
/* JR NC,d      */  case 0x00000030: if((F & F_C) == 0) { tstates -= 12; HPC += (LPC+= (byte)BL) >>> 8; HPC &= 0xFF; LPC &= 0xFF;; } else tstates -= 7; continue;
/* LD (HL),n    */  case 0x00000036: tstates -= 10; WRMEM[H][L] = (byte)BL; continue;
/* JR C,d       */  case 0x00000038: if((F & F_C) != 0) { tstates -= 12; HPC += (LPC+= (byte)BL) >>> 8; HPC &= 0xFF; LPC &= 0xFF;; } else tstates -= 7; continue;
/* LD A,n       */  case 0x0000003E: tstates -=  7; A = BL; continue;
/* ADD A,n     !*/  case 0xFFFFFFC6: tstates -=  7; { int V0 = (char)(SZHVC_SUB_ADD_T[A][BL] >> 16); F = V0 & 0xFF; A = V0 >> 8; } continue;
/* ADC A,n     !*/  case 0xFFFFFFCE: tstates -=  7; { int V0 = F & F_C; int V1 = A + BL + V0; F = (V1 >> 8) | SZ_T[V1 &= 0xFF] | (((A ^ ~BL) & (A ^ V1)) >> 5 & F_PV) | ((A & 0xF) + (BL & 0xF) + V0 & F_H); A = V1; } continue;
/* OUT (n),A    */  case 0xFFFFFFD3: tstates -= 11; WRPORT(A << 8 | BL, A); continue;
/* SUB n       !*/  case 0xFFFFFFD6: tstates -=  7; { int V0 = (char)SZHVC_SUB_ADD_T[A][BL]; F = V0 & 0xFF; A = V0 >> 8; } continue;
/* IN A,(n)    !*/  case 0xFFFFFFDB: tstates -= 11; A = RDPORT(A << 8 | BL); continue;
/* SBC A,n     !*/  case 0xFFFFFFDE: tstates -=  7; { int V0 = F & F_C; int V1 = A - BL - V0; F = (V1 >> 8 & F_C) | SZ_T[V1 &= 0xFF] | (((A ^ BL) & (A ^ V1)) >> 5 & F_PV) | ((A & 0xF) - (BL & 0xF) - V0 & F_H) | F_N; A = V1; } continue;
/* AND n        */  case 0xFFFFFFE6: tstates -=  7; F = SZP_T[A &= BL] | F_H; continue;
/* XOR n        */  case 0xFFFFFFEE: tstates -=  7; F = SZP_T[A ^= BL]; continue;
/* OR n         */  case 0xFFFFFFF6: tstates -=  7; F = SZP_T[A |= BL]; continue;
/* CP n        !*/  case 0xFFFFFFFE: tstates -=  7; F = SZHVC_SUB_ADD_T[A][BL] & 0xFF; continue;
//  ----------------------------------------------------------------------------
            }
            BH = 0x00FF & RDMEM[HPC][LPC]; if(LPC++ == 0xFF) { LPC = 0x00; HPC = INC[HPC]; }
            switch(OP) {
//  ----------------------------------------------------------------------------
/* LD BC,nn     */  case 0x00000001: tstates -= 10; C = BL; B = BH; continue;
/* LD DE,nn     */  case 0x00000011: tstates -= 10; E = BL; D = BH; continue;
/* LD HL,nn     */  case 0x00000021: tstates -= 10; L = BL; H = BH; continue;
/* LD (nn),HL   */  case 0x00000022: tstates -= 16; WRMEM[BH][BL] = (byte)L; if(BL == 0xFF) WRMEM[INC[BH]][0] = (byte)H; else WRMEM[BH][++BL] = (byte)H; continue;
/* LD HL,(nn)   */  case 0x0000002A: tstates -= 16; L = 0x00FF & RDMEM[BH][BL]; H = BL == 0xFF ? 0x00FF & RDMEM[INC[BH]][0] : 0x00FF & RDMEM[BH][++BL]; continue;
/* LD SP,nn     */  case 0x00000031: tstates -= 10; LSP = BL; HSP = BH; continue;
/* LD (nn),A    */  case 0x00000032: tstates -= 13; WRMEM[BH][BL] = (byte)A; continue;
/* LD A,(nn)    */  case 0x0000003A: tstates -= 13; A = 0x00FF & RDMEM[BH][BL]; continue;
//  ----------------------------------------------------------------------------        
/* JP NZ,nn     */  case 0xFFFFFFC2: tstates -= 10; if((F & F_Z) == 0) { LPC = BL; HPC = BH; } continue;
/* JP nn        */  case 0xFFFFFFC3: tstates -= 10; LPC = BL; HPC = BH; continue;
/* CALL NZ,nn   */  case 0xFFFFFFC4: if((F & F_Z ) == 0) { tstates -= 17; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)HPC; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)LPC; LPC = BL; HPC = BH; } else tstates -= 10; continue;
//  ----------------------------------------------------------------------------
/* JP Z,nn      */  case 0xFFFFFFCA: tstates -= 10; if((F & F_Z) != 0) { LPC = BL; HPC = BH; } continue;
/* CALL Z,nn    */  case 0xFFFFFFCC: if((F & F_Z ) != 0) { tstates -= 17; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)HPC; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)LPC; LPC = BL; HPC = BH; } else tstates -= 10; continue;
/* CALL nn      */  case 0xFFFFFFCD: tstates -= 17; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)HPC; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)LPC; LPC = BL; HPC = BH; continue;
//  ----------------------------------------------------------------------------
/* JP NC,nn     */  case 0xFFFFFFD2: tstates -= 10; if((F & F_C) == 0) { LPC = BL; HPC = BH; } continue;
/* CALL NC,nn   */  case 0xFFFFFFD4: if((F & F_C ) == 0) { tstates -= 17; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)HPC; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)LPC; LPC = BL; HPC = BH; } else tstates -= 10; continue;
//  ----------------------------------------------------------------------------
/* JP C,nn      */  case 0xFFFFFFDA: tstates -= 10; if((F & F_C) != 0) { LPC = BL; HPC = BH; } continue;
/* CALL C,nn    */  case 0xFFFFFFDC: if((F & F_C ) != 0) { tstates -= 17; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)HPC; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)LPC; LPC = BL; HPC = BH; } else tstates -= 10; continue;
//  ----------------------------------------------------------------------------
/* JP PO,nn     */  case 0xFFFFFFE2: tstates -= 10; if((F & F_PV) == 0) { LPC = BL; HPC = BH; } continue;
/* CALL PO,nn   */  case 0xFFFFFFE4: if((F & F_PV) == 0) { tstates -= 17; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)HPC; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)LPC; LPC = BL; HPC = BH; } else tstates -= 10; continue;
//  ----------------------------------------------------------------------------
/* JP PE,nn     */  case 0xFFFFFFEA: tstates -= 10; if((F & F_PV) != 0) { LPC = BL; HPC = BH; } continue;
/* CALL PE,nn   */  case 0xFFFFFFEC: if((F & F_PV) != 0) { tstates -= 17; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)HPC; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)LPC; LPC = BL; HPC = BH; } else tstates -= 10; continue;
//  ----------------------------------------------------------------------------
/* JP P,nn      */  case 0xFFFFFFF2: tstates -= 10; if((F & F_S) == 0) { LPC = BL; HPC = BH; } continue;
/* CALL P,nn    */  case 0xFFFFFFF4: if((F & F_S ) == 0) { tstates -= 17; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)HPC; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)LPC; LPC = BL; HPC = BH; } else tstates -= 10; continue;
//  ----------------------------------------------------------------------------
/* JP M,nn      */  case 0xFFFFFFFA: tstates -= 10; if((F & F_S) != 0) { LPC = BL; HPC = BH; } continue;
/* CALL M,nn    */  case 0xFFFFFFFC: if((F & F_S ) != 0) { tstates -= 17; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)HPC; if(LSP-- == 0x00) { LSP = 0xFF; HSP = DEC[HSP]; } WRMEM[HSP][LSP] = (byte)LPC; LPC = BL; HPC = BH; } else tstates -= 10; continue;
//  ----------------------------------------------------------------------------
            }
        }   // end for...    
    }        




//  ============================================================================
//  ����� �������� ������ CPU Z80 � ��������� DD/FD+CB    
//  ============================================================================
    private final int execute_dd_fd_cb(/*byte[][] RDMEM, byte[][] WRMEM,*/ int LAD, int HAD) {
//  - ���������� �������� ���������� ����������� ������������������� �������
//  - � ����� � ��������� ������ �� ��� byte ���������� ������������ ����� �������       
        int OP = RDMEM[HPC][LPC]; if(LPC++ == 0xFF) { LPC = 0x00; HPC = INC[HPC]; }
        switch(OP) {
//  ----------------------------------------------------------------------------            
/* RLC (index)  */  case 0x00000006: { int V0 = 0x00FF & RDMEM[HAD][LAD]; F = V0 >> 7 | SZP_T[V0 = RLC[V0]]; WRMEM[HAD][LAD] = (byte)V0; } return 23;
/* RRC (index)  */  case 0x0000000E: { int V0 = 0x00FF & RDMEM[HAD][LAD]; F = V0 & 1  | SZP_T[V0 = RRC[V0]]; WRMEM[HAD][LAD] = (byte)V0; } return 23;
/* RL  (index)  */  case 0x00000016: { int V0 = 0x00FF & RDMEM[HAD][LAD]; F = V0 >> 7 | SZP_T[V0 = (V0 << 1 | (F & F_C)) & 0xFF]; WRMEM[HAD][LAD] = (byte)V0; } return 23;
/* RR  (index)  */  case 0x0000001E: { int V0 = 0x00FF & RDMEM[HAD][LAD]; F = V0 & 1  | SZP_T[V0 = (V0 >> 1 | F << 7) & 0xFF]; WRMEM[HAD][LAD] = (byte)V0; } return 23;
/* SLA (index)  */  case 0x00000026: { int V0 = 0x00FF & RDMEM[HAD][LAD]; F = V0 >> 7 | SZP_T[V0 = V0 << 1 & 0xFF]; WRMEM[HAD][LAD] = (byte)V0; } return 23;
/* SRA (index)  */  case 0x0000002E: { int V0 = 0x00FF & RDMEM[HAD][LAD]; F = V0 & 1  | SZP_T[V0 = V0 >> 1 | (V0 & 0x80)]; WRMEM[HAD][LAD] = (byte)V0; } return 23;
/* SLL (index)  */  case 0x00000036: { int V0 = 0x00FF & RDMEM[HAD][LAD]; F = V0 >> 7 | SZP_T[V0 = (V0 << 1 | 0x01) & 0xFF]; WRMEM[HAD][LAD] = (byte)V0; } return 23;
/* SRL (index)  */  case 0x0000003E: { int V0 = 0x00FF & RDMEM[HAD][LAD]; F = V0 & 1  | SZP_T[V0 >>= 1]; WRMEM[HAD][LAD] = (byte)V0; } return 23;
//  ----------------------------------------------------------------------------
/* BIT 0,(index)*/  case 0x00000046: F = (F & F_C) | ((0x01 & RDMEM[HAD][LAD]) == 0 ? F_ZHPV : F_H ); return 20;
/* BIT 1,(index)*/  case 0x0000004E: F = (F & F_C) | ((0x02 & RDMEM[HAD][LAD]) == 0 ? F_ZHPV : F_H ); return 20;
/* BIT 2,(index)*/  case 0x00000056: F = (F & F_C) | ((0x04 & RDMEM[HAD][LAD]) == 0 ? F_ZHPV : F_H ); return 20;
/* BIT 3,(index)*/  case 0x0000005E: F = (F & F_C) | ((0x08 & RDMEM[HAD][LAD]) == 0 ? F_ZHPV : F_H ); return 20;
/* BIT 4,(index)*/  case 0x00000066: F = (F & F_C) | ((0x10 & RDMEM[HAD][LAD]) == 0 ? F_ZHPV : F_H ); return 20;
/* BIT 5,(index)*/  case 0x0000006E: F = (F & F_C) | ((0x20 & RDMEM[HAD][LAD]) == 0 ? F_ZHPV : F_H ); return 20;
/* BIT 6,(index)*/  case 0x00000076: F = (F & F_C) | ((0x40 & RDMEM[HAD][LAD]) == 0 ? F_ZHPV : F_H ); return 20;
/* BIT 7,(index)*/  case 0x0000007E: F = (F & F_C) | ((0x80 & RDMEM[HAD][LAD]) == 0 ? F_ZHPV : F_SH); return 20;
//  ----------------------------------------------------------------------------
/* RES 0,(index)*/  case 0xFFFFFF86: WRMEM[HAD][LAD] = (byte)(RDMEM[HAD][LAD] & ~0x01); return 23;
/* RES 1,(index)*/  case 0xFFFFFF8E: WRMEM[HAD][LAD] = (byte)(RDMEM[HAD][LAD] & ~0x02); return 23;
/* RES 2,(index)*/  case 0xFFFFFF96: WRMEM[HAD][LAD] = (byte)(RDMEM[HAD][LAD] & ~0x04); return 23;
/* RES 3,(index)*/  case 0xFFFFFF9E: WRMEM[HAD][LAD] = (byte)(RDMEM[HAD][LAD] & ~0x08); return 23;
/* RES 4,(index)*/  case 0xFFFFFFA6: WRMEM[HAD][LAD] = (byte)(RDMEM[HAD][LAD] & ~0x10); return 23;
/* RES 5,(index)*/  case 0xFFFFFFAE: WRMEM[HAD][LAD] = (byte)(RDMEM[HAD][LAD] & ~0x20); return 23;
/* RES 6,(index)*/  case 0xFFFFFFB6: WRMEM[HAD][LAD] = (byte)(RDMEM[HAD][LAD] & ~0x40); return 23;
/* RES 7,(index)*/  case 0xFFFFFFBE: WRMEM[HAD][LAD] = (byte)(RDMEM[HAD][LAD] & ~0x80); return 23;
//  ----------------------------------------------------------------------------
/* SET 0,(index)*/  case 0xFFFFFFC6: WRMEM[HAD][LAD] = (byte)(RDMEM[HAD][LAD] | 0x01); return 23;
/* SET 1,(index)*/  case 0xFFFFFFCE: WRMEM[HAD][LAD] = (byte)(RDMEM[HAD][LAD] | 0x02); return 23;
/* SET 2,(index)*/  case 0xFFFFFFD6: WRMEM[HAD][LAD] = (byte)(RDMEM[HAD][LAD] | 0x04); return 23;
/* SET 3,(index)*/  case 0xFFFFFFDE: WRMEM[HAD][LAD] = (byte)(RDMEM[HAD][LAD] | 0x08); return 23;
/* SET 4,(index)*/  case 0xFFFFFFE6: WRMEM[HAD][LAD] = (byte)(RDMEM[HAD][LAD] | 0x10); return 23;
/* SET 5,(index)*/  case 0xFFFFFFEE: WRMEM[HAD][LAD] = (byte)(RDMEM[HAD][LAD] | 0x20); return 23;
/* SET 6,(index)*/  case 0xFFFFFFF6: WRMEM[HAD][LAD] = (byte)(RDMEM[HAD][LAD] | 0x40); return 23;
/* SET 7,(index)*/  case 0xFFFFFFFE: WRMEM[HAD][LAD] = (byte)(RDMEM[HAD][LAD] | 0x80); return 23;
//  ----------------------------------------------------------------------------
        }
        return 12;
    }    

//  ============================================================================
//  ����� �������� ������ CPU Z80 � ��������� CB
//  ============================================================================
    private final int execute_cb() {
        int OP = RDMEM[HPC][LPC]; if(LPC++ == 0xFF) { LPC = 0x00; HPC = INC[HPC]; }
        switch(OP) {
//  ----------------------------------------------------------------------------
/* RLC B        */  case 0x00000000: F = B >> 7 | SZP_T[B = RLC[B]]; return 8;
/* RLC C        */  case 0x00000001: F = C >> 7 | SZP_T[C = RLC[C]]; return 8;
/* RLC D        */  case 0x00000002: F = D >> 7 | SZP_T[D = RLC[D]]; return 8;
/* RLC E        */  case 0x00000003: F = E >> 7 | SZP_T[E = RLC[E]]; return 8;
/* RLC H        */  case 0x00000004: F = H >> 7 | SZP_T[H = RLC[H]]; return 8;
/* RLC L        */  case 0x00000005: F = L >> 7 | SZP_T[L = RLC[L]]; return 8;
/* RLC (HL)     */  case 0x00000006: { int V0 = 0x00FF & RDMEM[H][L]; F = V0 >> 7 | SZP_T[V0 = RLC[V0]]; WRMEM[H][L] = (byte)V0; } return 15;
/* RLC A        */  case 0x00000007: F = A >> 7 | SZP_T[A = RLC[A]]; return 8;
//  ----------------------------------------------------------------------------
/* RRC B        */  case 0x00000008: F = B & 1  | SZP_T[B = RRC[B]]; return 8;
/* RRC C        */  case 0x00000009: F = C & 1  | SZP_T[C = RRC[C]]; return 8;
/* RRC D        */  case 0x0000000A: F = D & 1  | SZP_T[D = RRC[D]]; return 8;
/* RRC E        */  case 0x0000000B: F = E & 1  | SZP_T[E = RRC[E]]; return 8;
/* RRC H        */  case 0x0000000C: F = H & 1  | SZP_T[H = RRC[H]]; return 8;
/* RRC L        */  case 0x0000000D: F = L & 1  | SZP_T[L = RRC[L]]; return 8;
/* RRC (HL)     */  case 0x0000000E: { int V0 = 0x00FF & RDMEM[H][L]; F = V0 & 1  | SZP_T[V0 = RRC[V0]]; WRMEM[H][L] = (byte)V0; } return 15;
/* RRC A        */  case 0x0000000F: F = A & 1  | SZP_T[A = RRC[A]]; return 8;
//  ----------------------------------------------------------------------------
/* RL B         */  case 0x00000010: F = B >> 7 | SZP_T[B = (B << 1 | (F & F_C)) & 0xFF]; return 8;
/* RL C         */  case 0x00000011: F = C >> 7 | SZP_T[C = (C << 1 | (F & F_C)) & 0xFF]; return 8;
/* RL D         */  case 0x00000012: F = D >> 7 | SZP_T[D = (D << 1 | (F & F_C)) & 0xFF]; return 8;
/* RL E         */  case 0x00000013: F = E >> 7 | SZP_T[E = (E << 1 | (F & F_C)) & 0xFF]; return 8;
/* RL H         */  case 0x00000014: F = H >> 7 | SZP_T[H = (H << 1 | (F & F_C)) & 0xFF]; return 8;
/* RL L         */  case 0x00000015: F = L >> 7 | SZP_T[L = (L << 1 | (F & F_C)) & 0xFF]; return 8;
/* RL {HL}      */  case 0x00000016: { int V0 = 0x00FF & RDMEM[H][L]; F = V0 >> 7 | SZP_T[V0 = (V0 << 1 | (F & F_C)) & 0xFF]; WRMEM[H][L] = (byte)V0; } return 15;
/* RL A         */  case 0x00000017: F = A >> 7 | SZP_T[A = (A << 1 | (F & F_C)) & 0xFF]; return 8;
//  ----------------------------------------------------------------------------
/* RR B         */  case 0x00000018: F = B & 1  | SZP_T[B = (B >> 1 | F << 7) & 0xFF]; return 8;
/* RR C         */  case 0x00000019: F = C & 1  | SZP_T[C = (C >> 1 | F << 7) & 0xFF]; return 8;
/* RR D         */  case 0x0000001A: F = D & 1  | SZP_T[D = (D >> 1 | F << 7) & 0xFF]; return 8;
/* RR E         */  case 0x0000001B: F = E & 1  | SZP_T[E = (E >> 1 | F << 7) & 0xFF]; return 8;
/* RR H         */  case 0x0000001C: F = H & 1  | SZP_T[H = (H >> 1 | F << 7) & 0xFF]; return 8;
/* RR L        !*/  case 0x0000001D: F = L & 1  | SZP_T[L = (L >> 1 | F << 7) & 0xFF]; return 8;
/* RR (HL)      */  case 0x0000001E: { int V0 = 0x00FF & RDMEM[H][L]; F = V0 & 1  | SZP_T[V0 = (V0 >> 1 | F << 7) & 0xFF]; WRMEM[H][L] = (byte)V0; } return 15;
/* RR A        !*/  case 0x0000001F: F = A & 1  | SZP_T[A = (A >> 1 | F << 7) & 0xFF]; return 8;
//  ----------------------------------------------------------------------------
/* SLA B        */  case 0x00000020: F = B >> 7 | SZP_T[B = B << 1 & 0xFF]; return 8;
/* SLA C        */  case 0x00000021: F = C >> 7 | SZP_T[C = C << 1 & 0xFF]; return 8;
/* SLA D        */  case 0x00000022: F = D >> 7 | SZP_T[D = D << 1 & 0xFF]; return 8;
/* SLA E        */  case 0x00000023: F = E >> 7 | SZP_T[E = E << 1 & 0xFF]; return 8;
/* SLA H        */  case 0x00000024: F = H >> 7 | SZP_T[H = H << 1 & 0xFF]; return 8;
/* SLA L        */  case 0x00000025: F = L >> 7 | SZP_T[L = L << 1 & 0xFF]; return 8;
/* SLA {HL}     */  case 0x00000026: { int V0 = 0x00FF & RDMEM[H][L]; F = V0 >> 7 | SZP_T[V0 = V0 << 1 & 0xFF]; WRMEM[H][L] = (byte)V0; } return 15;
/* SLA A        */  case 0x00000027: F = A >> 7 | SZP_T[A = A << 1 & 0xFF]; return 8;
//  ----------------------------------------------------------------------------
/* SRA B        */  case 0x00000028: F = B & 1  | SZP_T[B = B >> 1 | (B & 0x80)]; return 8;
/* SRA C        */  case 0x00000029: F = C & 1  | SZP_T[C = C >> 1 | (C & 0x80)]; return 8;
/* SRA D        */  case 0x0000002A: F = D & 1  | SZP_T[D = D >> 1 | (D & 0x80)]; return 8;
/* SRA E        */  case 0x0000002B: F = E & 1  | SZP_T[E = E >> 1 | (E & 0x80)]; return 8;
/* SRA H        */  case 0x0000002C: F = H & 1  | SZP_T[H = H >> 1 | (H & 0x80)]; return 8;
/* SRA L        */  case 0x0000002D: F = L & 1  | SZP_T[L = L >> 1 | (L & 0x80)]; return 8;
/* SRA (HL)     */  case 0x0000002E: { int V0 = 0x00FF & RDMEM[H][L]; F = V0 & 1  | SZP_T[V0 = V0 >> 1 | (V0 & 0x80)]; WRMEM[H][L] = (byte)V0; } return 15;
/* SRA A        */  case 0x0000002F: F = A & 1  | SZP_T[A = A >> 1 | (A & 0x80)]; return 8;
//  ----------------------------------------------------------------------------
/* SLL B        */  case 0x00000030: F = B >> 7 | SZP_T[B = (B << 1 | 0x01) & 0xFF]; return 8;
/* SLL C        */  case 0x00000031: F = C >> 7 | SZP_T[C = (C << 1 | 0x01) & 0xFF]; return 8;
/* SLL D        */  case 0x00000032: F = D >> 7 | SZP_T[D = (D << 1 | 0x01) & 0xFF]; return 8;
/* SLL E        */  case 0x00000033: F = E >> 7 | SZP_T[E = (E << 1 | 0x01) & 0xFF]; return 8;
/* SLL H        */  case 0x00000034: F = H >> 7 | SZP_T[H = (H << 1 | 0x01) & 0xFF]; return 8;
/* SLL L       !*/  case 0x00000035: F = L >> 7 | SZP_T[L = (L << 1 | 0x01) & 0xFF]; return 8;
/* SLL (HL)     */  case 0x00000036: { int V0 = 0x00FF & RDMEM[H][L]; F = V0 >> 7 | SZP_T[V0 = (V0 << 1 | 0x01) & 0xFF]; WRMEM[H][L] = (byte)V0; } return 15;
/* SLL A        */  case 0x00000037: F = A >> 7 | SZP_T[A = (A << 1 | 0x01) & 0xFF]; return 8;
//  ----------------------------------------------------------------------------
/* SRL B        */  case 0x00000038: F = B & 1  | SZP_T[B >>= 1]; return 8;
/* SRL C        */  case 0x00000039: F = C & 1  | SZP_T[C >>= 1]; return 8;
/* SRL D        */  case 0x0000003A: F = D & 1  | SZP_T[D >>= 1]; return 8;
/* SRL E       !*/  case 0x0000003B: F = E & 1  | SZP_T[E >>= 1]; return 8;
/* SRL H        */  case 0x0000003C: F = H & 1  | SZP_T[H >>= 1]; return 8;
/* SRL L        */  case 0x0000003D: F = L & 1  | SZP_T[L >>= 1]; return 8;
/* SRL (HL)    !*/  case 0x0000003E: { int V0 = 0x00FF & RDMEM[H][L]; F = V0 & 1  | SZP_T[V0 >>= 1]; WRMEM[H][L] = (byte)V0; } return 15;
/* SRL A        */  case 0x0000003F: F = A & 1  | SZP_T[A >>= 1]; return 8;
//  ----------------------------------------------------------------------------
/* BIT 0,B      */  case 0x00000040: F = (F & F_C) | ((0x01 & B) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 0,C      */  case 0x00000041: F = (F & F_C) | ((0x01 & C) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 0,D      */  case 0x00000042: F = (F & F_C) | ((0x01 & D) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 0,E      */  case 0x00000043: F = (F & F_C) | ((0x01 & E) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 0,H      */  case 0x00000044: F = (F & F_C) | ((0x01 & H) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 0,L      */  case 0x00000045: F = (F & F_C) | ((0x01 & L) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 0,(HL)   */  case 0x00000046: F = (F & F_C) | ((0x01 & RDMEM[H][L]) == 0 ? F_ZHPV : F_H); return 12;
/* BIT 0,A      */  case 0x00000047: F = (F & F_C) | ((0x01 & A) == 0 ? F_ZHPV : F_H); return 8;
//  ----------------------------------------------------------------------------
/* BIT 1,B      */  case 0x00000048: F = (F & F_C) | ((0x02 & B) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 1,C      */  case 0x00000049: F = (F & F_C) | ((0x02 & C) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 1,D      */  case 0x0000004A: F = (F & F_C) | ((0x02 & D) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 1,E      */  case 0x0000004B: F = (F & F_C) | ((0x02 & E) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 1,H      */  case 0x0000004C: F = (F & F_C) | ((0x02 & H) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 1,L      */  case 0x0000004D: F = (F & F_C) | ((0x02 & L) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 1,(HL)   */  case 0x0000004E: F = (F & F_C) | ((0x02 & RDMEM[H][L]) == 0 ? F_ZHPV : F_H); return 12;
/* BIT 1,A      */  case 0x0000004F: F = (F & F_C) | ((0x02 & A) == 0 ? F_ZHPV : F_H); return 8;
//  ----------------------------------------------------------------------------
/* BIT 2,B      */  case 0x00000050: F = (F & F_C) | ((0x04 & B) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 2,C      */  case 0x00000051: F = (F & F_C) | ((0x04 & C) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 2,D      */  case 0x00000052: F = (F & F_C) | ((0x04 & D) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 2,E      */  case 0x00000053: F = (F & F_C) | ((0x04 & E) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 2,H      */  case 0x00000054: F = (F & F_C) | ((0x04 & H) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 2,L      */  case 0x00000055: F = (F & F_C) | ((0x04 & L) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 2,(HL)   */  case 0x00000056: F = (F & F_C) | ((0x04 & RDMEM[H][L]) == 0 ? F_ZHPV : F_H); return 12;
/* BIT 2,A      */  case 0x00000057: F = (F & F_C) | ((0x04 & A) == 0 ? F_ZHPV : F_H); return 8;
//  ----------------------------------------------------------------------------
/* BIT 3,B      */  case 0x00000058: F = (F & F_C) | ((0x08 & B) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 3,C      */  case 0x00000059: F = (F & F_C) | ((0x08 & C) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 3,D      */  case 0x0000005A: F = (F & F_C) | ((0x08 & D) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 3,E      */  case 0x0000005B: F = (F & F_C) | ((0x08 & E) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 3,H      */  case 0x0000005C: F = (F & F_C) | ((0x08 & H) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 3,L      */  case 0x0000005D: F = (F & F_C) | ((0x08 & L) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 3,(HL)   */  case 0x0000005E: F = (F & F_C) | ((0x08 & RDMEM[H][L]) == 0 ? F_ZHPV : F_H); return 12;
/* BIT 3,A      */  case 0x0000005F: F = (F & F_C) | ((0x08 & A) == 0 ? F_ZHPV : F_H); return 8;
//  ----------------------------------------------------------------------------
/* BIT 4,B      */  case 0x00000060: F = (F & F_C) | ((0x10 & B) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 4,C      */  case 0x00000061: F = (F & F_C) | ((0x10 & C) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 4,D      */  case 0x00000062: F = (F & F_C) | ((0x10 & D) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 4,E      */  case 0x00000063: F = (F & F_C) | ((0x10 & E) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 4,H      */  case 0x00000064: F = (F & F_C) | ((0x10 & H) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 4,L      */  case 0x00000065: F = (F & F_C) | ((0x10 & L) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 4,(HL)   */  case 0x00000066: F = (F & F_C) | ((0x10 & RDMEM[H][L]) == 0 ? F_ZHPV : F_H); return 12;
/* BIT 4,A      */  case 0x00000067: F = (F & F_C) | ((0x10 & A) == 0 ? F_ZHPV : F_H); return 8;
//  ----------------------------------------------------------------------------
/* BIT 5,B      */  case 0x00000068: F = (F & F_C) | ((0x20 & B) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 5,C      */  case 0x00000069: F = (F & F_C) | ((0x20 & C) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 5,D      */  case 0x0000006A: F = (F & F_C) | ((0x20 & D) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 5,E      */  case 0x0000006B: F = (F & F_C) | ((0x20 & E) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 5,H      */  case 0x0000006C: F = (F & F_C) | ((0x20 & H) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 5,L      */  case 0x0000006D: F = (F & F_C) | ((0x20 & L) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 5,(HL)   */  case 0x0000006E: F = (F & F_C) | ((0x20 & RDMEM[H][L]) == 0 ? F_ZHPV : F_H); return 12;
/* BIT 5,A      */  case 0x0000006F: F = (F & F_C) | ((0x20 & A) == 0 ? F_ZHPV : F_H); return 8;
//  ----------------------------------------------------------------------------
/* BIT 6,B      */  case 0x00000070: F = (F & F_C) | ((0x40 & B) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 6,C      */  case 0x00000071: F = (F & F_C) | ((0x40 & C) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 6,D      */  case 0x00000072: F = (F & F_C) | ((0x40 & D) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 6,E      */  case 0x00000073: F = (F & F_C) | ((0x40 & E) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 6,H      */  case 0x00000074: F = (F & F_C) | ((0x40 & H) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 6,L      */  case 0x00000075: F = (F & F_C) | ((0x40 & L) == 0 ? F_ZHPV : F_H); return 8;
/* BIT 6,(HL)   */  case 0x00000076: F = (F & F_C) | ((0x40 & RDMEM[H][L]) == 0 ? F_ZHPV : F_H); return 12;
/* BIT 6,A      */  case 0x00000077: F = (F & F_C) | ((0x40 & A) == 0 ? F_ZHPV : F_H); return 8;
//  ----------------------------------------------------------------------------
/* BIT 7,B      */  case 0x00000078: F = (F & F_C) | ((0x80 & B) == 0 ? F_ZHPV : F_SH); return 8;
/* BIT 7,C      */  case 0x00000079: F = (F & F_C) | ((0x80 & C) == 0 ? F_ZHPV : F_SH); return 8;
/* BIT 7,D      */  case 0x0000007A: F = (F & F_C) | ((0x80 & D) == 0 ? F_ZHPV : F_SH); return 8;
/* BIT 7,E      */  case 0x0000007B: F = (F & F_C) | ((0x80 & E) == 0 ? F_ZHPV : F_SH); return 8;
/* BIT 7,H      */  case 0x0000007C: F = (F & F_C) | ((0x80 & H) == 0 ? F_ZHPV : F_SH); return 8;
/* BIT 7,L      */  case 0x0000007D: F = (F & F_C) | ((0x80 & L) == 0 ? F_ZHPV : F_SH); return 8;
/* BIT 7,(HL)   */  case 0x0000007E: F = (F & F_C) | ((0x80 & RDMEM[H][L]) == 0 ? F_ZHPV : F_SH); return 12;
/* BIT 7,A      */  case 0x0000007F: F = (F & F_C) | ((0x80 & A) == 0 ? F_ZHPV : F_SH); return 8;
//  ----------------------------------------------------------------------------
/* RES 0,B      */  case 0xFFFFFF80: B &= ~0x01; return 8;
/* RES 0,C      */  case 0xFFFFFF81: C &= ~0x01; return 8;
/* RES 0,D      */  case 0xFFFFFF82: D &= ~0x01; return 8;
/* RES 0,E      */  case 0xFFFFFF83: E &= ~0x01; return 8;
/* RES 0,H      */  case 0xFFFFFF84: H &= ~0x01; return 8;
/* RES 0,L      */  case 0xFFFFFF85: L &= ~0x01; return 8;
/* RES 0,(HL)   */  case 0xFFFFFF86: WRMEM[H][L] = (byte)(RDMEM[H][L] & ~0x01); return 15;
/* RES 0,A      */  case 0xFFFFFF87: A &= ~0x01; return 8;
//  ----------------------------------------------------------------------------
/* RES 1,B      */  case 0xFFFFFF88: B &= ~0x02; return 8;
/* RES 1,C      */  case 0xFFFFFF89: C &= ~0x02; return 8;
/* RES 1,D      */  case 0xFFFFFF8A: D &= ~0x02; return 8;
/* RES 1,E      */  case 0xFFFFFF8B: E &= ~0x02; return 8;
/* RES 1,H      */  case 0xFFFFFF8C: H &= ~0x02; return 8;
/* RES 1,L      */  case 0xFFFFFF8D: L &= ~0x02; return 8;
/* RES 1,(HL)   */  case 0xFFFFFF8E: WRMEM[H][L] = (byte)(RDMEM[H][L] & ~0x02); return 15;
/* RES 1,A      */  case 0xFFFFFF8F: A &= ~0x02; return 8;
//  ----------------------------------------------------------------------------
/* RES 2,B      */  case 0xFFFFFF90: B &= ~0x04; return 8;
/* RES 2,C      */  case 0xFFFFFF91: C &= ~0x04; return 8;
/* RES 2,D      */  case 0xFFFFFF92: D &= ~0x04; return 8;
/* RES 2,E      */  case 0xFFFFFF93: E &= ~0x04; return 8;
/* RES 2,H      */  case 0xFFFFFF94: H &= ~0x04; return 8;
/* RES 2,L      */  case 0xFFFFFF95: L &= ~0x04; return 8;
/* RES 2,(HL)   */  case 0xFFFFFF96: WRMEM[H][L] = (byte)(RDMEM[H][L] & ~0x04); return 15;
/* RES 2,A      */  case 0xFFFFFF97: A &= ~0x04; return 8;
//  ----------------------------------------------------------------------------
/* RES 3,B      */  case 0xFFFFFF98: B &= ~0x08; return 8;
/* RES 3,C      */  case 0xFFFFFF99: C &= ~0x08; return 8;
/* RES 3,D      */  case 0xFFFFFF9A: D &= ~0x08; return 8;
/* RES 3,E      */  case 0xFFFFFF9B: E &= ~0x08; return 8;
/* RES 3,H      */  case 0xFFFFFF9C: H &= ~0x08; return 8;
/* RES 3,L      */  case 0xFFFFFF9D: L &= ~0x08; return 8;
/* RES 3,(HL)   */  case 0xFFFFFF9E: WRMEM[H][L] = (byte)(RDMEM[H][L] & ~0x08); return 15;
/* RES 3,A      */  case 0xFFFFFF9F: A &= ~0x08; return 8;
//  ----------------------------------------------------------------------------
/* RES 4,B      */  case 0xFFFFFFA0: B &= ~0x10; return 8;
/* RES 4,C      */  case 0xFFFFFFA1: C &= ~0x10; return 8;
/* RES 4,D      */  case 0xFFFFFFA2: D &= ~0x10; return 8;
/* RES 4,E      */  case 0xFFFFFFA3: E &= ~0x10; return 8;
/* RES 4,H      */  case 0xFFFFFFA4: H &= ~0x10; return 8;
/* RES 4,L      */  case 0xFFFFFFA5: L &= ~0x10; return 8;
/* RES 4,(HL)   */  case 0xFFFFFFA6: WRMEM[H][L] = (byte)(RDMEM[H][L] & ~0x10); return 15;
/* RES 4,A      */  case 0xFFFFFFA7: A &= ~0x10; return 8;
//  ----------------------------------------------------------------------------
/* RES 5,B      */  case 0xFFFFFFA8: B &= ~0x20; return 8;
/* RES 5,C      */  case 0xFFFFFFA9: C &= ~0x20; return 8;
/* RES 5,D      */  case 0xFFFFFFAA: D &= ~0x20; return 8;
/* RES 5,E      */  case 0xFFFFFFAB: E &= ~0x20; return 8;
/* RES 5,H      */  case 0xFFFFFFAC: H &= ~0x20; return 8;
/* RES 5,L      */  case 0xFFFFFFAD: L &= ~0x20; return 8;
/* RES 5,(HL)   */  case 0xFFFFFFAE: WRMEM[H][L] = (byte)(RDMEM[H][L] & ~0x20); return 15;
/* RES 5,A      */  case 0xFFFFFFAF: A &= ~0x20; return 8;
//  ----------------------------------------------------------------------------
/* RES 6,B      */  case 0xFFFFFFB0: B &= ~0x40; return 8;
/* RES 6,C      */  case 0xFFFFFFB1: C &= ~0x40; return 8;
/* RES 6,D      */  case 0xFFFFFFB2: D &= ~0x40; return 8;
/* RES 6,E      */  case 0xFFFFFFB3: E &= ~0x40; return 8;
/* RES 6,H      */  case 0xFFFFFFB4: H &= ~0x40; return 8;
/* RES 6,L      */  case 0xFFFFFFB5: L &= ~0x40; return 8;
/* RES 6,(HL)   */  case 0xFFFFFFB6: WRMEM[H][L] = (byte)(RDMEM[H][L] & ~0x40); return 15;
/* RES 6,A      */  case 0xFFFFFFB7: A &= ~0x40; return 8;
//  ----------------------------------------------------------------------------
/* RES 7,B      */  case 0xFFFFFFB8: B &= ~0x80; return 8;
/* RES 7,C      */  case 0xFFFFFFB9: C &= ~0x80; return 8;
/* RES 7,D      */  case 0xFFFFFFBA: D &= ~0x80; return 8;
/* RES 7,E      */  case 0xFFFFFFBB: E &= ~0x80; return 8;
/* RES 7,H      */  case 0xFFFFFFBC: H &= ~0x80; return 8;
/* RES 7,L      */  case 0xFFFFFFBD: L &= ~0x80; return 8;
/* RES 7,(HL)   */  case 0xFFFFFFBE: WRMEM[H][L] = (byte)(RDMEM[H][L] & ~0x80); return 15;
/* RES 7,A      */  case 0xFFFFFFBF: A &= ~0x80; return 8;
//  ----------------------------------------------------------------------------
/* SET 0,B      */  case 0xFFFFFFC0: B |= 0x01; return 8;
/* SET 0,C      */  case 0xFFFFFFC1: C |= 0x01; return 8;
/* SET 0,D      */  case 0xFFFFFFC2: D |= 0x01; return 8;
/* SET 0,E      */  case 0xFFFFFFC3: E |= 0x01; return 8;
/* SET 0,H      */  case 0xFFFFFFC4: H |= 0x01; return 8;
/* SET 0,L      */  case 0xFFFFFFC5: L |= 0x01; return 8;
/* SET 0,(HL)   */  case 0xFFFFFFC6: WRMEM[H][L] = (byte)(RDMEM[H][L] | 0x01); return 15;
/* SET 0,A      */  case 0xFFFFFFC7: A |= 0x01; return 8;
//  ----------------------------------------------------------------------------
/* SET 1,B      */  case 0xFFFFFFC8: B |= 0x02; return 8;
/* SET 1,C      */  case 0xFFFFFFC9: C |= 0x02; return 8;
/* SET 1,D      */  case 0xFFFFFFCA: D |= 0x02; return 8;
/* SET 1,E      */  case 0xFFFFFFCB: E |= 0x02; return 8;
/* SET 1,H      */  case 0xFFFFFFCC: H |= 0x02; return 8;
/* SET 1,L      */  case 0xFFFFFFCD: L |= 0x02; return 8;
/* SET 1,(HL)   */  case 0xFFFFFFCE: WRMEM[H][L] = (byte)(RDMEM[H][L] | 0x02); return 15;
/* SET 1,A      */  case 0xFFFFFFCF: A |= 0x02; return 8;
//  ----------------------------------------------------------------------------
/* SET 2,B      */  case 0xFFFFFFD0: B |= 0x04; return 8;
/* SET 2,C      */  case 0xFFFFFFD1: C |= 0x04; return 8;
/* SET 2,D      */  case 0xFFFFFFD2: D |= 0x04; return 8;
/* SET 2,E      */  case 0xFFFFFFD3: E |= 0x04; return 8;
/* SET 2,H      */  case 0xFFFFFFD4: H |= 0x04; return 8;
/* SET 2,L      */  case 0xFFFFFFD5: L |= 0x04; return 8;
/* SET 2,(HL)   */  case 0xFFFFFFD6: WRMEM[H][L] = (byte)(RDMEM[H][L] | 0x04); return 15;
/* SET 2,A      */  case 0xFFFFFFD7: A |= 0x04; return 8;
//  ----------------------------------------------------------------------------
/* SET 3,B      */  case 0xFFFFFFD8: B |= 0x08; return 8;
/* SET 3,C      */  case 0xFFFFFFD9: C |= 0x08; return 8;
/* SET 3,D      */  case 0xFFFFFFDA: D |= 0x08; return 8;
/* SET 3,E      */  case 0xFFFFFFDB: E |= 0x08; return 8;
/* SET 3,H      */  case 0xFFFFFFDC: H |= 0x08; return 8;
/* SET 3,L      */  case 0xFFFFFFDD: L |= 0x08; return 8;
/* SET 3,(HL)   */  case 0xFFFFFFDE: WRMEM[H][L] = (byte)(RDMEM[H][L] | 0x08); return 15;
/* SET 3,A      */  case 0xFFFFFFDF: A |= 0x08; return 8;
//  ----------------------------------------------------------------------------
/* SET 4,B      */  case 0xFFFFFFE0: B |= 0x10; return 8;
/* SET 4,C      */  case 0xFFFFFFE1: C |= 0x10; return 8;
/* SET 4,D      */  case 0xFFFFFFE2: D |= 0x10; return 8;
/* SET 4,E      */  case 0xFFFFFFE3: E |= 0x10; return 8;
/* SET 4,H      */  case 0xFFFFFFE4: H |= 0x10; return 8;
/* SET 4,L      */  case 0xFFFFFFE5: L |= 0x10; return 8;
/* SET 4,(HL)   */  case 0xFFFFFFE6: WRMEM[H][L] = (byte)(RDMEM[H][L] | 0x10); return 15;
/* SET 4,A      */  case 0xFFFFFFE7: A |= 0x10; return 8;
//  ----------------------------------------------------------------------------
/* SET 5,B      */  case 0xFFFFFFE8: B |= 0x20; return 8;
/* SET 5,C      */  case 0xFFFFFFE9: C |= 0x20; return 8;
/* SET 5,D      */  case 0xFFFFFFEA: D |= 0x20; return 8;
/* SET 5,E      */  case 0xFFFFFFEB: E |= 0x20; return 8;
/* SET 5,H      */  case 0xFFFFFFEC: H |= 0x20; return 8;
/* SET 5,L      */  case 0xFFFFFFED: L |= 0x20; return 8;
/* SET 5,(HL)   */  case 0xFFFFFFEE: WRMEM[H][L] = (byte)(RDMEM[H][L] | 0x20); return 15;
/* SET 5,A      */  case 0xFFFFFFEF: A |= 0x20; return 8;
//  ----------------------------------------------------------------------------
/* SET 6,B      */  case 0xFFFFFFF0: B |= 0x40; return 8;
/* SET 6,C      */  case 0xFFFFFFF1: C |= 0x40; return 8;
/* SET 6,D      */  case 0xFFFFFFF2: D |= 0x40; return 8;
/* SET 6,E      */  case 0xFFFFFFF3: E |= 0x40; return 8;
/* SET 6,H      */  case 0xFFFFFFF4: H |= 0x40; return 8;
/* SET 6,L      */  case 0xFFFFFFF5: L |= 0x40; return 8;
/* SET 6,(HL)   */  case 0xFFFFFFF6: WRMEM[H][L] = (byte)(RDMEM[H][L] | 0x40); return 15;
/* SET 6,A      */  case 0xFFFFFFF7: A |= 0x40; return 8;
//  ----------------------------------------------------------------------------
/* SET 7,B      */  case 0xFFFFFFF8: B |= 0x80; return 8;
/* SET 7,C      */  case 0xFFFFFFF9: C |= 0x80; return 8;
/* SET 7,D      */  case 0xFFFFFFFA: D |= 0x80; return 8;
/* SET 7,E      */  case 0xFFFFFFFB: E |= 0x80; return 8;
/* SET 7,H      */  case 0xFFFFFFFC: H |= 0x80; return 8;
/* SET 7,L      */  case 0xFFFFFFFD: L |= 0x80; return 8;
/* SET 7,(HL)   */  case 0xFFFFFFFE: WRMEM[H][L] = (byte)(RDMEM[H][L] | 0x80); return 15;
/* SET 7,A      */  case 0xFFFFFFFF: A |= 0x80; return 8;
//  ----------------------------------------------------------------------------
        }
        return 4;
    }

//  ============================================================================
//  ����� �������� ������ CPU Z80 � ��������� ED    
//  ============================================================================    
    private final int execute_ed() {
//  - ��� ������� ADC HL,.. SBC HL,.. �������� ���������� ��������� (������) ����� PV
//  - ���������� �������� R �����������, ��� LD A,R ������������ ��������� �����
        int OP = RDMEM[HPC][LPC]; if(LPC++ == 0xFF) { LPC = 0x00; HPC = INC[HPC]; }
        switch(OP) {
//  ----------------------------------------------------------------------------
/* IN B,(C)     */  case 0x00000040: F = (F & F_C) | SZP_T[B = RDPORT(B << 8 | C)]; return 12;
/* OUT (C),B    */  case 0x00000041: WRPORT(B << 8 | C, B); return 12;
/* SBC HL,BC    */  case 0x00000042: { int V0 = H << 8 | L, V1 = B << 8 | C, V2 = V0 - V1 - (F & F_C); F = ((V2 >> 8) & F_S) | (((V2 & 0xFFFF) != 0) ? 0 : F_Z) | (((V0 ^ V2 ^ V1) >> 8) & F_H) | (((V1 ^ V0) & (V0 ^ V2)) >> 13 & F_PV) | ((V2 >> 16) & F_C) | F_N; H = V2 >> 8 & 0xFF; L = V2 & 0xFF; } return 15;
/* NEG          */  case 0x00000044: 
                    case 0x0000004C:
                    case 0x00000054:
                    case 0x0000005C:
                    case 0x00000064:
                    case 0x0000006C:
                    case 0x00000074:
                    case 0x0000007C: { int V0 = 0 - A; F = (V0 >> 8 & F_C) | SZ_T[V0 &= 0xFF] | (((0 ^ A) & (0 ^ V0)) >> 5 & F_PV) | ((0 & 0xF) - (A & 0xF) & F_H) | F_N; A = V0; } return 8;                        
/* RETN        !*/  case 0x00000045:
                    case 0x00000055:
                    case 0x0000005D:
                    case 0x00000065:
                    case 0x0000006D:
                    case 0x00000075:
                    case 0x0000007D: IFF1 = IFF2; LPC = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } HPC = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } return 14;                        
/* IM 0         */  case 0x00000046:
                    case 0x0000004E:
                    case 0x00000066:
                    case 0x0000006E: IM = 0; return 8;
/* LD I,A       */  case 0x00000047: I = A; return 9;
//  ----------------------------------------------------------------------------
/* IN C,(C)     */  case 0x00000048: F = (F & F_C) | SZP_T[C = RDPORT(B << 8 | C)]; return 12;
/* OUT (C),C    */  case 0x00000049: WRPORT(B << 8 | C, C); return 12;
/* ADC HL,BC    */  case 0x0000004A: { int V0 = H << 8 | L, V1 = B << 8 | C, V2 = V0 + V1 + (F & F_C); F = ((V2 >> 8) & F_S) | (((V2 & 0xFFFF) !=0) ? 0 : F_Z) | (((V0 ^ V2 ^ V1) >> 8) & F_H) | /*(((V1 ^ V0 ^ 0x8000) & (V1 ^ V2)) >> 13 & F_PV) |*/ ((V2 >> 16) & F_C); H = V2 >> 8 & 0xFF; L = V2 & 0xFF; } return 15;
/* RETI        !*/  case 0x0000004D: LPC = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } HPC = 0x00FF & RDMEM[HSP][LSP]; if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; } return 14;
/* LD R,A       */  case 0x0000004F: return 9;
//  ----------------------------------------------------------------------------
/* IN D,(C)     */  case 0x00000050: F = (F & F_C) | SZP_T[D = RDPORT(B << 8 | C)]; return 12;
/* OUT (C),D    */  case 0x00000051: WRPORT(B << 8 | C, D); return 12;
/* SBC HL,DE    */  case 0x00000052: { int V0 = H << 8 | L, V1 = D << 8 | E, V2 = V0 - V1 - (F & F_C); F = ((V2 >> 8) & F_S) | (((V2 & 0xFFFF) != 0) ? 0 : F_Z) | (((V0 ^ V2 ^ V1) >> 8) & F_H) | (((V1 ^ V0) & (V0 ^ V2)) >> 13 & F_PV) | ((V2 >> 16) & F_C) | F_N; H = V2 >> 8 & 0xFF; L = V2 & 0xFF; } return 15;
/* IM 1         */  case 0x00000056: 
                    case 0x00000076: IM = 1; return 8;
/* LD A,I       */  case 0x00000057: F = (F & F_C) | SZ_T[A = I] | (IFF2 ? F_PV : 0); return 9;
//  ----------------------------------------------------------------------------
/* IN E,(C)     */  case 0x00000058: F = (F & F_C) | SZP_T[E = RDPORT(B << 8 | C)]; return 12;
/* OUT (C),E    */  case 0x00000059: WRPORT(B << 8 | C, E); return 12;
/* ADC HL,DE    */  case 0x0000005A: { int V0 = H << 8 | L, V1 = D << 8 | E, V2 = V0 + V1 + (F & F_C); F = ((V2 >> 8) & F_S) | (((V2 & 0xFFFF) !=0) ? 0 : F_Z) | (((V0 ^ V2 ^ V1) >> 8) & F_H) | /*(((V1 ^ V0 ^ 0x8000) & (V1 ^ V2)) >> 13 & F_PV) |*/ ((V2 >> 16) & F_C); H = V2 >> 8 & 0xFF; L = V2 & 0xFF; } return 15;
/* IM 2         */  case 0x0000005E: 
                    case 0x0000007E: IM = 2; return 8;
/* LD A,R       */  case 0x0000005F: F = (F & F_C) | SZ_T[A = Math.abs(RND.nextInt() % 256)] | (IFF2 ? F_PV : 0); return 9;
//  ----------------------------------------------------------------------------
/* IN H,(C)     */  case 0x00000060: F = (F & F_C) | SZP_T[H = RDPORT(B << 8 | C)]; return 12;
/* OUT (C),H    */  case 0x00000061: WRPORT(B << 8 | C, H); return 12;
/* SBC HL,HL    */  case 0x00000062: { int V0 = H << 8 | L, V1 = V0, V2 = V0 - V1 - (F & F_C); F = ((V2 >> 8) & F_S) | (((V2 & 0xFFFF) != 0) ? 0 : F_Z) | (((V0 ^ V2 ^ V1) >> 8) & F_H) | (((V1 ^ V0) & (V0 ^ V2)) >> 13 & F_PV) | ((V2 >> 16) & F_C) | F_N; H = V2 >> 8 & 0xFF; L = V2 & 0xFF; } return 15;
/* RRD          */  case 0x00000067: { int V0 = 0x00FF & RDMEM[H][L]; WRMEM[H][L] = (byte)(V0 >> 4 | (A & 0x0F) << 4); F = (F & F_C) | SZP_T[A = (A & 0xF0) | (V0 & 0x0F)]; } return 18;
//  ----------------------------------------------------------------------------
/* IN L,(C)     */  case 0x00000068: F = (F & F_C) | SZP_T[L = RDPORT(B << 8 | C)]; return 12;
/* OUT (C),L    */  case 0x00000069: WRPORT(B << 8 | C, L); return 12;
/* ADC HL,HL    */  case 0x0000006A: { int V0 = H << 8 | L, V1 = V0, V2 = V0 + V1 + (F & F_C); F = ((V2 >> 8) & F_S) | (((V2 & 0xFFFF) !=0) ? 0 : F_Z) | (((V0 ^ V2 ^ V1) >> 8) & F_H) | /*(((V1 ^ V0 ^ 0x8000) & (V1 ^ V2)) >> 13 & F_PV) |*/ ((V2 >> 16) & F_C); H = V2 >> 8 & 0xFF; L = V2 & 0xFF; } return 15;
/* RLD          */  case 0x0000006F: { int V0 = 0x00FF & RDMEM[H][L]; WRMEM[H][L] = (byte)((V0 & 0x0F) << 4 | (A & 0x0F)); F = (F & F_C) | SZP_T[A = (A & 0xF0) | V0 >> 4]; } return 18;
//  ----------------------------------------------------------------------------
/* IN F,(C)     */  case 0x00000070: F = (F & F_C) | SZP_T[RDPORT(B << 8 | C)]; return 12;
/* OUT (C),0    */  case 0x00000071: WRPORT(B << 8 | C, 0); return 12;
/* SBC HL,SP    */  case 0x00000072: { int V0 = H << 8 | L, V1 = HSP << 8 | LSP, V2 = V0 - V1 - (F & F_C); F = ((V2 >> 8) & F_S) | (((V2 & 0xFFFF) != 0) ? 0 : F_Z) | (((V0 ^ V2 ^ V1) >> 8) & F_H) | (((V1 ^ V0) & (V0 ^ V2)) >> 13 & F_PV) | ((V2 >> 16) & F_C) | F_N; H = V2 >> 8 & 0xFF; L = V2 & 0xFF; } return 15;
//  ----------------------------------------------------------------------------
/* IN A,(C)     */  case 0x00000078: F = (F & F_C) | SZP_T[A = RDPORT(B << 8 | C)]; return 12;
/* OUT (C),A    */  case 0x00000079: WRPORT(B << 8 | C, A); return 12;
/* ADC HL,SP    */  case 0x0000007A: { int V0 = H << 8 | L, V1 = HSP << 8 | LSP, V2 = V0 + V1 + (F & F_C); F = ((V2 >> 8) & F_S) | (((V2 & 0xFFFF) !=0) ? 0 : F_Z) | (((V0 ^ V2 ^ V1) >> 8) & F_H) | /*(((V1 ^ V0 ^ 0x8000) & (V1 ^ V2)) >> 13 & F_PV) |*/ ((V2 >> 16) & F_C); H = V2 >> 8 & 0xFF; L = V2 & 0xFF; } return 15;
//  ----------------------------------------------------------------------------
/* LDI          */  case 0xFFFFFFA0: WRMEM[D][E] = RDMEM[H][L]; if(E++ == 0xFF) { E = 0x00; D = INC[D]; } if(L++ == 0xFF) { L = 0x00; H = INC[H]; } if(C-- == 0x00) { C = 0xFF; B = DEC[B]; } F = (F & F_SZC) | ((B | C) != 0 ? F_PV : 0); return 16;
/* CPI          */  case 0xFFFFFFA1: { int V0 = 0x00FF & RDMEM[H][L], V1 = A - V0; if(L++ == 0xFF) { L = 0x00; H = INC[H]; } if(C-- == 0x00) { C = 0xFF; B = DEC[B]; } F = (F & F_C) | F_N | SZ_T[V1 &= 0xFF] | ((A & 0xF) - (V0 & 0xF) & F_H) | ((B | C) != 0 ? F_PV : 0); } return 16;
/* INI          */  case 0xFFFFFFA2: WRMEM[H][L] = (byte)(RDPORT(B << 8 | C)); if(L++ == 0xFF) { L = 0x00; H = INC[H]; } F = F_N | ((B = DEC[B]) == 0 ? F_Z : 0); return 16;
/* OUTI         */  case 0xFFFFFFA3: WRPORT(B << 8 | C, 0x00FF & RDMEM[H][L]); if(L++ == 0xFF) { L = 0x00; H = INC[H]; } F = F_N | ((B = DEC[B]) == 0 ? F_Z : 0); return 16;    
//  ----------------------------------------------------------------------------
/* LDD          */  case 0xFFFFFFA8: WRMEM[D][E] = RDMEM[H][L]; if(E-- == 0x00) { E = 0xFF; D = DEC[D]; } if(L-- == 0x00) { L = 0xFF; H = DEC[H]; } if(C-- == 0x00) { C = 0xFF; B = DEC[B]; } F = (F & F_SZC) | ((B | C) != 0 ? F_PV : 0); return 16;
/* CPD          */  case 0xFFFFFFA9: { int V0 = 0x00FF & RDMEM[H][L], V1 = A - V0; if(L-- == 0x00) { L = 0xFF; H = DEC[H]; } if(C-- == 0x00) { C = 0xFF; B = DEC[B]; } F = (F & F_C) | F_N | SZ_T[V1 &= 0xFF] | ((A & 0xF) - (V0 & 0xF) & F_H) | ((B | C) != 0 ? F_PV : 0); } return 16;
/* IND         ?*/  case 0xFFFFFFAA: WRMEM[H][L] = (byte)(RDPORT(B << 8 | C)); if(L-- == 0x00) { L = 0xFF; H = DEC[H]; } F = F_N | ((B = DEC[B]) == 0 ? F_Z : 0); return 16;
/* OUTD        ?*/  case 0xFFFFFFAB: WRPORT(B << 8 | C, 0x00FF & RDMEM[H][L]); if(L-- == 0x00) { L = 0xFF; H = DEC[H]; } F = F_N | ((B = DEC[B]) == 0 ? F_Z : 0); return 16;    
//  ----------------------------------------------------------------------------
/* LDIR         */  case 0xFFFFFFB0: 
//    WRMEM[D][E] = RDMEM[H][L];
//    if(E++ == 0xFF) { E = 0x00; D = INC[D]; }
//    if(L++ == 0xFF) { L = 0x00; H = INC[H]; }
//    if(C-- == 0x00) { C = 0xFF; B = DEC[B]; }
//    F = (F & F_SZC) | ((B | C) != 0 ? F_PV : 0);
//    if(((B | C)) != 0) { 
//        if((LPC -= 2) < 0) { LPC &= 0xFF; HPC = DEC[HPC]; }
//        return 21;
//    } 
//    return 16;
{
    int V0 = (tstates + 20) / 21, V1 = B << 8 | C, V2 = V0 < V1 ? V0 : V1, V3 = V2 * 21;
    while(V2 > 0) {
        if(L == 0 && E == 0 && V2 >= 256) {
            System.arraycopy(RDMEM[H], 0, WRMEM[D], 0, 256);            
            H = INC[H];
            D = INC[D];
            B = DEC[B];
            V2 -= 256;
        } else {
            WRMEM[D][E] = RDMEM[H][L];
            if(L++ == 0xFF) { L = 0x00; H = INC[H]; }
            if(E++ == 0xFF) { E = 0x00; D = INC[D]; }            
            if(C-- == 0x00) { C = 0xFF; B = DEC[B]; }
            V2--;
        }
    }
    F = (F & F_SZC) | ((B | C) != 0 ? F_PV : 0);
    if((B | C) != 0) { 
        if((LPC -= 2) < 0) { LPC &= 0xFF; HPC = DEC[HPC]; }
        return V3;
     }
    return V3 - 5;
}
/* CPIR         */  case 0xFFFFFFB1: 
{ 
    int V0 = 0x00FF & RDMEM[H][L], V1 = A - V0;
    if(L++ == 0xFF) { L = 0x00; H = INC[H]; }
    if(C-- == 0x00) { C = 0xFF; B = DEC[B]; }
    F = (F & F_C) | F_N | SZ_T[V1 &= 0xFF] | ((A & 0xF) - (V0 & 0xF) & F_H) | ((B | C) != 0 ? F_PV : 0);
    if(((B | C)) != 0 && V1 != 0) {
        if((LPC -= 2) < 0) { LPC &= 0xFF; HPC = DEC[HPC]; }
        return 21;
    }
    return 16;
}
/* INIR         */  case 0xFFFFFFB2:
    WRMEM[H][L] = (byte)(RDPORT(B << 8 | C));
    if(L++ == 0xFF) { L = 0x00; H = INC[H]; }
    F = F_N | ((B = DEC[B]) == 0 ? F_Z : 0);
    if(B != 0) { 
        if((LPC -= 2) < 0) { LPC &= 0xFF; HPC = DEC[HPC]; }
        return 21;
    } 
    return 16;
/* OTIR         */  case 0xFFFFFFB3:
    WRPORT(B << 8 | C, 0x00FF & RDMEM[H][L]);
    if(L++ == 0xFF) { L = 0x00; H = INC[H]; }
    F = F_N | ((B = DEC[B]) == 0 ? F_Z : 0);
    if(B != 0) {
        if((LPC -= 2) < 0) { LPC &= 0xFF; HPC = DEC[HPC]; }
        return 21;
    }
    return 16;
//  ----------------------------------------------------------------------------
/* LDDR         */  case 0xFFFFFFB8:
//    WRMEM[D][E] = RDMEM[H][L];
//    if(E-- == 0x00) { E = 0xFF; D = DEC[D]; }
//    if(L-- == 0x00) { L = 0xFF; H = DEC[H]; }
//    if(C-- == 0x00) { C = 0xFF; B = DEC[B]; }
//    F = (F & F_SZC) | ((B | C) != 0 ? F_PV : 0);
//    if(((B | C)) != 0) {
//        if((LPC -= 2) < 0) { LPC &= 0xFF; HPC = DEC[HPC]; }
//        return 21;
//    }
//    return 16;
{
    int V0 = (tstates + 20) / 21, V1 = B << 8 | C, V2 = V0 < V1 ? V0 : V1, V3 = V2 * 21;
    while(V2-- > 0) {        
        WRMEM[D][E] = RDMEM[H][L];
        if(L-- == 0x00) { L = 0xFF; H = DEC[H]; }
        if(E-- == 0x00) { E = 0xFF; D = DEC[D]; }
        if(C-- == 0x00) { C = 0xFF; B = DEC[B]; }
    }
    F = (F & F_SZC) | ((B | C) != 0 ? F_PV : 0);
    if((B | C) != 0) { 
        if((LPC -= 2) < 0) { LPC &= 0xFF; HPC = DEC[HPC]; }
        return V3;
    }
    return V3 - 5;
}
/* CPDR         */  case 0xFFFFFFB9:
{
    int V0 = 0x00FF & RDMEM[H][L], V1 = A - V0;
    if(L-- == 0x00) { L = 0xFF; H = DEC[H]; }
    if(C-- == 0x00) { C = 0xFF; B = DEC[B]; }
    F = (F & F_C) | F_N | SZ_T[V1 &= 0xFF] | ((A & 0xF) - (V0 & 0xF) & F_H) | ((B | C) != 0 ? F_PV : 0);
    if(((B | C)) != 0 && V1 != 0) { 
        if((LPC -= 2) < 0) { LPC &= 0xFF; HPC = DEC[HPC]; }
        return 21;
    }
    return 16;
} 
/* INDR         */  case 0xFFFFFFBA:
    WRMEM[H][L] = (byte)(RDPORT(B << 8 | C));
    if(L-- == 0x00) { L = 0xFF; H = DEC[H]; }
    F = F_N | ((B = DEC[B]) == 0 ? F_Z : 0);
    if(B != 0) {
        if((LPC -= 2) < 0) { LPC &= 0xFF; HPC = DEC[HPC]; }
        return 21;
    } 
    return 16;
/* OTDR         */  case 0xFFFFFFBB: 
    WRPORT(B << 8 | C, 0x00FF & RDMEM[H][L]);
    if(L-- == 0x00) { L = 0xFF; H = DEC[H]; }
    F = F_N | ((B = DEC[B]) == 0 ? F_Z : 0);
    if(B != 0) {
        if((LPC -= 2) < 0) { LPC &= 0xFF; HPC = DEC[HPC]; }
        return 21;
    }
    return 16;
//  ----------------------------------------------------------------------------
        }        
        int BL = 0x00FF & RDMEM[HPC][LPC]; if(LPC++ == 0xFF) { LPC = 0x00; HPC = INC[HPC]; }
        int BH = 0x00FF & RDMEM[HPC][LPC]; if(LPC++ == 0xFF) { LPC = 0x00; HPC = INC[HPC]; }
        switch(OP) {
//  ----------------------------------------------------------------------------            
/* LD (nn),BC   */  case 0x00000043: WRMEM[BH][BL] = (byte)C; if(BL == 0xFF) WRMEM[INC[BH]][0] = (byte)B; else WRMEM[BH][++BL] = (byte)B; return 20;
/* LD BC,(nn)   */  case 0x0000004B: C = 0x00FF & RDMEM[BH][BL]; B = BL == 0xFF ? 0x00FF & RDMEM[INC[BH]][0] : 0x00FF & RDMEM[BH][++BL]; return 20;
/* LD (nn),DE   */  case 0x00000053: WRMEM[BH][BL] = (byte)E; if(BL == 0xFF) WRMEM[INC[BH]][0] = (byte)D; else WRMEM[BH][++BL] = (byte)D; return 20;
/* LD DE,(nn)   */  case 0x0000005B: E = 0x00FF & RDMEM[BH][BL]; D = BL == 0xFF ? 0x00FF & RDMEM[INC[BH]][0] : 0x00FF & RDMEM[BH][++BL]; return 20;
/* LD (nn),HL   */  case 0x00000063: WRMEM[BH][BL] = (byte)L; if(BL == 0xFF) WRMEM[INC[BH]][0] = (byte)H; else WRMEM[BH][++BL] = (byte)H; return 20;
/* LD HL,(nn)   */  case 0x0000006B: L = 0x00FF & RDMEM[BH][BL]; H = BL == 0xFF ? 0x00FF & RDMEM[INC[BH]][0] : 0x00FF & RDMEM[BH][++BL]; return 20;
/* LD (nn),SP   */  case 0x00000073: WRMEM[BH][BL] = (byte)LSP; if(BL == 0xFF) WRMEM[INC[BH]][0] = (byte)HSP; else WRMEM[BH][++BL] = (byte)HSP; return 20;
/* LD HL,(nn)   */  case 0x0000007B: LSP = 0x00FF & RDMEM[BH][BL]; HSP = BL == 0xFF ? 0x00FF & RDMEM[INC[BH]][0] : 0x00FF & RDMEM[BH][++BL]; return 20;
//  ----------------------------------------------------------------------------
        }
        if((LPC -= 2) < 0) { LPC &= 0xFF; HPC = DEC[HPC]; }
        return 8;
    }    
    
//  ============================================================================
//  ������������ ��� ��� ���������� ������ CPU Z80
//  ============================================================================
    private final void generateCPUTables() {
        SZHVC_SUB_ADD_T = new int[256][256];
        SZHV_INC_T  = new int[256];
        SZHV_DEC_T  = new int[256];
        PARITY_T    = new int[256];
        SZP_T       = new int[256];
        SZ_T        = new int[256];        
//      ------------------------------------------------------------------------
        INC         = new int[256];
        DEC         = new int[256];   
//      ------------------------------------------------------------------------        
        RLC         = new int[256];
        RRC         = new int[256];        
//      ------------------------------------------------------------------------        
        for(int v = 0; v < 256; v++) {
            INC[v] = (v + 1) & 0xFF;
            DEC[v] = (v - 1) & 0xFF;            
//          -------------------------------------------------------------------- 
            RLC[v] = (v << 1 | v >> 7) & 0xFF;
            RRC[v] = (v >> 1 | v << 7) & 0xFF;
//          --------------------------------------------------------------------            
            int p = F_PV;
            for(int i = 0; i < 8; i++) if((v & (1 << i)) != 0) p ^= F_PV;
            PARITY_T[v] = p;
//          --------------------------------------------------------------------
            int s = (v & 0x80) != 0 ? F_S : 0;
            int z = v == 0 ? F_Z : 0;
            SZP_T[v] = (SZ_T[v] = s | z) | p;
            SZHV_INC_T[v] = SZ_T[v] | (v == 0x80 ? F_PV : 0) | ((v & 0x0F) == 0x00 ? F_H : 0);
            SZHV_DEC_T[v] = SZ_T[v] | (v == 0x7F ? F_PV : 0) | ((v & 0x0F) == 0x0F ? F_H : 0) | F_N;
//          --------------------------------------------------------------------
        }
        for(int a = 0; a < 256; a++) {
            for(int b = 0; b < 256; b++) {
                int sr = a - b;
                int sf = (sr >> 8 & F_C) | SZ_T[sr &= 0xFF] | (((a ^  b) & (a ^ sr)) >> 5 & F_PV) | ((a & 0xF) - (b & 0xF) & F_H) | F_N;
                int ar = a + b;
                int af = (ar >> 8 & F_C) | SZ_T[ar &= 0xFF] | (((a ^ ~b) & (a ^ ar)) >> 5 & F_PV) | ((a & 0xF) + (b & 0xF) & F_H);                
                SZHVC_SUB_ADD_T[a][b] = ar << 24 | af << 16 | sr << 8 | sf;
            }
        }
        System.gc();
    }
    
    private final void destroyCPUTables() {
        SZHVC_SUB_ADD_T = null;
        SZHV_INC_T  = null;
        SZHV_DEC_T  = null;
        PARITY_T    = null;
        SZP_T       = null;
        SZ_T        = null;        
//      ------------------------------------------------------------------------
        INC         = null;
        DEC         = null;
        RLC         = null;
        RRC         = null;              
        System.gc();
    }
    
//  ============================================================================    
    private final void daa() {
        int V0 = 0, V1, V2;
        if((F & F_H) != 0 || (A & 0x0F) > 0x09) V0 |= 0x06;
        if((F & F_C) != 0 || A > 0x9F || (A > 0x8F && (A & 0x0F) > 0x09)) V0 |= 0x60;
        V1 = A > 0x99 ? F_C : 0;
        if((F & F_N) != 0) {    // sub
            V2 = A - V0;
            F = SZ_T[V2 &= 0xFF] | ((A & 0xF) - (V0 & 0xF) & F_H) | F_N;
        } else {    // add
            V2 = A + V0;
            F = SZ_T[V2 &= 0xFF] | ((A & 0xF) + (V0 & 0xF) & F_H);
        }
        F = F | V1 | PARITY_T[A = V2];
    }


//  =========================================================================================================================================
    
//  ----------------------------------------------------------------------------    
    private Graphics  graphics;    
    private boolean   engine_ok;
//  ============================================================================    
//  �������� ���������� �������������� �������� ������
//  ============================================================================     
    public boolean  full_zoom   = false;
    public int      rot_mode    = 0;
    public int      zoom_align  = 0;
    public int      mid_zoom    = 30; //  percents
    public int      frameskip   = 4;
    public int      res_mode    = 0;
    public int      joy_type    = 4;
    public int      bright_dif  = 85; //  percents

//  ----------------------------------------------------------------------------    
    public boolean  osd_enable  = true;
    public boolean  fps_enable  = true;
    public int      osd_colour  = 2;
//  ----------------------------------------------------------------------------
    public boolean  windowed = false;
    public boolean  mirrored_scale = false;
    public int      max_scr_h = 320;
    public int      max_scr_w = 240;    
//  ----------------------------------------------------------------------------
    private final int PLATFORM_H = 192;
    private final int PLATFORM_W = 256;
//  ----------------------------------------------------------------------------    
    private int       LastH, LastW;
    private int[]     screen;
    private int       DY, DX, SH, SW;
    
    
//  ============================================================================    
//  ������ ������ ������� ������
//  ============================================================================        
    private int[] pal1 = new int[16];
    private int[] pal2 = new int[16];
    
    private void generatePalette() {
        int BR1 = 0xFF, BR0 = BR1 * bright_dif / 100;        
        for(int c = 0; c < 16; c++) {
            int bright = c <= 8 ? BR0 : BR1;
            pal1[c] = ((c & 2) != 0 ? bright : 0) << 16 | ((c & 4) != 0 ? bright : 0) << 8 | ((c & 0x1) != 0 ? bright : 0);
            pal2[c] = pal1[c] >> 1 & 0x007F7F7F;
        }
        
    }
    
//  ============================================================================
//  ���������� �������� ���������� ������
//  ============================================================================    
    protected void screenSizeChanged() {
        int max_side_len = PLATFORM_W > PLATFORM_H ? PLATFORM_W : PLATFORM_H;
        setFullScreenMode(!windowed);   //  ������������� �����
        graphics = getGraphics();       //  ����������� ��������
        LastH = getHeight();            //  ��������� ������ ������
        LastW = getWidth();             //  ��������� ������ ������        
        SH = LastH < max_scr_h ? LastH : max_scr_h; //  ����������� ��������� ��� ��������� ������
        SW = LastW < max_scr_w ? LastW : max_scr_w; //  ����������� ��������� ��� ��������� ������
        SH = SH < max_side_len ? SH : max_side_len; //  ����������� ������ ������������ ������������ �������������� ������
        SW = SW < max_side_len ? SW : max_side_len; //  ����������� ������ ������������ ������������ �������������� ������
        DY = LastH - SH >> 1;   //  �������� ��������� �������� ������� �� ������ �� ��� Y
        DX = LastW - SW >> 1;   //  �������� ��������� �������� ������� �� ������ �� ��� X
        graphics.setColor(0x404040);
        graphics.fillRect(0, 0, LastW, LastH);
        flushGraphics();        
        screen = null; screen = new int[SH * SW];
        recountZooming();                
    }    

//  ============================================================================    
//  ������ � ������������� ��������������� ������
//  ============================================================================
    private boolean ver_line_visible[][];
    private boolean scanline_visible[][];
    private char scry_addr[][];
    private char scrx_addr[][];
    private char fst_visible[];
    private char lst_visible[];
    private int max_zoom;
    
    protected void recountZooming() {
        for(int i = 0; i < screen.length; i++) screen[i] = cur_brd;
        scanline_visible = null; scry_addr = null;
        ver_line_visible = null; scrx_addr = null;
        int PW = rot_mode != 0 ? SH : SW;
        int PH = rot_mode != 0 ? SW : SH;
        max_zoom = PLATFORM_W - PW >> 1;
        scanline_visible = new boolean[max_zoom + 1][PLATFORM_H];
        ver_line_visible = new boolean[max_zoom + 1][PLATFORM_W];
        scry_addr = new char[max_zoom + 1][PLATFORM_H];
        scrx_addr = new char[max_zoom + 1][PLATFORM_W];
        fst_visible = new char[max_zoom + 1];
        lst_visible = new char[max_zoom + 1];
        int index = max_zoom;
        do {
            int VirtualSW = PW + (index << 1);
            int VirtualSH = full_zoom ? (PH < PLATFORM_H ? PH : PLATFORM_H) : (VirtualSW * PLATFORM_H) / PLATFORM_W;
            if(VirtualSH % 2 != 0) VirtualSH--;
            int xs_tab[] = null; xs_tab = new int[VirtualSW];
            int ys_tab[] = null; ys_tab = new int[VirtualSH];
            int sh = (PLATFORM_W * 10000) / VirtualSW;
            int sv = (PLATFORM_H * 10000) / VirtualSH;
            for(int i = 0; i < VirtualSW / 2; i++) {    
                xs_tab[i] = (i * sh) / 10000;
                xs_tab[VirtualSW - 1 - i] = mirrored_scale ? PLATFORM_W - 1 - xs_tab[i] : ((VirtualSW - 1 - i) * sh) / 10000;
            }
            for(int i = 0; i < VirtualSH / 2; i++) {
                ys_tab[i] = (i * sv) / 10000;
                ys_tab[VirtualSH - 1 - i] = mirrored_scale ? PLATFORM_H - 1 - ys_tab[i] : ((VirtualSH - 1 - i) * sv) / 10000;
            }
            for(int i = 0; i < PW; i++) {
                int align_index = zoom_align == 0 ? index + i : (zoom_align == 1 ? i : VirtualSW - PW + i);
                if(rot_mode == 0) scrx_addr[index][xs_tab[align_index]] = (char)i;
                if(rot_mode == 1) scrx_addr[index][xs_tab[align_index]] = (char)(i * PH);
                if(rot_mode == 2) scrx_addr[index][xs_tab[align_index]] = (char)((PW - 1 - i) * PH);
                ver_line_visible[index][xs_tab[align_index]] = true;
            }
            int maxheight, space_y, vbase_y;
            if(VirtualSH > PH) {
                space_y = 0;
                vbase_y = VirtualSH - PH >> 1;
                maxheight = PH;
            } else {
                space_y = PH - VirtualSH >> 1;
                vbase_y = 0;
                maxheight = VirtualSH;
            }
            for(int i = 0; i < maxheight; i++) {
                int scanline = ys_tab[vbase_y + i];
                if(rot_mode == 0) scry_addr[index][scanline] = (char)((i + space_y) * PW);
                if(rot_mode == 1) scry_addr[index][scanline] = (char)(PH - 1 - (i + space_y));
                if(rot_mode == 2) scry_addr[index][scanline] = (char)(i + space_y);
                scanline_visible[index][scanline] = true;
            }
            for(int i = 0;      i < PLATFORM_H; i++) if(scanline_visible[index][i]) { fst_visible[index] = (char)i; break; }
            for(int i = PLATFORM_H - 1; i >= 0; i--) if(scanline_visible[index][i]) { lst_visible[index] = (char)i; break; }
            if(--index < 0) break;
        } while(true);
    }    


    public final void refreshSettings() {
        emulThreadControl(ACT_PAUSE);
        if(screen == null) screenSizeChanged(); else recountZooming();
        graphics.setFont(Font.getFont(0, 0, Font.SIZE_SMALL));
        generatePalette();
        // ..
        emulThreadControl(ACT_RESUME);
        System.gc();
    }
    
   
//  ============================================================================    
//  �����, ����������� ������� ����� ���������� �������
//  ============================================================================         
    private final class ZXKey {
        private byte[] keyArray = new byte[8];
        public ZXKey() { reset(); }        
        public ZXKey(int Part, int Mask) { reset(); keyArray[Part] = (byte)Mask; }
        public ZXKey reset() { for(int i = 0; i < 8; i++) keyArray[i] = (byte)0xFF; return this; }
        public ZXKey add(ZXKey Key) { for(int i = 0; i < 8; i++) keyArray[i] &= Key.keyArray[i]; return this; }
        public int getPart(int Part) { return keyArray[Part] & 0xFF; }
    }
   
//  ============================================================================    
//  ������� ������ ���������� ��� ������������ ������
//  ============================================================================         
    private final ZXKey KEY_CS = new ZXKey(0, 0xFE), KEY_Z  = new ZXKey(0, 0xFD), KEY_X  = new ZXKey(0, 0xFB), KEY_C  = new ZXKey(0, 0xF7), KEY_V  = new ZXKey(0, 0xEF);
    private final ZXKey KEY_A  = new ZXKey(1, 0xFE), KEY_S  = new ZXKey(1, 0xFD), KEY_D  = new ZXKey(1, 0xFB), KEY_F  = new ZXKey(1, 0xF7), KEY_G  = new ZXKey(1, 0xEF);
    private final ZXKey KEY_Q  = new ZXKey(2, 0xFE), KEY_W  = new ZXKey(2, 0xFD), KEY_E  = new ZXKey(2, 0xFB), KEY_R  = new ZXKey(2, 0xF7), KEY_T  = new ZXKey(2, 0xEF);
    private final ZXKey KEY_1  = new ZXKey(3, 0xFE), KEY_2  = new ZXKey(3, 0xFD), KEY_3  = new ZXKey(3, 0xFB), KEY_4  = new ZXKey(3, 0xF7), KEY_5  = new ZXKey(3, 0xEF);
    private final ZXKey KEY_0  = new ZXKey(4, 0xFE), KEY_9  = new ZXKey(4, 0xFD), KEY_8  = new ZXKey(4, 0xFB), KEY_7  = new ZXKey(4, 0xF7), KEY_6  = new ZXKey(4, 0xEF);
    private final ZXKey KEY_P  = new ZXKey(5, 0xFE), KEY_O  = new ZXKey(5, 0xFD), KEY_I  = new ZXKey(5, 0xFB), KEY_U  = new ZXKey(5, 0xF7), KEY_Y  = new ZXKey(5, 0xEF);
    private final ZXKey KEY_EN = new ZXKey(6, 0xFE), KEY_L  = new ZXKey(6, 0xFD), KEY_K  = new ZXKey(6, 0xFB), KEY_J  = new ZXKey(6, 0xF7), KEY_H  = new ZXKey(6, 0xEF);
    private final ZXKey KEY_SP = new ZXKey(7, 0xFE), KEY_SS = new ZXKey(7, 0xFD), KEY_M  = new ZXKey(7, 0xFB), KEY_N  = new ZXKey(7, 0xF7), KEY_B  = new ZXKey(7, 0xEF);
    private final ZXKey ST_KEY = new ZXKey().add(KEY_0).add(KEY_SP).add(KEY_EN).add(KEY_S);
    
    
//  ============================================================================    
//  ��������� � ���������� ��� ���������� ������ � �����������
//  ============================================================================     
    private final int U_ID = 0, D_ID = 1, L_ID = 2, R_ID = 3, F_ID = 4, S_ID = 5; 
    
    private final int[][] joy_rot_map = {
        { U_ID, D_ID, L_ID, R_ID, F_ID }, { L_ID, R_ID, D_ID, U_ID, F_ID }, { R_ID, L_ID, U_ID, D_ID, F_ID,}
    };
    
    private int[] kemp_joy = { 0x08, 0x04, 0x02, 0x01, 0x10 };
    
    private final String[]  JoyNames    = { "Kempston", "Sinclair I", "Sinclair II", "QAOPSp", "Cursor", "Dizzy series" };
    private final ZXKey[]   SinclairI   = { KEY_4, KEY_3, KEY_1, KEY_2, KEY_5  };
    private final ZXKey[]   SinclairII  = { KEY_9, KEY_8, KEY_6, KEY_7, KEY_0  };
    private final ZXKey[]   QAOPSP      = { KEY_Q, KEY_A, KEY_O, KEY_P, KEY_SP };
    private final ZXKey[]   Cursor      = { new ZXKey().add(KEY_CS).add(KEY_7), new ZXKey().add(KEY_CS).add(KEY_6), new ZXKey().add(KEY_CS).add(KEY_5), new ZXKey().add(KEY_CS).add(KEY_8), new ZXKey().add(KEY_CS).add(KEY_EN) };
    private final ZXKey[]   Dizzy       = { KEY_SP, null, KEY_Z, KEY_X, KEY_EN };
    private final ZXKey[][] JoyPointers = { null, SinclairI, SinclairII, QAOPSP, Cursor, Dizzy };

//  ============================================================================    
//  ������� ����������� �� ������� �������� � ����������� �� ����������
//  ============================================================================     
    private ZXKey[] JoyLayers   = new ZXKey[5 + 1];
    
    protected final void keyPressed(int keyCode) {        
        ZXKey[] curr_joy = JoyPointers[joy_type];        
        Keyboard.reset();
        switch(keyCode) {
            case  -1:   //	4-way select up
            case  50:   //	[2]
                if(joy_type != 0) JoyLayers[U_ID] = curr_joy[joy_rot_map[rot_mode][U_ID]]; else KempstJoy |= kemp_joy[joy_rot_map[rot_mode][U_ID]];
                break;
            case  -2:   //	4-way select down
            case  56:   //	[8]
                if(joy_type != 0) JoyLayers[D_ID] = curr_joy[joy_rot_map[rot_mode][D_ID]]; else KempstJoy |= kemp_joy[joy_rot_map[rot_mode][D_ID]];
                break;
            case  -3:   //	4-way select left
            case  52:   //	[4]
                if(joy_type != 0) JoyLayers[L_ID] = curr_joy[joy_rot_map[rot_mode][L_ID]]; else KempstJoy |= kemp_joy[joy_rot_map[rot_mode][L_ID]];
                break;
            case  -4:   //	4-way select right
            case  54:   //	[6]
                if(joy_type != 0) JoyLayers[R_ID] = curr_joy[joy_rot_map[rot_mode][R_ID]]; else KempstJoy |= kemp_joy[joy_rot_map[rot_mode][R_ID]];
                break;
            case  -5:   //	4-way select press
            case  53:   //	[5]
                if(joy_type != 0) JoyLayers[F_ID] = curr_joy[joy_rot_map[rot_mode][F_ID]]; else KempstJoy |= kemp_joy[joy_rot_map[rot_mode][F_ID]];
                break;
            case  48:   //      [0]
                JoyLayers[S_ID] = ST_KEY;
        }
        for(int i = 0; i < JoyLayers.length; i++) if(JoyLayers[i] != null) Keyboard.add(JoyLayers[i]);
        switch(keyCode) {                        
            case  49:   //	[1]
                if(max_zoom == 0) return;
                if(--MID_ZOOM < 0) MID_ZOOM = 0;
                new_zoom = MID_ZOOM;
                mid_zoom = (100 * MID_ZOOM) / max_zoom;
                print_osd("Zoom out: " + mid_zoom + "%");
                return;
            case  51:   //	[3]
                if(max_zoom == 0) return;
                if(++MID_ZOOM > max_zoom) MID_ZOOM = max_zoom;
                new_zoom = MID_ZOOM;
                mid_zoom = (100 * MID_ZOOM) / max_zoom;
                print_osd("Zoom in: " + mid_zoom + "%");
                return;
            case  55:   //	[7]
                full_zoom = !full_zoom;
                print_osd("Disproportions: " + (full_zoom ? "ON" : "OFF"));
                refreshSettings();
                return;
            case  57:   //	[9]
                String[] arr = { "Center", "Left", "Right" };
                if(++zoom_align > 2) zoom_align = 0;
                print_osd("Zoom align: " + arr[zoom_align]);
                refreshSettings();
                return;                
            case  35:   //	[#]
                if(++joy_type >= JoyPointers.length) joy_type = 0;
                print_osd("Joystick: " + JoyNames[joy_type]);
                return;
            case  -8:   //	C key (Clear)
                if(++rot_mode > 2) rot_mode = 0;
                print_osd("Display rotation");
                refreshSettings();
                return;                
        }
    }
    
    protected void keyReleased(int keyCode) {
        Keyboard.reset();
        switch(keyCode) {
            case  -1:   //	4-way select up
            case  50:   //	[2]
                JoyLayers[U_ID] = null; KempstJoy &= ~kemp_joy[joy_rot_map[rot_mode][U_ID]];
                break;
            case  -2:   //	4-way select down
            case  56:   //	[8]
                JoyLayers[D_ID] = null; KempstJoy &= ~kemp_joy[joy_rot_map[rot_mode][D_ID]];
                break;
            case  -3:   //	4-way select left
            case  52:   //	[4]
                JoyLayers[L_ID] = null; KempstJoy &= ~kemp_joy[joy_rot_map[rot_mode][L_ID]];
                break;
            case  -4:   //	4-way select right
            case  54:   //	[6]
                JoyLayers[R_ID] = null; KempstJoy &= ~kemp_joy[joy_rot_map[rot_mode][R_ID]];
                break;
            case  -5:   //	4-way select press
            case  53:   //	[5]
                JoyLayers[F_ID] = null; KempstJoy &= ~kemp_joy[joy_rot_map[rot_mode][F_ID]];
                break;
            case  48:   //      [0]
                JoyLayers[S_ID] = null;
        }
        for(int i = 0; i < JoyLayers.length; i++) if(JoyLayers[i] != null) Keyboard.add(JoyLayers[i]);
    }
    
    protected final void keyRepeated(int keyCode) {
        switch(keyCode) {
            case  49:   //	[1]
            case  51:   //	[3]
                keyPressed(keyCode);
        }
    }    
    
//  ============================================================================
    public void loadSNA(InputStream is) throws IOException {
        boolean Mode128K = false; int header[] = new int[27];
        Mode128K = is.available() > 49179;            
        for(int i = 0; i < 27; i++) header[i] = 0xFF & is.read();            
        tr_dos = false; P7FFD = 0x30; 
        for(int i = 0; i < 64; i++) is.read(MEM[(RAM + 0x05) * 64 + i]); 
        for(int i = 0; i < 64; i++) is.read(MEM[(RAM + 0x02) * 64 + i]); 
        for(int i = 0; i < 64; i++) is.read(MEM[(RAM + 0x00) * 64 + i]); 
        if(Mode128K) { 
            LPC    = 0xFF & is.read();
            HPC    = 0xFF & is.read();
            P7FFD  = 0xFF & is.read();
            tr_dos = 0x0 != is.read();                
            int cur = P7FFD & 0x07;
            for(int i = 0; i < 64; i++) System.arraycopy(MEM[(RAM + 0x00) * 64 + i], 0, MEM[(RAM + cur) * 64 + i], 0, 256);
            for(int p = 0; p < 8; p++) {
                if(p == 5 || p == 2 || p == cur) continue;
                for(int i = 0; i < 64; i++) is.read(MEM[(RAM + p) * 64 + i]); 
            }
        }
        setupROMpage();
        setupRAMpage();
        cur_brd = pal1[header[0x1A] & 0x07];
        L2  = header[0x01]; H2  = header[0x02];
        E2  = header[0x03]; D2  = header[0x04];
        C2  = header[0x05]; B2  = header[0x06];
        F2  = header[0x07] & 0xD7; 
        A2  = header[0x08];        
        L   = header[0x09]; H   = header[0x0A];
        E   = header[0x0B]; D   = header[0x0C];
        C   = header[0x0D]; B   = header[0x0E];
        F   = header[0x15] & 0xD7;
        A   = header[0x16];
        LIY = header[0x0F]; HIY = header[0x10];
        LIX = header[0x11]; HIX = header[0x12];
        LSP = header[0x17]; HSP = header[0x18];        
        IM  = header[0x19]; I   = header[0x00];
        IFF1 = IFF2 = (header[0x13] & 0x04) != 0;
        if(!Mode128K) {
            LPC = 0xFF & RDMEM[HSP][LSP];
            if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; }
            HPC = 0xFF & RDMEM[HSP][LSP];
            if(LSP++ == 0xFF) { LSP = 0x00; HSP = INC[HSP]; }
        }
        print_osd("Image type: SNA " + (Mode128K ? "128" : "48") + "K");                
    }
    
    public void loadZ80(InputStream is) throws IOException {
        String path = "%path%";
        int left = is.available();  
        int header[] = new int[30];        
        for(int i = 0; i < header.length; i++, left--) header[i] = 0xFF & is.read();
        if(header[0x0C] == 0xFF) header[0x0C] = 0x01; 
        if((header[0x06] | header[0x07]) == 0) {
            System.out.println("Extended mode");
            int add_header_len = (0xFF & is.read()) | (0xFF & is.read()) << 8;
            left -= 2; int version = 0;
            System.out.println("add_header_len: " + add_header_len);
            switch(add_header_len) {
                case 23: version = 0x20; break;
                case 54: 
                case 55: version = 0x30; break;
                default: throw new IOException("\n\n" + path + "\n\n" + "Z80: " + "Unsupported version");
            }
            int add_header[] = new int[add_header_len];
            for(int i = 0; i < add_header.length; i++, left--) add_header[i] = 0xFF & is.read();            
            boolean Mode128K = false;
            switch(version << 8 | add_header[0x02]) {
                case 0x2003:    //  v2.x 128K
                case 0x2004:    //  v2.x 128K + If.1
                case 0x2009:    //  v2.x Pentagon 128K
                case 0x3004:    //  v3.x 128K
                case 0x3005:    //  v3.x 128K + If.1
                case 0x3006:    //  v3.x 128K + M.G.T
                case 0x3009:    //  v3.x Pentagon 128K                
                    Mode128K = true; break;
                case 0x2000:    //  v2.x 48K
                case 0x2001:    //  v2.x 48K + If.1
                case 0x3000:    //  v3.x 48K
                case 0x3001:    //  v3.x 48K + If.1
                case 0x3003:    //  v3.x 48K + M.G.T                
                    Mode128K = false; break;
                default: 
                    System.out.println("mashine type: " + Integer.toHexString(version << 8 | add_header[0x02]));
                    throw new IOException("\n\n" + path + "\n\n" + "Z80: " + "Unsupported mashine type");
            }
            System.out.println("Memory mode: " + (Mode128K ? "128K" : "48K"));            
            while(left > 0) {
                int bufflen = (0xFF & is.read()) | (0xFF & is.read()) << 8;
                int page = 0xFF & is.read(); left -= 3;
                if(!Mode128K) {
                    switch(page) {
                        case  4: page = 2; break;
                        case  5: page = 0; break;
                        case  8: page = 5; break;
                        default: throw new IOException("\n\n" + path + "\n\n" + "Z80: " + "Wrong memory page");
                    }
                } else page -= 3;                
                if(bufflen == 0xFFFF) {
                    System.out.println("pages: uncompressed mode");
                    for(int i = 0; i < 64; i++) left -= is.read(MEM[(RAM + page) * 64 + i]); 
                } else {
                    System.out.println("pages: compressed mode");
                    byte buffer[] = null; buffer = new byte[bufflen];
                    left -= is.read(buffer);                    
                    int addr = 0x0000, bpos = 0, tbyte;                   
                    while(addr <= 0x3FFF && bpos < bufflen) {                
                        if((tbyte = buffer[bpos++] & 0xFF) != 0xED) {
                            MEM[(RAM + page) * 64 + (addr >> 8)][addr++ & 0xFF] = (byte)tbyte;
                            continue;
                        }                
                        if((tbyte = buffer[bpos++] & 0xFF) != 0xED) {                           
                            MEM[(RAM + page) * 64 + (addr >> 8)][addr++ & 0xFF] = (byte)0xED;
                            MEM[(RAM + page) * 64 + (addr >> 8)][addr++ & 0xFF] = (byte)tbyte;
                            continue;
                        }
                        int count = buffer[bpos++] & 0xFF;
                        tbyte = buffer[bpos++] & 0xFF;                
                        while(count-- > 0 && addr <= 0x3FFF) {
                            MEM[(RAM + page) * 64 + (addr >> 8)][addr++ & 0xFF] = (byte)tbyte;
                        }
                    }       
                }                
            }
            tr_dos = false; P7FFD = Mode128K ? add_header[0x04] & 0x3F : 0x30; 
            setupROMpage();
            setupRAMpage();
            LPC = add_header[0x00]; HPC = add_header[0x01];
            print_osd("Image type: Z80 " + (Mode128K ? "128" : "48") + "K");                
        } else {
            tr_dos = false; P7FFD = 0x30;
            setupROMpage();
            setupRAMpage();
            if((header[0x0C] & 0x20) != 0) {
                System.out.println("48K compressed mode");                
                byte buffer[] = new byte[left];
                int size = is.read(buffer);
                int addr = 0x4000, bpos = 0, tbyte;                                        
                while(addr <= 0xFFFF && bpos < size) {                
                    if((tbyte = buffer[bpos++] & 0xFF) != 0xED) {
                        WRMEM[addr >> 8][addr++ & 0xFF] = (byte)tbyte;
                        continue;
                    }                
                    if((tbyte = buffer[bpos++] & 0xFF) != 0xED) {
                        WRMEM[addr >> 8][addr++ & 0xFF] = (byte)0xED;                    
                        WRMEM[addr >> 8][addr++ & 0xFF] = (byte)tbyte;
                        continue;
                    }
                    int count = buffer[bpos++] & 0xFF;
                    tbyte = buffer[bpos++] & 0xFF;                
                    while(count-- > 0 && addr <= 0xFFFF) {
                        WRMEM[addr >> 8][addr++ & 0xFF] = (byte)tbyte;
                    }
                }        
            } else {
                System.out.println("48K uncompressed mode");
                for(int i = 0x40; i <= 0xFF; i++) is.read(WRMEM[i]);            
            }
            LPC = header[0x06]; HPC = header[0x07];
            print_osd("Image type: Z80 48K");
        }
        A   = header[0x00]; F   = header[0x01];
        C   = header[0x02]; B   = header[0x03];
        L   = header[0x04]; H   = header[0x05];        
        LSP = header[0x08]; HSP = header[0x09];
        I   = header[0x0A];
        cur_brd = pal1[header[0x0C] >> 1 & 0x07];       
        E   = header[0x0D]; D   = header[0x0E];
        C2  = header[0x0F]; B2  = header[0x10];
        E2  = header[0x11]; D2  = header[0x12];
        L2  = header[0x13]; H2  = header[0x14];
	A2  = header[0x15]; F2  = header[0x16];
        LIY = header[0x17]; HIY = header[0x18];
        LIX = header[0x19]; HIX = header[0x1A];
        IFF1 = header[0x1B] != 0;
        IFF2 = header[0x1C] != 0;
        IM = header[0x1D] & 0x03;
    }
    // ...    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
