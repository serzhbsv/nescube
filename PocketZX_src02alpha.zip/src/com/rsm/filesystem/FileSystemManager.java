package com.rsm.filesystem;

import com.rsm.filesystem.container.ContainerManager;

public abstract class FileSystemManager {
    
    private static boolean jsr75enable = true;
    private static FileSystem instance = null;
        
    public static FileSystem getFileSystem(boolean jsr75enabled, String[] filter, String resfolder) {
        jsr75enable = jsr75enabled;
        instance    = null;
        if(isJSR75available())
            instance = new FileSystemJSR75(filter, resfolder);
        else
            instance = new FileSystem(filter, resfolder);
        return instance;
    }
    
    public static FileSystem getFileSystem() {
        return instance;
    }
    
    public static boolean isJSR75available() {
        return (jsr75enable && System.getProperty("microedition.io.file.FileConnection.version") != null);
    }
    
    public static String[] getSupportedFileContainers() {
        return ContainerManager.getSupportedFileContainers();
    }

    public static String[] getSupportedLogicalContainers() {
        return ContainerManager.getSupportedLogicalContainers();
    }
    
    public static void addPropertyToLogConainer(String containerName, String property) {
        ContainerManager.addPropertyToLogConainer(containerName, property);
    }
}
