package com.rsm.filesystem.container;

import com.topcoder.mobile.util.compression.*;
import com.topcoder.mobile.util.compression.decomp.*;
import java.io.*;
import java.util.*;

public class ContainerZIP implements ContainerManager.Container {
    
    protected Hashtable tree;    
    
    public ContainerZIP(String archiveFileName, InputStream archiveFileInputStream) {
        String path, file;
        tree = new Hashtable();
        tree.put(SEPARATOR, new Vector());
        try {
            ZipInputStream zis = new ZipInputStream(archiveFileInputStream);
            ZipEntry zen;
            while((zen = zis.getNextEntry()) != null) {
                path = SEPARATOR + zen.getName();                
                do {
                    int i = path.lastIndexOf(SEPARATOR.charAt(0), path.length() - 2);
                    file  = path.substring(i + 1, path.length());
                    path  = path.substring(0, i + 1);
                    if(tree.get(path) == null) tree.put(path, new Vector());
                    Vector v = (Vector)tree.get(path);
                    if(!v.contains(file)) v.addElement(file);                    
                } while(!path.equals(SEPARATOR));
            }
            zis.close();
        } catch(Throwable t) {}    
    }        

    public String[] getFileList(String folderInArchive) {        
        Vector v = (Vector)tree.get(folderInArchive);
        String[] list = new String[v.size()];
        v.copyInto(list);        
        return list;
    }    

    public InputStream getInputStream(String pathInArchive, InputStream archiveFileInputStream) throws IOException {        
        ZipInputStream zis = new ZipInputStream(archiveFileInputStream);
        ZipEntry zen;
        while((zen = zis.getNextEntry()) != null) {
            if((SEPARATOR + zen.getName()).equals(pathInArchive)) break;
        }
        return zis;
    }    

    public boolean islogical() {
        return false;
    }
   
}
