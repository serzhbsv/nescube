package com.rsm.filesystem.container;

import java.io.InputStream;
import java.util.Vector;

public class ContainerJAR extends ContainerZIP implements ContainerManager.Container {
    
    public ContainerJAR(String archiveFileName, InputStream archiveFileInputStream) {
        super(archiveFileName, archiveFileInputStream);
        ((Vector)tree.get(SEPARATOR)).removeElement("META-INF" + SEPARATOR);
    }
   
}
