package com.rsm.filesystem.container;

import com.topcoder.mobile.util.compression.decomp.GZIPInputStream;
import java.io.*;

public class ContainerGZIP implements ContainerManager.Container {
    
    private String[] content = new String[1];
    
    public ContainerGZIP(String archiveFileName, InputStream archiveFileInputStream) {
        content[0] = archiveFileName.substring(0, archiveFileName.indexOf(".gz"));
    }

    public String[] getFileList(String folderInArchive) {
        return content;
    }

    public InputStream getInputStream(String pathInArchive, InputStream archiveFileInputStream) throws IOException {
        return new GZIPInputStream(archiveFileInputStream);
    }

    public boolean islogical() {
        return false;
    }
    
}
