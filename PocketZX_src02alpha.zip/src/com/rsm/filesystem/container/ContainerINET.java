package com.rsm.filesystem.container;

import com.rsm.util.parse.INIReader;
import com.topcoder.mobile.util.compression.decomp.GZIPInputStream;
import java.io.*;
import java.util.Vector;
import javax.microedition.io.*;
import javax.microedition.rms.RecordStore;

public class ContainerINET implements ContainerManager.Container {
    
    private final  String CACHE_S = "cached";
    private final  int CACHE_SIZE = 5;
    private final  String FOLDERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ#";
    private final  String CATALOG = "cat.ini";
    private static String server;
    private static INIReader cat;
    
    public ContainerINET(String serverUrl) {
        server = serverUrl;
        if(cat == null) {
            try {            
                cat = new INIReader(new ByteArrayInputStream(readInetFile(server + SEPARATOR + CATALOG)));
            } catch(Throwable t) {}
        }
    }

    public String[] getFileList(String folderInArchive) {
        Vector v = new Vector();
        if(cat != null) {
            if(folderInArchive.equals("/")) {            
                for(int i = 0; i < FOLDERS.length(); i++) {
                    if(isCategoryPresent(FOLDERS.charAt(i))) v.addElement((String)(FOLDERS.substring(i, i + 1) + SEPARATOR));
                }
            } else {
                String[] lst = cat.getINI();
                char symb = folderInArchive.charAt(1);
                for(int i = 0; i < lst.length; i += 2) {
                    char ch = lst[i].toUpperCase().charAt(0);
                    if(symb == '#' && (ch < 'A' || ch > 'Z')) v.addElement(lst[i]);
                    else
                    if(symb == ch) v.addElement(lst[i]);
                }            
            }
        }
        String[] list = new String[v.size()];
        v.copyInto(list);        
        return list;
    }
    
    public InputStream getInputStream(String pathInArchive, InputStream archiveFileInputStream) throws IOException {
        String filename = pathInArchive.substring(pathInArchive.lastIndexOf(SEPARATOR.charAt(0)) + 1);
        String realname = cat.readKey(filename, filename);
        String rms_name = getFileRMSName(realname);
//      ------------------------------------------------------------------------        
        String[] stores = RecordStore.listRecordStores();
        Vector temp = new Vector();        
        for(int i = 0; i < stores.length; i++) {
            if(stores[i].equals(rms_name)) {
                byte[] file = loadDataFromRMS(rms_name);
                return new GZIPInputStream(new ByteArrayInputStream(file));
            }
            if(stores[i].startsWith(CACHE_S)) temp.addElement(stores[i]);
        }
        stores = new String[temp.size()];
        temp.copyInto(stores);
//      ------------------------------------------------------------------------        
        if(stores.length >= CACHE_SIZE) {
            try {
                RecordStore curRec = null, oldRec = null; int old = 0;
                for(int i = 1; i < stores.length; i++) {                    
                    oldRec = RecordStore.openRecordStore(stores[old], false);
                    curRec = RecordStore.openRecordStore(stores[i]  , false);
                    if(curRec.getLastModified() < oldRec.getLastModified()) old = i;
                    if(oldRec != null) { oldRec.closeRecordStore(); oldRec = null; }
                    if(curRec != null) { curRec.closeRecordStore(); curRec = null; }
                }
                RecordStore.deleteRecordStore(stores[old]);
            } catch(Throwable t) {
                t.toString();
            }            
        }
//      ------------------------------------------------------------------------        
        byte[] file = readInetFile(server + SEPARATOR + realname);
        saveDataToRMS(rms_name, file);        
        return new GZIPInputStream(new ByteArrayInputStream(file)); 
    }
    
    public boolean islogical() {
        return true;
    }
    
    private byte[] readInetFile(String url) throws IOException {
        StreamConnection sc = null;
        InputStream is = null;
        ByteArrayOutputStream baos = null;
        try {
            sc = (StreamConnection)Connector.open(url);
            is = sc.openInputStream();
            baos = new ByteArrayOutputStream();
            int rdbyte;
            while((rdbyte = is.read()) >= 0) baos.write(rdbyte);        
        } finally {
            if(baos != null) baos.close();
            if(is != null) is.close();
            if(sc != null) sc.close();            
        }
        return baos.toByteArray();
    }
    
    private boolean isCategoryPresent(char symb) {
        String[] lst = cat.getINI();
        for(int i = 0; i < lst.length; i += 2) {
            char ch = lst[i].toUpperCase().charAt(0);
            if(symb == '#' && (ch < 'A' || ch > 'Z')) return true;
            if(symb == ch) return true;
        }
        return false;
    }

    private void saveDataToRMS(String name, byte[] data) {
        RecordStore record;
        try {
            RecordStore.deleteRecordStore(name);
        } catch(Throwable t) {} 
        try {
            record = RecordStore.openRecordStore(name, true);            
            record.addRecord(data, 0, data.length);
            record.closeRecordStore();
        } catch(Throwable t) {}
    }        

    private byte[] loadDataFromRMS(String name) {
        RecordStore record;
        byte[] data = null;
        try{
            record = RecordStore.openRecordStore(name, false);            
            data = record.getRecord(record.getNextRecordID() - 1);           
            record.closeRecordStore();
        } catch(Throwable t) {}
        return data;
    }
    
    private String getFileRMSName(String filename) {
        int hashCode = 0xA55AA55A;
        for(int i = 0; i < filename.length(); i++) {            
            hashCode = hashCode ^ filename.charAt(i) ^ (hashCode << 3);
        }
        return CACHE_S + Integer.toHexString(hashCode);
    }
    
}
