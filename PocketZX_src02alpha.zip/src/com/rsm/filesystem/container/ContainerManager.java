package com.rsm.filesystem.container;

import java.io.*;
import java.util.Hashtable;

public abstract class ContainerManager {
    
    public interface Container {    
        public String       SEPARATOR = "/";
        public boolean      islogical();
        public String[]     getFileList(String folderInArchive);
        public InputStream  getInputStream(String pathInArchive, InputStream archiveFileInputStream) throws IOException;
    }
    
    private static final String[] file_containers = { "zip", "gz", "jar" };
    private static final String[] logi_containers = new String[0];//{ "Internet" };
    
    private static Hashtable lConProp = new Hashtable();
    
    public static String[] getSupportedFileContainers() {
        return file_containers;
    }
    
    public static String[] getSupportedLogicalContainers() {
        return logi_containers;
    }
    
    public static int getContainerIndex(String filename) {
        for(int i = 0; i < file_containers.length; i++)
            if(filename.toLowerCase().endsWith("." + file_containers[i])) return i;
        for(int i = 0; i < logi_containers.length; i++)
            if(filename.equals(logi_containers[i])) return file_containers.length + i;        
        return -1;
    }
    
    public static void addPropertyToLogConainer(String containerName, String property) {
        lConProp.put(containerName, property);
    }
    
    public static Container openContainer(String archiveFileName, InputStream archiveFileInputStream) {
        int contIndex = getContainerIndex(archiveFileName);
        if(contIndex < file_containers.length) {
            switch(contIndex) {
                case 0: //  zip
                    return new ContainerZIP  (archiveFileName, archiveFileInputStream);
                case 1: //  gzip
                    return new ContainerGZIP (archiveFileName, archiveFileInputStream);
                case 2: //  jar
                    return new ContainerJAR  (archiveFileName, archiveFileInputStream);            
            }
        } else {
            String containerProperty = (String)lConProp.get(archiveFileName);
            switch(contIndex - file_containers.length) {
                case 0: //  Internet
                    return new ContainerINET (containerProperty);
            }
        }        
        return null;
    }
        
}
