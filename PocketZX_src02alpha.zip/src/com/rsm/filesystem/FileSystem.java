package com.rsm.filesystem;

import com.rsm.util.parse.INIReader;
import java.io.InputStream;
import java.util.Vector;

public class FileSystem {
    public final String FILE_LIST = "files.res";
        
    protected String ResFolder;
    protected String LastFile;
    protected String[] Filter;    
    
    public FileSystem(String[] filter, String resfolder) {
        setFileFilter(filter);
        ResFolder = resfolder;
        LastFile = "";
    }
    
    public void setFileFilter(String[] filter) {
        Filter = new String[filter.length];
        for(int i = 0; i < Filter.length; i++) Filter[i] = filter[i].toLowerCase().trim();
    }
    
    public String[] getFileList(String filename) {
        if(!filename.equals("")) return null;
        String[] list = (new INIReader(ResFolder + FILE_LIST)).getINI();
        Vector v = new Vector();
        for(int i = 0; i < Filter.length; i++) {
            for(int n = 0; n < list.length; n++) {
                if(list[n].toLowerCase().endsWith("." + Filter[i])) v.addElement(list[n]);
            }
        }
        list = new String[v.size()];
        v.copyInto(list);        
        return list;
    }
    
    public int getFileTypeIndex(String filename) {
        for(int i = 0; i < Filter.length; i++)
            if(filename.toLowerCase().endsWith("." + Filter[i])) return i;      //  Filter type index
        return -1;                                                              //  Unknown type
    }
    
    public InputStream getInputStream(String filename) {                        //  ��� �������� ������ ����������
        InputStream is = getClass().getResourceAsStream(ResFolder + filename);
        if(is != null) LastFile = filename;
        return is;
    }        
    
    public String getCurrentFolder() {        
        return ResFolder;
    }
    
    public String getCurrentFile() {        
        return LastFile;
    }
        
}


