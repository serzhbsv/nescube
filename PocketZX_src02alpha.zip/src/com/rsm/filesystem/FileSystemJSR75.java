package com.rsm.filesystem;

import com.rsm.filesystem.container.*;
import java.util.*;
import java.io.*;
import javax.microedition.io.file.*;
import javax.microedition.io.Connector;

public class FileSystemJSR75 extends FileSystem {
       
    private final String SEPARATOR = "/";    
    private final String DEVICE_ID = ":" + SEPARATOR;
    private final String FOLDER_ID = SEPARATOR;
    private final String UP_FOLDER = "..";
        
    private ContainerManager.Container container = null;
    private JSR75  fsobject = new JSR75();
    private String FullPath = "";
    private String ContPath = "";
    
    private class JSR75 implements FileSystemListener {        
        private boolean setListener = false;
        private FileConnection fc;
        
        public void rootChanged(int i, String string) {            
        }
    
        public Enumeration getRoot() {
            if(!setListener) {
                FileSystemRegistry.addFileSystemListener(this);
                setListener = true;
            }
            return FileSystemRegistry.listRoots();
        }
        
        public void openConnection(String path) throws IOException {
            fc = (FileConnection)Connector.open("file://" + path, Connector.READ);
        }
        
        public void closeConnection() throws IOException {
            fc.close();
        }
        
        public Enumeration getList() throws IOException {            
            return fc.list();
        }
        
        public InputStream getInputStream(String path) throws IOException {
            openConnection(path);            
            return fc.openInputStream(); 
        }
    
    }
                
    public FileSystemJSR75(String[] filter, String resfolder) {
        super(filter, resfolder);
        FullPath = SEPARATOR;        
    }
            
    public String[] getFileList(String filename) {
//  filename == ""   - �������� ������ �������� ��������
//  filename == dir  - ������� � ���������� dir � �������� ��� ������ ������
//  filename == ".." - ������� �� ������� ���� (�����) � �������� ������ ������
//  filename == file - ������������ null, ����������� �� ������� ������� ����   
        Vector v;        
        if(filename.equals(UP_FOLDER)) {
            if(ContPath.length() != 0 && !ContPath.equals(SEPARATOR)) {
                int i = ContPath.lastIndexOf(SEPARATOR.charAt(0), ContPath.length() - 2);                
                ContPath = ContPath.substring(0, i + 1);
            } else {
                int i = FullPath.lastIndexOf(SEPARATOR.charAt(0), FullPath.length() - 2);
                FullPath = FullPath.substring(0, i + 1);
                container = null;
                ContPath = "";
            }
            LastFile = filename = "";
        }
        if((FullPath + filename).equals(SEPARATOR)) {
            v = getJSR75FileList(true, filename);
        } else
        if(ContPath.length() != 0 && (filename.endsWith(SEPARATOR) || filename.length() == 0)) {            
            v = getContainerFileList(filename);
            v.insertElementAt(UP_FOLDER, 0);
        } else
        if(filename.endsWith(SEPARATOR) || filename.length() == 0) {
            v = getJSR75FileList(false, filename);
            if(v == null) {
                FullPath = SEPARATOR;
                return getFileList("");
            } else {
                v.insertElementAt(UP_FOLDER, 0);
            }                                           
        } else
        if(ContainerManager.getContainerIndex(filename) >= 0) {                
            container = ContainerManager.openContainer(filename, getInputStream(filename));
            ContPath  = SEPARATOR;
            FullPath += filename;
            return getFileList("");
        } else
            return null;        
        String[] list = new String[v.size()];
        v.copyInto(list);        
        return list;
    }
    
    private Vector getJSR75FileList(boolean root, String filename) {
        Vector v = new Vector();
        if(root) {            
            try {
                for(Enumeration e = fsobject.getRoot(); e.hasMoreElements();) {
                    String t = (String)e.nextElement();
                    if(t.endsWith(DEVICE_ID)) v.insertElementAt(t, 0); else v.addElement(t);
                }
            } catch(Throwable t) {
                v.removeAllElements();
            }
            String[] list = super.getFileList(filename);
            for(int i = 0; i < list.length; i++) v.addElement(list[i]);
            list = ContainerManager.getSupportedLogicalContainers();
            for(int i = 0; i < list.length; i++) v.insertElementAt(list[list.length - 1 - i], 0);            
        } else {
            try {
                fsobject.openConnection(FullPath + filename);
                for(Enumeration e = fsobject.getList(); e.hasMoreElements();) {
                    String t = (String)e.nextElement();
                    if(t.endsWith(SEPARATOR)) v.addElement(t);
                }
                String[] Containers = ContainerManager.getSupportedFileContainers();
                for(int i = 0; i < Containers.length; i++) {
                    for(Enumeration e = fsobject.getList(); e.hasMoreElements();) {
                        String t = (String)e.nextElement();
                        if(t.toLowerCase().endsWith("." + Containers[i])) v.addElement(t);
                    }
                }
                for(int i = 0; i < Filter.length; i++) {
                    for(Enumeration e = fsobject.getList(); e.hasMoreElements();) {
                        String t = (String)e.nextElement();
                        if(t.toLowerCase().endsWith("." + Filter[i])) v.addElement(t);
                    }
                }              
                fsobject.closeConnection();
                FullPath += filename;              
            } catch(Throwable t) {
                return null; 
            }
        }        
        return v;
    }
    
    private Vector getContainerFileList(String filename) {
        Vector v = new Vector();
        ContPath += filename;
        String[] list = container.getFileList(ContPath);
        for(int i = 0; i < list.length; i++) 
            if(list[i].endsWith(SEPARATOR)) v.addElement(list[i]);
        for(int n = 0; n < Filter.length; n++) {
            for(int i = 0; i < list.length; i++) {
                if(list[i].toLowerCase().endsWith("." + Filter[n])) v.addElement(list[i]);  //  Fixed bug!
            }
        } 
        return v;
    }
    
    public int getFileTypeIndex(String filename) {        
        int conteiner_index = ContainerManager.getContainerIndex(filename);
        if(conteiner_index >= 0) return conteiner_index + Filter.length;        //  Container type index 
        if(filename.endsWith(DEVICE_ID)) return -4;                             //  Device        
        if(filename.endsWith(FOLDER_ID)) return -3;                             //  Folder
        if(filename.equals(UP_FOLDER))   return -2;                             //  Upper folder        
        return super.getFileTypeIndex(filename);                                //  Filter type index or Unknown type        
    }
    
    public InputStream getInputStream(String filename) {
        if(FullPath.equals(SEPARATOR)) return super.getInputStream(filename);        
        InputStream is = null;
        try {            
            if(ContPath.length() == 0)                
                is = fsobject.getInputStream(FullPath + filename);
            else             
                is = container.getInputStream(ContPath + filename, (container.islogical() ? null : fsobject.getInputStream(FullPath)));                       
            LastFile = filename;           
        } catch(Throwable t) {}
        return is;
    }
            
    public String getCurrentFolder() {        
        return FullPath + ContPath;
    }   
    
}
