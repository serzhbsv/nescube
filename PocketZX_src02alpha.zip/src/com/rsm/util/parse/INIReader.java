package com.rsm.util.parse;

import java.io.InputStream;
import java.util.Vector;

public class INIReader {
    
    private String[] ini;
    
    public INIReader(String resINIfile) {
        ini = parseTxtData(this.getClass().getResourceAsStream(resINIfile));
    }
    
    public INIReader(InputStream is) {
        ini = parseTxtData(is);
    }
    
    public String[] getINI() {
        return ini;
    }
    
    public boolean readKey(String key, boolean cur) {
        String tmp = getKeyValue(key);
        return tmp == null ? cur : !tmp.equals("0");
    }

    public int readKey(String key, int cur) {
        String tmp = getKeyValue(key);
        if(tmp != null) cur = tmp.charAt(0) == '#' ? Integer.parseInt(tmp.substring(1), 16) : Integer.parseInt(tmp);
        return cur;
    }

    public String readKey(String key, String cur) {
        String tmp = getKeyValue(key);
        return tmp == null ? cur : tmp;
    }
    
    private String[] parseTxtData(InputStream is) {
        Vector v = new Vector();
        try {
            for(int i = 0, k = 0; k != -1; k = is.read()) {
                if(k == '[' || k == ';') while((k = is.read()) > 31);                                
                if(k == '=') k = 0x0D;
                if(k > 32) {
                    StringBuffer sb = new StringBuffer();
                    do {
                        sb.append(win1251toUnicode(k));
                    } while(((k = is.read()) == '=' ? 0x0D : k) > 31);
                    v.addElement((new String(sb)).trim());
                }
            }
        } catch(Throwable t) {}
        String[] list = new String[v.size()];
        v.copyInto(list);        
        return list;
    }

    private char win1251toUnicode(int ch) {
        if(ch < 0x80)  return (char)ch;
        switch(ch) {
            default  : return (char)(ch + 0x0350);
            case 0xA8: return 0x0401;   //  RU - �
            case 0xB8: return 0x0451;   //  RU - � 
            case 0xB2: return 0x0406;   //  UA - �
            case 0xB3: return 0x0456;   //  UA - �
            case 0xAF: return 0x0407;   //  UA - �
            case 0xBF: return 0x0457;   //  UA - �
            case 0xAA: return 0x0404;   //  UA - �
            case 0xBA: return 0x0454;   //  UA - �
        }
    }
 
    private String getKeyValue(String key) {
        if(ini != null) {
            key = key.toLowerCase();
            for(int i = 0; i < ini.length; i += 2) {               
                if(ini[i].toLowerCase().equals(key)) return ini[i + 1];            
            }
        }
        return null;        
    }        
}
