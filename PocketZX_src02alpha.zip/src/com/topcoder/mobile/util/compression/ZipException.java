/*
 * Copyright (C) 2006 TopCoder Inc., All Rights Reserved.
 */
package com.topcoder.mobile.util.compression;

import java.io.IOException;


/**
 * <p>
 * This exception is thrown if there is an error parsing a ZIP file. Usually because the file is invalid
 * </p>
 *
 * <p>
 * This class is meant to be compatible with java.util.zip.ZipException from J2SE
 * </p>
 *
 * @author Mafy, mikolajz
 * @version 1.0
 */
public class ZipException extends IOException {
    /**
     * Constructs an <code>ZipException</code> with <code>null</code> as its error detail message.
     */
    public ZipException() {
        this(null);
    }

    /**
     * Constructs an <code>ZipException</code> with the specified detail message.
     *
     * @param message the detail message.
     */
    public ZipException(String message) {
        super(message);
    }
}
