/*
 * Copyright (C) 2006 TopCoder Inc., All Rights Reserved.
 */
package com.topcoder.mobile.util.compression;

import java.util.Vector;


/**
 * <p>
 * This class is used to detect whether compression or decompression, and which algorithms are available during
 * runtime. Compression and decompression is detected by checking whether a class from the subpackages is present.
 * Available algorithms includes only Deflater.
 * </p>
 *
 * @author Mafy, mikolajz
 * @version 1.0
 */
public class CompressionUtility {
    /**
     * Default constructor. Creates a new compression utility.
     */
    public CompressionUtility() {
    }

    /**
     * Check if the class of the given name exists
     * @param name The fully qualified name of the class
     * @return <code>true</code> if such class exists
     */
    private static boolean doesClassExist(String name) {
        try {
            Class.forName(name);
            return true;
        } catch (ClassNotFoundException e) {
        	return false;
        }
    
    }

    /**
     * Returns the available algorithms. Currently only Deflater algorithm is available.
     *
     * @return the vector list of available algorithms
     */
    public static Vector availableAlgorithms() {
        Vector algs = new Vector();

        if (doesClassExist("com.topcoder.mobile.util.compression.comp.Deflater") ||
        		doesClassExist("com.topcoder.mobile.util.compression.decomp.Inflater"))
            algs.addElement("Deflater");

        return algs;
    }

    /**
     * Checks whether compression is available with specified algorithm. By default, compression is available with the
     * Deflater algorithm.
     *
     * @param algorithm algorithm name to check if available for compression
     *
     * @return whether compression is available
     */
    public static boolean isCompressionAvailable(String algorithm) {
    	if (algorithm == null)
    		throw new NullPointerException("algorithm is null");
    	algorithm = algorithm.trim();
    	if (algorithm.length() == 0)
    		throw new IllegalArgumentException("algorithm length is zero");
        try {
            String alg = "com.topcoder.mobile.util.compression.comp." + algorithm;
            Class.forName(alg);

            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    /**
     * Checks whether decompression is available with specified algorithm. By default, decompression is available with
     * the Deflater algorithm in corresponding Inflater class.
     *
     * @param algorithm algorithm name to check if available for decompression
     *
     * @return whether decompression is available
     */
    public static boolean isDecompressionAvailable(String algorithm) {
    	if (algorithm == null)
    		throw new NullPointerException("algorithm is null");
    	algorithm = algorithm.trim();
    	if (algorithm.length() == 0)
    		throw new IllegalArgumentException("algorithm length is zero");
        try {
            String alg = "com.topcoder.mobile.util.compression.decomp." + algorithm;
            Class.forName(alg);

            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }
}
