/*
 * Copyright (C) 2006 TopCoder Inc., All Rights Reserved.
 */
package com.topcoder.mobile.util.compression;

/**
 * <p>
 * This interface defines the methods required to compute a checksum on a stream of data. The checksum is computed
 * based on the bytes of data supplied by the update() methods; the current value of the checksum can be obtained at
 * any time with the getValue() method. reset() resets the checksum to its default value; use this method before
 * beginning a new stream of data. The checksum value computed by a Checksum object and returned through the
 * getValue() method must fit into a long value. The classes CheckedInputStream provide a higher-level API for
 * computing a checksum on a stream of data.
 * </p>
 *
 * <p>
 * This interface is meant to be compatible with java.util.zip.Checksum from J2SE
 * </p>
 *
 * @author Mafy, mikolajz
 * @version 1.0
 */
public interface Checksum {
    /**
     * Returns the current checksum value.
     *
     * @return the current checksum value.
     */
    public long getValue();

    /**
     * Resets the checksum to its initial value.
     */
    public void reset();

    /**
     * Updates the current checksum with the specified byte.
     *
     * @param b the byte to update the checksum with
     */
    public void update(int b);

    /**
     * Updates the current checksum with the specified array of bytes.
     *
     * @param buffer the byte array to update the checksum with
     * @param offset the start offset of the data
     * @param len the number of bytes to use for the update
     */
    public void update(byte[] buffer, int offset, int len);
}
