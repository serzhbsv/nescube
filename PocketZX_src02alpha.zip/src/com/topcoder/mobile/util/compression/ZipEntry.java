/*
 * Copyright (C) 2006 TopCoder Inc., All Rights Reserved.
 */
package com.topcoder.mobile.util.compression;

import java.util.Calendar;
import java.util.Date;


/**
 * <p>
 * This class describes a single entry (typically a compressed file) stored within a ZIP file. The various methods get
 * and set various pieces of information about the entry. The ZipEntry class is used by ZipInputStream, which read ZIP
 * files, and by ZipOutputStream, which writes ZIP files. When you are reading a ZIP file, a ZipEntry object returned
 * by ZipInputStream contains the name, size, modification time, and other information about an entry in the file.
 * When writing a ZIP file, on the other hand, you must create your own ZipEntry objects and initialize them to
 * contain the entry name and other appropriate information before writing the contents of the entry.
 * </p>
 *
 * <p>
 * This class is meant to be compatible with java.util.zip.ZipEntry from J2SE
 * </p>
 *
 * <p>
 * This class is not thread-safe
 * </p>
 *
 * @author Mafy, mikolajz
 * @version 1.0
 */
public class ZipEntry implements ZipConstants {
    /** Represents the Compression method for uncompressed entries. */
    public static final int STORED = 0;

    /** Represents the Compression method for compressed (deflated) entries. */
    public static final int DEFLATED = 8;

    /** Represents the entry name. Initialized in the constructor and never changed after. Can not be null. */
    private String name;

    /**
     * Represents the modification time (in DOS time). Initialized in the constructor or in setTime(...) method. Can
     * not be null.
     */
    private long time = -1;

    /** Represents crc-32 of entry data. Initialized in the constructor or in setCrc(...) method. Can not be null. */
    private long crc = -1;

    /**
     * Represents the uncompressed size of entry data. Initialized in the constructor or in setSize(...) method with
     * zero or positive values.
     */
    private long size = -1;

    /**
     * Represents the compressed size of entry data. Initialized in the constructor or in setCompressedSize(...) with
     * positive values..
     */
    private long csize = -1;

    /**
     * <p>
     * Represents the compression method. STORED and DEFLATED methods are supported
     * </p>
     *
     * <p>
     * Initialized in the constructor or in setMethod(...) method.
     * </p>
     *
     * @see #STORED
     * @see #DEFLATED
     */
    private int method = -1;

    /** Represents the optional extra field data for entry. Initialized in the constructor or in setExtra(...) method. */
    private byte[] extra = null;

    /** Represents the optional comment string for entry. Initialized in the constructor or in setComment(...) method. */
    private String comment = null;

    /** Represents the bit flags used only by Zip{Input,Output}Stream. It is set in setFlag(...) method. */
    private int flag;

    /**
     * Represents the version needed to extract used only by Zip{Input,Output}Stream. It is set in setVersion(...)
     * method.
     */
    private int version;

    /** Represents the offset of loc header used only by Zip{Input,Output}Stream. It is set in setOffset(...) method. */
    private long offset;

    /**
     * Creates a new zip entry with the specified name.
     *
     * @param name the entry name
     *
     * @throws NullPointerException if the entry name is null
     * @throws IllegalArgumentException if the entry name is longer than 0xFFFF bytes
     */
    public ZipEntry(String name) {
        if (name == null) {
            throw new NullPointerException("name parameter is null");
        }

        if (name.length() > 0xffff) {
            throw new IllegalArgumentException("name longer than 65536");
        }

        this.name = name;
    }

    /**
     * Creates a new zip entry with fields taken from the specified zip entry.
     *
     * @param zipentry a zip Entry object
     */
    public ZipEntry(ZipEntry zipentry) {
        this.comment = zipentry.comment;
        this.crc = zipentry.crc;
        this.csize = zipentry.csize;
        this.extra = zipentry.extra;
        this.flag = zipentry.flag;
        this.method = zipentry.method;
        this.name = zipentry.name;
        this.offset = zipentry.offset;
        this.size = zipentry.size;
        this.time = zipentry.time;
        this.version = zipentry.version;
    }

    /**
     * Returns the name of the entry.
     *
     * @return the name of the entry
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the modification time of the entry. The time must be given in the DOS format
     *
     * @param time the entry modification time in the DOS format
     *
     * @see #setTime(long)
     * @see #getDOSTime()
     */
    public void setDOSTime(int time) {
        this.time = (long) time & 0xffffffff;
    }

    /**
     * Returns the modification time of the entry, or -1 if not specified. The time is returned in the DOS format
     *
     * @return the modification time of the entry, or -1 if not specified
     *
     * @see #getTime()
     * @see #setDOSTime(int)
     */
    public long getDOSTime() {
        return (time != -1) ? time : (-1);
    }

    /**
     * Sets the modification time of the entry.
     *
     * @param time the entry modification time in number of milliseconds since the epoch
     *
     * @see #getTime()
     */
    public void setTime(long time) {
        this.time = javaToDosTime(time);
    }

    /**
     * Returns the modification time of the entry, or -1 if not specified.
     *
     * @return the modification time of the entry, or -1 if not specified
     *
     * @see #setTime(long)
     */
    public long getTime() {
        return (time != -1) ? dosToJavaTime((int) time) : (-1);
    }

    /**
     * Sets the uncompressed size of the entry data.
     *
     * @param size the uncompressed size in bytes
     *
     * @throws IllegalArgumentException if the specified size is less than 0 or greater than 0xFFFFFFFF bytes
     *
     * @see #getSize()
     */
    public void setSize(long size) {
        if ((size < 0) || (size > 0xFFFFFFFFL)) {
            throw new IllegalArgumentException("invalid entry size");
        }

        this.size = size;
    }

    /**
     * Returns the uncompressed size of the entry data, or -1 if not known.
     *
     * @return the uncompressed size of the entry data, or -1 if not known
     *
     * @see #setSize(long)
     */
    public long getSize() {
        return size;
    }

    /**
     * Returns the size of the compressed entry data, or -1 if not known. In the case of a stored entry, the compressed
     * size will be the same as the uncompressed size of the entry.
     *
     * @return the size of the compressed entry data, or -1 if not known
     *
     * @see #setCompressedSize(long)
     */
    public long getCompressedSize() {
        return csize;
    }

    /**
     * Sets the size of the compressed entry data.
     *
     * @param csize the compressed size to set to
     *
     * @see #getCompressedSize()
     */
    public void setCompressedSize(long csize) {
        this.csize = csize;
    }

    /**
     * Sets the CRC-32 checksum of the uncompressed entry data.
     *
     * @param crc the CRC-32 value
     *
     * @throws IllegalArgumentException if the specified CRC-32 value is less than 0 or greater than 0xFFFFFFFF
     *
     * @see #getCrc()
     */
    public void setCrc(long crc) {
        if ((crc < 0) || (crc > 0xFFFFFFFFL)) {
            throw new IllegalArgumentException("invalid entry crc-32");
        }

        this.crc = crc;
    }

    /**
     * Returns the CRC-32 checksum of the uncompressed entry data, or -1 if not known.
     *
     * @return the CRC-32 checksum of the uncompressed entry data, or -1 if not known
     *
     * @see #setCrc(long)
     */
    public long getCrc() {
        return crc;
    }

    /**
     * Sets the compression method for the entry.
     *
     * @param method the compression method, either STORED or DEFLATED
     *
     * @throws IllegalArgumentException if the specified compression method is invalid
     *
     * @see #getMethod()
     */
    public void setMethod(int method) {
        if ((method != STORED) && (method != DEFLATED)) {
            throw new IllegalArgumentException("invalid compression method");
        }

        this.method = method;
    }

    /**
     * Returns the compression method of the entry, or -1 if not specified.
     *
     * @return the compression method of the entry, or -1 if not specified
     *
     * @see #setMethod(int)
     */
    public int getMethod() {
        return method;
    }

    /**
     * Sets the optional extra field data for the entry.
     *
     * @param extra the extra field data bytes
     *
     * @throws IllegalArgumentException if the length of the specified extra field data is greater than 0xFFFF bytes
     *
     * @see #getExtra()
     */
    public void setExtra(byte[] extra) {
    	if (extra == null)
    		throw new NullPointerException("extra is null");
        if ((extra != null) && (extra.length > 0xFFFF)) {
            throw new IllegalArgumentException("invalid extra field length");
        }

        this.extra = extra;
    }

    /**
     * Returns the extra field data for the entry, or null if none.
     *
     * @return the extra field data for the entry, or null if none
     *
     * @see #setExtra(byte[])
     */
    public byte[] getExtra() {
        return extra;
    }

    /**
     * Sets the optional comment string for the entry.
     *
     * @param comment the comment string
     *
     * @throws IllegalArgumentException if the length of the specified comment string is greater than 0xFFFF bytes
     *
     * @see #getComment()
     */
    public void setComment(String comment) {
    	if (comment == null)
    		throw new NullPointerException("comment is null");
        if ((comment != null) && (getUTF8Length(comment) > 0xffff)) {
            throw new IllegalArgumentException("invalid entry comment length");
        }

        this.comment = comment;
    }

    /**
     * Returns the hash code value for this entry.
     *
     * @return the comment string for the entry, or null if none
     *
     * @see #setComment(String)
     */
    public String getComment() {
        return comment;
    }

    /**
     * Sets the bit flags for the entry.
     *
     * @param flag the bit flags
     *
     * @see #getFlag()
     */
    public void setFlag(int flag) {
        this.flag = flag;
    }

    /**
     * Returns the bit flags for the entry.
     *
     * @return the bit flags for the entry
     *
     * @see #setFlag(int)
     */
    public int getFlag() {
        return flag;
    }

    /**
     * Sets the version needed to extract for the entry.
     *
     * @param version the version needed to extract
     *
     * @see #getVersion()
     */
    public void setVersion(int version) {
    	if (version < 0)
    		throw new IllegalArgumentException("version should be positive");
        this.version = version;
    }

    /**
     * Returns the version needed to extract for the entry.
     *
     * @return the version needed to extract for the entry
     *
     * @see #setVersion(int)
     */
    public int getVersion() {
        return version;
    }

    /**
     * Sets the offset of LOC header for the entry. The LOC header is stored before the compressed data and contains
     * information like the file name, compression method etc.
     *
     * @param offset the offset of LOC header
     *
     * @throws IllegalArgumentException If the offset is less than zero
     *
     * @see #getOffset()
     */
    public void setOffset(long offset) {
        if (offset < 0) {
            throw new IllegalArgumentException("Offset is less than zero");
        }

        this.offset = offset;
    }

    /**
     * Returns the offset of LOC header for the entry.  The LOC header is stored before the compressed data and contains
     * information like the file name, compression method etc.
     *
     * @return the offset of LOC header for the entry
     *
     * @see #setOffset(long)
     */
    public long getOffset() {
        return offset;
    }

    /**
     * Returns true if this is a directory entry. A directory entry is defined to be one whose name ends with a '/'.
     *
     * @return true if this is a directory entry
     */
    public boolean isDirectory() {
        return name.endsWith("/");
    }

    /**
     * Returns a string representation of the ZIP entry.
     *
     * @return The name of the entry
     */
    public String toString() {
        return name;
    }

    /**
     * Converts DOS time to Java time (number of milliseconds since epoch).
     *
     * @param dtime A timestamp in the DOS representation
     *
     * @return The timestamp in the Java time representation
     */
    private static long dosToJavaTime(int dtime) {
        int sec = (dtime & 0x1f) << 1;
        int min = (dtime >> 5) & 0x3f;
        int hrs = (dtime >> 11) & 0x1f;
        int day = (dtime >> 16) & 0x1f;
        int month = ((dtime >> 21) & 0xf) - 1;
        int year = ((dtime >> 25) & 0x7f) + 1980;

        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.MILLISECOND, 0);
        cal.set(Calendar.SECOND, sec);
        cal.set(Calendar.MINUTE, min);
        cal.set(Calendar.HOUR_OF_DAY, hrs);
        cal.set(Calendar.DAY_OF_MONTH, day);
        cal.set(Calendar.MONTH, month);
        cal.set(Calendar.YEAR, year);

        return cal.getTime().getTime();
    }

    /**
     * Converts Java time to DOS time.
     *
     * @param time A timestamp in Java representation
     *
     * @return The timestamp in the DOS representation
     *
     * @throws IllegalArgumentException If the year cannot be fit into the field;
     */
    private static int javaToDosTime(long time) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date(time));

        int year = cal.get(Calendar.YEAR);

        if ((year < 1980) || (year > 2107)) {
            throw new IllegalArgumentException("Year out of bounds for a DOS timestamp");
        }

        int dostime = (cal.get(Calendar.SECOND) >> 1) | (cal.get(Calendar.MINUTE) << 5) |
            (cal.get(Calendar.HOUR_OF_DAY) << 11) | (cal.get(Calendar.DAY_OF_MONTH) << 16) |
            ((cal.get(Calendar.MONTH) + 1) << 21) | ((cal.get(Calendar.YEAR) - 1980) << 25);

        return dostime;
    }

    /**
     * Returns the hash code value for this entry.
     *
     * @return The hash code of the name value
     */
    public int hashCode() {
        return name.hashCode();
    }

    /**
     * Helper method. Returns the number of bytes for the string UTF-8 encoding
     *
     * @param string The string we want to encode
     *
     * @return The number of bytes needed for the UTF-8 encoding
     */
    public static int getUTF8Length(String string) {
        int count = 0;

        for (int i = 0; i < string.length(); i++) {
            char ch = string.charAt(i);
            count++;

            if ((ch & 0xff80) != 0) {
                count++;
            }

            if ((ch & 0xf800) != 0) {
                count++;
            }
        }

        return count;
    }
}
