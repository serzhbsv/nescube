/*
 * Copyright (C) 2006 TopCoder Inc., All Rights Reserved.
 */
package com.topcoder.mobile.util.compression;

/**
 * <p>
 * This class implements the Checksum interface that computes a checksum on a stream of data using the CRC32
 * algorithm.
 * </p>
 *
 * <p>
 * This class is meant to be compatible with java.util.zip.CRC32 from J2SE
 * </p>
 *
 * <p>
 * This class is not thread-safe
 * </p>
 *
 * @author Mafy, mikolajz
 * @version 1.0
 */
public class CRC32 implements Checksum {
    /** Table of constants needed to quickly compute CRC32. Computed once the class is loaded */
    static private int[] crcTable = makeCRCTable();

    /** The polynomial used in the IEEE standard CRC32 */
    private static final int CRC_POLYNOMINAL = 0xedb88320;

    /** The current value of the CRC32 checksum */
    private int notCrc;

    /**
     * Construct a new CRC32 object
     */
    public CRC32() {
        notCrc = 0xffffffff;
    }

    /**
     * Returns the current checksum value.
     *
     * @return the current checksum value.
     */
    public long getValue() {
        return ((long) ~notCrc) & 0xffffffffL;
    }

    /**
     * Resets the checksum to its initial value.
     */
    public void reset() {
        notCrc = 0xffffffff;
    }

    /**
     * Updates the current checksum with the specified byte.
     *
     * @param b the byte to update the checksum with
     */
    public void update(int b) {
        notCrc = crcTable[(notCrc ^ b) & 0xff] ^ (notCrc >>> 8);
    }

    /**
     * Updates the current checksum with the specified array of bytes.
     *
     * @param buffer the byte array to update the checksum with
     */
    public void update(byte[] buffer) {
        update(buffer, 0, buffer.length);
    }

    /**
     * Updates the current checksum with the specified array of bytes.
     *
     * @param buffer The byte array with data to update the checksum with
     * @param offset The offset to the beginning of the data to checksum in the array
     * @param len The number of bytes of data to checksum in the array
     */
    public void update(byte[] buffer, int offset, int len) {
        int c = notCrc;

        while (--len >= 0)
            c = crcTable[(c ^ buffer[offset++]) & 0xff] ^ (c >>> 8);

        notCrc = c;
    }

    /**
     * Build the crcTable which is used to quickly compute the CRC
     *
     * @return The built table
     */
    static private int[] makeCRCTable() {
        int[] crc_table = new int[256];

        for (int n = 0; n < 256; n++) {
            int c = n;

            for (int k = 8; --k >= 0;) {
                if ((c & 1) != 0) {
                    c = CRC_POLYNOMINAL ^ (c >>> 1);
                } else {
                    c = c >>> 1;
                }
            }

            crc_table[n] = c;
        }

        return crc_table;
    }
}
