/*
 * Copyright (C) 2006 TopCoder Inc., All Rights Reserved.
 */
package com.topcoder.mobile.util.compression;

/**
 * <p>
 * Signals that invalid or corrupt data has been encountered while uncompressing data.
 * </p>
 *
 * <p>
 * This class is meant to be compatible with java.util.zip.DataFormatException from J2SE
 * </p>
 *
 * @author Mafy, mikolajz
 * @version 1.0
 */
public class DataFormatException extends Exception {
    /**
     * Constructs a DataFormatException with no detail message.
     */
    public DataFormatException() {
    }

    /**
     * Constructs a DataFormatException with the specified detail message. A detail message is a String that describes
     * this particular exception.
     *
     * @param message the String containing a detail message
     */
    public DataFormatException(String message) {
        super(message);
    }
}
