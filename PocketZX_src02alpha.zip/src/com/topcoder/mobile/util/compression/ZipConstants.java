/*
 * Copyright (C) 2006 TopCoder Inc., All Rights Reserved.
 */
package com.topcoder.mobile.util.compression;

/**
 * <p>
 * This interface defines the constants that are used by the classes that manipulate ZIP files.
 * </p>
 *
 * <p>
 * This interface is meant to be compatible with java.util.zip.ZipConstants from J2SE
 * </p>
 *
 * @author Mafy, mikolajz
 * @version 1.0
 */
public interface ZipConstants {
    /** The LOC (Local file) header signature "PK\003\004". */
    static long LOCSIG = 0x04034b50L;

    /** The EXT (Extra local) header signature "PK\007\008" */
    static long EXTSIG = 0x08074b50L;

    /** The CEN (Central directory) header signature "PK\001\002". */
    static long CENSIG = 0x02014b50L;

    /** The END (End of central directory) header signature "PK\005\006". */
    static long ENDSIG = 0x06054b50L;

    /** The LOC (Local file) header size. */
    static final int LOCHDR = 30;

    /** The EXT (Extra local) header size. */
    static final int EXTHDR = 16;

    /** The CEN (Central directory) header size. */
    static final int CENHDR = 46;

    /** The END (End of central directory) header size. */
    static final int ENDHDR = 22;

    /** The offset of the version field in the LOC (Local file) header. */
    static final int LOCVER = 4;

    /** The offset of the general purpose bit flag field in the LOC (Local file) header. */
    static final int LOCFLG = 6;

    /** The offset of the compression method field in the LOC (Local file) header. */
    static final int LOCHOW = 8;

    /** The offset of the modification time field in the LOC (Local file) header. */
    static final int LOCTIM = 10;

    /** The offset of the uncompressed file crc-32 value field in the LOC (Local file) header. */
    static final int LOCCRC = 14;

    /** The offset of the compressed size field in the LOC (Local file) header. */
    static final int LOCSIZ = 18;

    /** The offset of the uncompressed size field in the LOC (Local file) header. */
    static final int LOCLEN = 22;

    /** The offset of the filename length field in the LOC (Local file) header. */
    static final int LOCNAM = 26;

    /** The offset of the extra fields length field in the LOC (Local file) header. */
    static final int LOCEXT = 28;

    /** The uncompressed file crc-32 value offset of EXT (Extra local) header. */
    static final int EXTCRC = 4;

    /** The compressed size offset of EXT (Extra local) header. */
    static final int EXTSIZ = 8;

    /** The uncompressed size offset of EXT (Extra local) header. */
    static final int EXTLEN = 12;

    /** The version made by offset of CEN (Central directory) header. */
    static final int CENVEM = 4;

    /** Represents the version needed to extract offset of CEN (Central directory) header. */
    static final int CENVER = 6;

    /** Represents the encrypt, decrypt flags offset of CEN (Central directory) header. */
    static final int CENFLG = 8;

    /** Represents the compression method offset of CEN (Central directory) header. */
    static final int CENHOW = 10;

    /** Represents the modification time offset of CEN (Central directory) header. */
    static final int CENTIM = 12;

    /** Represents the uncompressed file crc-32 value offset of CEN (Central directory) header. */
    static final int CENCRC = 16;

    /** Represents the compressed size offset of CEN (Central directory) header. */
    static final int CENSIZ = 20;

    /** Represents the uncompressed size offset of CEN (Central directory) header. */
    static final int CENLEN = 24;

    /** Represents the filename length offset of CEN (Central directory) header. */
    static final int CENNAM = 28;

    /** Represents the extra field length offset of CEN (Central directory) header. */
    static final int CENEXT = 30;

    /** Represents the comment length offset of CEN (Central directory) header. */
    static final int CENCOM = 32;

    /** Represents the disk number start offset of CEN (Central directory) header. */
    static final int CENDSK = 34;

    /** Represents the internal file attributes offset of CEN (Central directory) header. */
    static final int CENATT = 36;

    /** Represents the external file attributes offset of CEN (Central directory) header. */
    static final int CENATX = 38;

    /** Represents the LOC header offset offset of CEN (Central directory) header. */
    static final int CENOFF = 42;

    /** Represents the number of entries on this disk offset of END (End of central directory) header. */
    static final int ENDSUB = 8;

    /** Represents the total number of entries offset of END (End of central directory) header. */
    static final int ENDTOT = 10;

    /** Represents the central directory size in bytes offset of END (End of central directory) header. */
    static final int ENDSIZ = 12;

    /** Represents the offset of first CEN header offset of END (End of central directory) header. */
    static final int ENDOFF = 16;

    /** Represents the zip file comment length offset of END (End of central directory) header. */
    static final int ENDCOM = 20;
}
