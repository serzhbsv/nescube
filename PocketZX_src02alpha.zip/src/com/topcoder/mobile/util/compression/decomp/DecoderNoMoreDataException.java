/*
 * Copyright (C) 2006 TopCoder Inc., All Rights Reserved.
 */
package com.topcoder.mobile.util.compression.decomp;

/**
 * This exception is thrown when there is no more data in the decoder buffer
 *
 * @author Mafy, mikolajz
 * @version 1.0
 */
class DecoderNoMoreDataException extends Exception {
    /**
     * Default constructor - construct an exception
     */
    DecoderNoMoreDataException() {
    }
}
