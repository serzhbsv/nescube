/*
 * Copyright (C) 2006 TopCoder Inc., All Rights Reserved.
 */
package com.topcoder.mobile.util.compression.decomp;

import com.topcoder.mobile.util.compression.DataFormatException;
import com.topcoder.mobile.util.compression.ZipException;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;


/**
 * <p>
 * This class is a subclass of java.io.InputStream; it reads a specified stream of compressed input data (typically one
 * that was written with DeflaterOutputStream or a subclass) and filters that data by uncompressing (inflating) it. To
 * create an InflaterInputStream, specify the input stream to read from and an optionally Inflater object to perform
 * the decompression. Once an InflaterInputStream is created, the read() and skip() methods are the same as those of
 * other input streams. The InflaterInputStream uncompresses raw data. Applications often prefer one of its
 * subclasses, GZIPInputStream or ZipInputStream, that work with compressed data written in the standard GZIP and
 * PKZip file formats.
 * </p>
 *
 * <p>
 * This class is meant to be compatible with java.util.zip.InflaterInputStream from J2SE
 * </p>
 *
 * <p>
 * This class is thread-safe
 * </p>
 *
 * @author Mafy, mikolajz
 * @version 1.0
 *
 * @see Inflater
 */
public class InflaterInputStream extends InputStream {
    /** This value is used as the buffer size if no buffer size is passed to the constructor */
    private static final int DEFAULT_BUFFER_SIZE = 4096;

    /**
     * Represents the input buffer that is used for decompression. Initialized in the constructor and can not be null.
     */
    protected byte[] buf;

    /**
     * Represents the length of data in the input buffer. It is set in fillInflaterInput(...) method with a positive
     * value.
     */
    protected int len;

    /** Represents the flag that is true when the input stream is closed. It is set to true in close(...) method. */
    private boolean closed = false;

    /** Represents the input stream. Initialized in the constructors and never changed after. Can not be null. */
    protected InputStream in;

    /**
     * <p>
     * Represents the decompressor for this stream.
     * </p>
     *
     * <p>
     * Initialized in the constructors and never changed after. Can not be null.
     * </p>
     */
    protected Inflater inf;

    /** A temporary buffer one byte buffer used in read() method to call read(byte[]). */
    private byte[] singleByteArray = new byte[1];

    /**
     * Creates a new input stream with the specified decompressor and buffer size.
     *
     * @param in the input stream with compressed data
     * @param inf the decompressor ("inflater")
     * @param size the input buffer size
     *
     * @throws NullPointerException - if an invalid parameter is received
     * @throws IllegalArgumentException if size is &lt;= 0
     */
    public InflaterInputStream(InputStream in, Inflater inf, int size) {
        if (in == null) {
            throw new NullPointerException("in is null");
        }

        if (inf == null) {
            throw new NullPointerException("inf is null");
        }

        if (size <= 0) {
            throw new IllegalArgumentException("Size is less or equal 0: " + size);
        }

        this.in = in;
        this.inf = inf;
        this.buf = new byte[size];
    }

    /**
     * Creates a new input stream with the specified decompressor and a default buffer size.
     *
     * @param in the input stream with compressed data
     * @param inf the decompressor ("inflater")
     */
    public InflaterInputStream(InputStream in, Inflater inf) {
        this(in, inf, DEFAULT_BUFFER_SIZE);
    }

    /**
     * Creates a new input stream with a default decompressor and buffer size.
     *
     * @param in the input stream with compressed data
     */
    public InflaterInputStream(InputStream in) {
        this(in, new Inflater(), DEFAULT_BUFFER_SIZE);
    }

    /**
     * Check to make sure that this stream has not been closed.
     *
     * @throws IOException - if the stream is closed
     */
    private void ensureOpen() throws IOException {
        if (closed) {
            throw new IOException("Stream closed");
        }
    }

    /**
     * Reads a byte of uncompressed data. This method will block until input is available for decompression.
     *
     * @return the byte read, or -1 if end of compressed input is reached
     *
     * @throws IOException if an I/O error has occurred
     */
    synchronized public int read() throws IOException {
        ensureOpen();

        return (read(singleByteArray) == -1) ? (-1) : (singleByteArray[0] & 0xff);
    }

    /**
     * Reads uncompressed data into an array of bytes <code>b</code> (that can not be <code>null</code>), from the
     * start offset of the data - <code>off</code> and with the maximum number of bytes read - <code>len</code>. This
     * method will block until some input can be decompressed.
     *
     * @param buffer the buffer into which the data is read
     * @param offset the start offset of the data
     * @param len the maximum number of bytes read
     *
     * @return the actual number of bytes read, or -1 if the end of the compressed input is reached or a preset
     *         dictionary is needed
     *
     * @throws IOException if an I/O error has occurred
     * @throws IndexOutOfBoundsException if a ZIP format error has occurred
     * @throws ZipException If the input file is not a valid ZIP file
     */
    public synchronized int read(byte[] buffer, int offset, int len)
        throws IOException {
        ensureOpen();

        if (((offset + len) | (buffer.length - (offset + len))) < 0) {
            throw new IndexOutOfBoundsException("offset or len is invalid");
        } else if (len == 0) {
            return 0;
        }

        if (inf.finished() || inf.needsDictionary()) {
            return -1;
        }

        try {
            int pos = 0;

            while (pos < len) {
                pos += inf.inflate(buffer, offset + pos, len - pos);

                if (inf.finished() || inf.needsDictionary()) {
                    break;
                }

                if (inf.needsInput()) {
                    fillInflaterInput();
                }
            }

            return ((pos > 0) ? pos : (-1));
        } catch (DataFormatException e) {
            String s = e.getMessage();
            throw new ZipException((s != null) ? s : "Invalid ZLIB data format");
        }
    }

    /**
     * <p>
     * Returns 0 after EOF has reached, otherwise always return 1.
     * </p>
     *
     * <p>
     * Programs should not count on this method to return the actual number of bytes that could be read without
     * blocking.
     * </p>
     *
     * @return 1 before EOF and 0 after EOF.
     *
     * @throws IOException if an I/O error occurs.
     */
    public synchronized int available() throws IOException {
        return (inf.finished() || inf.needsDictionary()) ? 0 : 1;
    }

    /**
     * Closes the input stream.
     *
     * @throws IOException if an I/O error has occurred
     */
    public void close() throws IOException {
        closed = true;
        in.close();
    }

    /**
     * Skips the specified amount of bytes
     *
     * @param count The number of bytes to skip
     *
     * @return The number of bytes actually skipped
     *
     * @throws IOException If an I/O error occurs
     * @throws IllegalArgumentException If <code>count</code> is less than zero
     */
    public long skip(long count) throws IOException {
        if (count < 0) {
            throw new IllegalArgumentException("count is negative");
        }

        return super.skip(count);
    }

    /**
     * Fills the input buffer with more data that can be decompressed.
     *
     * @throws IOException if an I/O error has occurred
     * @throws EOFException If the input couldn't be filled because and end-of-stream was reached
     */
    protected void fillInflaterInput() throws IOException {
        len = in.read(buf);

        if (len == -1) {
            throw new EOFException("Unexpected end of compressed stream");
        }

        inf.setInput(buf, 0, len);
    }
}
