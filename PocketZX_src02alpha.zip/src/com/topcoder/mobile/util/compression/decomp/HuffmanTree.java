/*
 * Copyright (C) 2006 TopCoder Inc., All Rights Reserved.
 */
package com.topcoder.mobile.util.compression.decomp;

import com.topcoder.mobile.util.compression.DataFormatException;


/**
 * <p>
 * A helper class for the Inflater - a Huffman tree decoder. Appropriate methods allows to build the tree from the
 * lengths representation and decode a symbol from the stream
 * </p>
 *
 * <p>
 * A HuffmanTree object can be reused to encode a different tree. This reduces the work of the Garbage Collector what
 * is important in the J2ME environment.
 * </p>
 *
 * <p>
 * This class is marked as final as this may help the VM optimizer
 * </p>
 *
 * @author Mafy, mikolajz
 * @version 1.0
 */
final class HuffmanTree {
    /** The maximum of hits a code may have. It is the same as the maximum code length in the DEFLATE algorithm */
    static final int MAX_BITS = 18;

    /** The id of the root node of our tree */
    private static final int NODE_ROOT = 0;

    /**
     * <p>
     * Each tree node contains a left node data and a right node data. Each data has a numerical value and a type field
     * </p>
     *
     * <p>
     * With this mask you can extract the numerical value from the node data
     * </p>
     */
    private static final int VALUE_MASK = 0x3fff;

    /**
     * <p>
     * Each tree node contains a left node data and a right node data. Each data has a numerical value and a type field
     * </p>
     *
     * <p>
     * By right shifting the node data by this amount you can extract the type field (note: remember that before
     * shifting the short is converted into an int. You should AND it with 0xffff to avoid some garbage because of
     * sign bit extension)
     * </p>
     */
    private static final int TYPE_SHIFT = 14;

    /**
     * <p>
     * Each tree node contains a left node data and a right node data. Each data has a numerical value and a type field
     * </p>
     *
     * <p>
     * This value of type field means the left/right node is not initialized yet
     * </p>
     */
    private static final int TYPE_UNDEFINED = 0;

    /**
     * <p>
     * Each tree node contains a left node data and a right node data. Each data has a numerical value and a type field
     * </p>
     *
     * <p>
     * This value of type field means the left/right node contains a literal
     * </p>
     */
    private static final int TYPE_LITERAL = 1;

    /**
     * <p>
     * Each tree node contains a left node data and a right node data. Each data has a numerical value and a type field
     * </p>
     *
     * <p>
     * This value of type field means the left/right node contains is an internal node with children
     * </p>
     */
    private static final int TYPE_NODE = 2;

    /** The maximal number of codes for this Huffman tree. Initialized in the constructor */
    private int maxCodes;

    /**
     * A temporary table used in buildTree. It is kept as a member of to avoid wasting too much time in the Garbage
     * Collector
     */
    private int[] lengthsCount;

    /**
     * A temporary table used in buildTree. It is kept as a member of to avoid wasting too much time in the Garbage
     * Collector
     */
    private int[] nextCode;

    /**
     * <p>
     * Each tree node contains a left node data and a right node data. Each data has a numerical value and a type field
     * </p>
     *
     * <p>
     * This table contains the left node data for each node
     * </p>
     */
    private short[] treeLeft;

    /**
     * <p>
     * Each tree node contains a left node data and a right node data. Each data has a numerical value and a type field
     * </p>
     *
     * <p>
     * This table contains the right node data for each node
     * </p>
     */
    private short[] treeRight;

    /** The last node that have been allocated */
    private int lastTreeNode;

    /**
     * Create a placeholder for a Huffman tree
     *
     * @param maxCodes The maximal number of codes for this tree
     */
    public HuffmanTree(int maxCodes) {
        this.maxCodes = maxCodes;
        lengthsCount = new int[MAX_BITS + 1];
        nextCode = new int[MAX_BITS + 1];
        treeLeft = new short[2 * maxCodes];
        treeRight = new short[2 * maxCodes];
    }

    /**
     * Clear the tree data
     */
    private void clearTree() {
        for (int i = 0; i < treeLeft.length; i++) {
            treeLeft[i] = 0;
            treeRight[i] = 0;
        }

        lastTreeNode = 0;
    }

    /**
     * Add a new node to the tree.
     *
     * @param code The binary code of that node
     * @param bits The number of bits for that code
     * @param value The numerical value associated with this code
     *
     * @throws DataFormatException If that node cannot be added to that tree
     * @throws Error If an invalid value is stored in the node type field
     */
    private void addNodeToTree(int code, int bits, int value)
        throws DataFormatException {
        int node = NODE_ROOT;

        if ((code >>> bits) > 0) {
            throw new DataFormatException("Invalid Huffman tree declaration");
        }

        while (bits > 0) {
            bits--;

            int msb = (code >>> bits) & 1;
            int nodeValue;

            if (msb == 0) {
                nodeValue = treeLeft[node];
            } else {
                nodeValue = treeRight[node];
            }

            nodeValue = nodeValue & 0xffff;

            switch ((nodeValue >>> TYPE_SHIFT)) {
            case TYPE_NODE:
                node = nodeValue & VALUE_MASK;

                break;

            case TYPE_UNDEFINED:

                int oldNode = node;
                short oldNodeNewValue;

                if (bits > 0) {
                    node = ++lastTreeNode;
                    oldNodeNewValue = (short) ((TYPE_NODE << TYPE_SHIFT) | node);
                } else {
                    oldNodeNewValue = (short) ((TYPE_LITERAL << TYPE_SHIFT) | value);
                }

                if (msb == 0) {
                    treeLeft[oldNode] = oldNodeNewValue;
                } else {
                    treeRight[oldNode] = oldNodeNewValue;
                }

                break;

            case TYPE_LITERAL:
                throw new DataFormatException("Unexpected literal while adding node to Huffman tree");

            default:
                throw new Error("Unknown Huffman node type " + (nodeValue >>> TYPE_SHIFT));
            }
        }
    }

    /**
     * Build a new Huffman tree from the given lengths representation
     *
     * @param codeLengths The table of code lengths for each numerical value
     *
     * @throws DataFormatException If the tree cannot be built
     */
    void buildTree(int[] codeLengths) throws DataFormatException {
        if (codeLengths.length > maxCodes) {
            throw new DataFormatException("More codes than the maximum declared for this HuffmanTree");
        }

        /*
         * Count the number of codes of the given length
         */
        for (int i = 0; i < lengthsCount.length; i++)
            lengthsCount[i] = 0;

        for (int i = 0; i < codeLengths.length; i++) {
            lengthsCount[codeLengths[i]]++;
        }

        lengthsCount[0] = 0; // length count 0 means code not used so ignore it

        /*
         * Get the binary form of the first code of the given length
         */
        int code = 0;
        nextCode[0] = 0;

        for (int bits = 1; bits <= MAX_BITS; bits++) {
            code = (code + lengthsCount[bits - 1]) << 1;
            nextCode[bits] = code;
        }

        /*
         * Compute the binary form of each code and update the tree
         */
        clearTree();

        for (int i = 0; i < codeLengths.length; i++)
            if (codeLengths[i] > 0) {
                int length = codeLengths[i];
                code = nextCode[length]++;
                addNodeToTree(code, length, i);
            }
    }

    /**
     * Read a code from the decoder and return the numerical value of that code. The data read is not committed.
     *
     * @param decoder The decoder to read from
     *
     * @return The numerical value of the code read
     *
     * @throws DecoderNoMoreDataException If arrived to the end of the stream
     * @throws DataFormatException If the data read is invalid
     */
    int readCode(Decoder decoder) throws DecoderNoMoreDataException, DataFormatException {
        int nodeValue = TYPE_NODE << TYPE_SHIFT;

        while ((nodeValue >>> TYPE_SHIFT) == TYPE_NODE) {
            int node = nodeValue & VALUE_MASK;
            int bit = decoder.readBit();

            if (bit == 0) {
                nodeValue = treeLeft[node] & 0xffff;
            } else {
                nodeValue = treeRight[node] & 0xffff;
            }
        }

        if ((nodeValue >>> TYPE_SHIFT) != TYPE_LITERAL) {
            throw new DataFormatException("Invalid Huffman code");
        }

        return nodeValue & VALUE_MASK;
    }
}
