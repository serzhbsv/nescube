/*
 * Copyright (C) 2006 TopCoder Inc., All Rights Reserved.
 */
package com.topcoder.mobile.util.compression.decomp;

/**
 * <p>
 * This is a helper class during inflating. It allows to read some arbitrary number of bits, crossing byte boundaries.
 * If the end of the input data is reached a DecoderNoMoreDataException is thrown.
 * </p>
 *
 * <p>
 * Another feature of the decoder is committing. When you read some data it is uncommitted. If a
 * DecoderNoMoreDataException is throws, the current position will be shifted and the uncommitted bits will be reread
 * what help to write the Inflater. The bits are committed with commit(). There may be at most 24 uncommitted bits.
 * </p>
 *
 * <p>
 * The class is marked as final as this might help the VM to optimize the code
 * </p>
 *
 * @author Mafy, mikolajz
 * @version 1.0
 */
final class Decoder {
    /** The buffer is used to keep the data to be uncompressed. */
    private byte[] buf = new byte[0];

    /**
     * The length of the data that is yet to be read from the <code>buf</code> buffer. The bytes in the decoder window
     * are not counted.
     *
     * @see #buf
     * @see #off
     */
    private int len = 0;

    /**
     * The start offset of the is yet to be read from the <code>buf</code> buffer. The bytes in the decoder window byte
     * are treated as already read.
     *
     * @see #buf
     * @see #len
     */
    private int off = 0;

    /**
     * This is the 32-bit "window" through which the decoder sees the source file. The readBit and readBits methods
     * read from this variable. The commit method fills the variable with fresh data is there is room.
     *
     * @see #currentBit
     * @see #commitedBit
     */
    private int window;

    /**
     * The number of the next bit to be read from the window. The bits decoderCurrentBit .. 31 of window contains the
     * data that is yet to be read
     */
    private int currentBit;

    /**
     * <p>
     * The number of the first bit that have not been commited. Before a DecoderNoMoreData exception will be thrown,
     * the decoderCurrentBit will be reset to decoderCommitBit allowing us to reexecute the command with probably a
     * bigger buffer.
     * </p>
     *
     * <p>
     * There may be at most 24 uncommitted bits
     * </p>
     */
    private int commitedBit;

    /** Whether we need more input. Set to true when a DecoderNoMoreDataException is throws */
    private boolean needsInput;

    /**
     * Read a single bit from the input
     *
     * @return 0 or 1 - the value of the bit
     *
     * @throws DecoderNoMoreDataException If the end of buffer is reached
     */
    int readBit() throws DecoderNoMoreDataException {
        if (currentBit == 32) {
            currentBit = commitedBit;
            needsInput = true;
            throw new DecoderNoMoreDataException();
        }

        int ret = (window >>> currentBit) & 1;
        currentBit++;

        return ret;
    }

    /**
     * Read <code>bits</code> bits from the input.
     *
     * @param bits the number of bits to read
     *
     * @return A value from 0 to 2^bits - 1 - the value of the bits
     *
     * @throws DecoderNoMoreDataException If the end of buffer is reached
     */
    int readBits(int bits) throws DecoderNoMoreDataException {
        if ((currentBit + bits) > 32) {
            currentBit = commitedBit;
            needsInput = true;
            throw new DecoderNoMoreDataException();
        }

        int mask = (1 << bits) - 1;
        int shifted = window >>> currentBit;
        currentBit += bits;

        return shifted & mask;
    }

    /**
     * Move to the byte boundary. The bits between the current position and the byte boundary are not commited
     *
     * @throws DecoderNoMoreDataException
     */
    void moveToByteBoundry() throws DecoderNoMoreDataException {
        readBits(8 - (currentBit % 8));
    }

    /**
     * Commit the read bits. If some bits are uncommitted it means that after a DecoderNoMoreData exception is thrown,
     * the bits will be reread. There may be at most 24 uncommitted bits.
     */
    void commit() {
        while ((currentBit >= 8) && (len > 0)) {
            currentBit -= 8;
            window >>>= 8;
            window |= (buf[off] << 24);
            off++;
            len--;
        }

        commitedBit = currentBit;
    }

    /**
     * Reset the decoder. After a reset it can read a new stream of data. The decoder should be reset before the first
     * usage
     */
    void reset() {
        currentBit = 32;
        commitedBit = 32;
        needsInput = true;
        buf = new byte[0];
        len = 0;
        off = 0;
    }

    /**
     * <p>
     * Set the input of the Decoder to a new buffer. This method can be called when the previous buffer was consumed or
     * there is no buffer yet. The decoder window may contain some data from the previous buffer.
     * </p>
     *
     * <p>
     * The buf, off and len are assumed to be checked for validity by the caller so no ArrayIndexOutOfBound or
     * NullPointerException are thrown
     * </p>
     *
     * @param b The buffer to use for decoding
     * @param off The offset to the data in the buffer
     * @param len The length of data in the buffer
     *
     * @throws IllegalStateException If there is still some input in the decoder
     */
    void setInput(byte[] b, int off, int len) {
        if (this.len > 0) {
            throw new IllegalStateException("some input already available");
        }

        this.buf = b;
        this.off = off;
        this.len = len;

        if (len > 0) {
            needsInput = false;
        }

        commit(); // read the data into the window
    }

    /**
     * Checks if there is a need for a new buffer. <code>true</code> is returned if all the data from the previous
     * buffer was read or moved to the decoder window
     *
     * @return <code>true</code> if there is a need for a new buffer
     *
     * @see #setInput
     */
    boolean needsInput() {
        return needsInput;
    }

    /**
     * Get the remaining bytes of the current decoder
     *
     * @return The number of bytes in the buffer plus the number of full bytes in the decoder window
     */
    int getRemaining() {
        return len + ((32 - commitedBit) / 8);
    }
}
