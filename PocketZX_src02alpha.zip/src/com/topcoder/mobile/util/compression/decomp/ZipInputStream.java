/*
 * Copyright (C) 2006 TopCoder Inc., All Rights Reserved.
 */
package com.topcoder.mobile.util.compression.decomp;

import com.topcoder.mobile.util.compression.CRC32;
import com.topcoder.mobile.util.compression.ZipEntry;
import com.topcoder.mobile.util.compression.ZipException;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;


/**
 * <p>
 * This class is a subclass of InflaterInputStream that reads the entries of a ZIP file in sequential order. Create a
 * ZipInputStream by specifying the InputStream from which it is to read the contents of the ZIP file. Once the
 * ZipInputStream is created, you can use getNextEntry() to begin reading data from the next entry in the ZIP file.
 * This method must be called before read() is called to begin reading the first entry. getNextEntry() returns a
 * ZipEntry object that describes the entry being read, or null when there are no more entries to be read from the ZIP
 * file. The read() methods of ZipInputStream read until the end of the current entry and then return -1, indicating
 * that there is no more data to read. To continue with the next entry in the ZIP file, you must call getNextEntry()
 * again. Similarly, the skip() method only skips bytes within the current entry. closeEntry() can be called to skip
 * the remaining data in the current entry, but it is usually easier simply to call getNextEntry() to begin the next
 * entry.
 * </p>
 *
 * <p>
 * This class is meant to be compatible with java.util.zip.ZipInputStream from J2SE
 * </p>
 *
 * <p>
 * This class is thread-safe.
 * </p>
 *
 * @author Mafy, mikolajz
 * @version 1.0
 */
public class ZipInputStream extends InflaterInputStream implements com.topcoder.mobile.util.compression.ZipConstants {
    /** A constant used to mark the STORED (i.e. no compression) zip entry type */
    private static final int STORED = ZipEntry.STORED;

    /** A constant used to mark the DEFLATED (i.e. with compression) zip entry type */
    private static final int DEFLATED = ZipEntry.DEFLATED;

    /** The amount of leading 1 bits in the numbers 0..15 writted as a four-digit binary number */
    static final private int[] LEADING_ONES = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 3, 4 };

    /**
     * Represents the flag that is true when the ZIP input stream is closed. It is always set on true in close()
     * method.
     */
    private boolean closed = false;

    /**
     * <p>
     * The current zip entry data. May be <code>null</code> if no entry is currently opened
     * </p>
     */
    private ZipEntry entry;

    /**
     * <p>
     * Object used to compute the CRC-32 of the current entry uncompressed data.
     * </p>
     */
    private CRC32 crc = new CRC32();

    /** The number of uncomressed bytes remaining in the current entry */
    private long storedEntryRemaining;

    /**
     * <p>
     * Valid while reading headers and decompressing STORED entries. The super.buf may contain some data after
     * decompressing a DEFLATER entry because the data is sent to the inflated in larger chunks and may be not fully
     * consumed
     * </p>
     *
     * <p>
     * The data from the fields pos .. super.len - 1 of super.buf should be read before reading from the super.in
     * stream
     * </p>
     */
    protected int pos;

    /** A temporary buffer used in readLOC() and readEnd. Will be enlarged if needed */
    private byte[] tmpBuffer = new byte[256];

    /**
     * Creates a new ZIP input stream.
     *
     * @param in the actual input stream
     */
    public ZipInputStream(InputStream in) {
        super(in, new Inflater(true));
    }

    /**
     * Check to make sure that this stream has not been closed.
     *
     * @throws IOException - if an I/O error has occurred
     */
    private void ensureOpen() throws IOException {
        if (closed) {
            throw new IOException("Stream closed");
        }
    }

    /**
     * Reads the next ZIP file entry header and positions stream at the beginning of the entry data. After calling the
     * constructor you should call this method to open the first entry. Then after reading an End-of-Stream you should
     * open the next entry with this call. This function returns <code>null</code> if there are no more entries
     *
     * @return The description of the next entry that can be read of <code>null</code> if there are no more entries
     *
     * @throws IOException if an I/O error has occurred
     */
    public synchronized ZipEntry getNextEntry() throws IOException {
        ensureOpen();

        if (entry != null) {
            closeEntry();
        }

        crc.reset();
        inf.reset();
        entry = readLOC();

        if (entry == null) { // end of file reached

            return null;
        }

        if (entry.getMethod() == STORED) {
            storedEntryRemaining = entry.getSize();
        } else if (pos < len) { // some data remained after the previous deflater
            inf.setInput(buf, pos, len - pos);
        }

        return entry;
    }

    /**
     * Closes the current ZIP entry and positions the stream for reading the next entry.
     *
     * @throws IOException if an I/O error has occurred
     */
    public void closeEntry() throws IOException {
        ensureOpen();

        byte[] tmpbuf = new byte[512];

        while (read(tmpbuf, 0, tmpbuf.length) != -1)
            ;

        entry = null;
    }

    /**
     * <p>
     * Returns 0 after EOF has reached for the current entry data, otherwise returns 1.
     * </p>
     *
     * <p>
     * Programs should not count on this method to return the actual number of bytes that could be read without
     * blocking.
     * </p>
     *
     * @return 1 before EOF and 0 after EOF has reached for current entry.
     *
     * @throws IOException if an I/O error occurs.
     */
    public synchronized int available() throws IOException {
        if (entry == null) {
            return 0;
        }

        return 1;
    }

    /**
     * Read some raw data from super.buf or (if empty) from the input stream
     *
     * @param buffer The buffer to store the output in
     * @param offset The offset where to start storing the output
     * @param len The number of bytes to read
     *
     * @return The number of bytes actually read
     *
     * @throws IOException If an I/O error occurred
     *
     * @see #pos
     */
    private int readRaw(byte[] buffer, int offset, int len)
        throws IOException {
        int read = 0;

        if (pos < this.len) {
            // some data is remaining in the buffer
            int copylen = Math.min(this.len - pos, len);
            System.arraycopy(buf, pos, buffer, offset, copylen);
            pos += copylen;
            offset += copylen;
            read += copylen;
            len -= copylen;
        }

        if (len > 0) {
            len = in.read(buffer, offset, len);

            if (len != -1) {
                read += len;
            }
        }

        return ((read > 0) ? read : (-1));
    }

    /**
     * Read some raw data from super.buf or (if empty) from the input stream. There must be enough data to fill the
     * buffer. If not an EOFException is thrown
     *
     * @param buffer The buffer to store the output in
     * @param offset The offset where to start storint the output
     * @param len The number of bytes to read
     *
     * @return The number of bytes actually read - always len
     *
     * @throws IOException If an I/O error occurred
     * @throws ZipException If an EOF occurred
     *
     * @see #pos
     */
    private int readRawFully(byte[] buffer, int offset, int len)
        throws IOException {
        int pos = 0;

        while (pos < len) {
            int readLen = readRaw(buffer, offset + pos, len - pos);

            if (readLen == -1) {
                throw new ZipException("Unexpected end of stream");
            }

            pos += readLen;
        }

        return pos;
    }

    /**
     * Reads from the current ZIP entry into the buffer <code>b</code> (that can not be <code>null</code>), from the
     * start offset of the data - off and with the maximum number of bytes read - len. Blocks until some input is
     * available.
     *
     * @param buffer the buffer into which the data is read
     * @param offset the start offset of the data
     * @param len the maximum number of bytes read
     *
     * @return the actual number of bytes read, or -1 if the end of the entry is reached
     *
     * @throws IOException if an I/O error has occurred
     * @throws IndexOutOfBoundsException if a ZIP file error has occurred
     * @throws Error if the compression method is unknown (shouldn't happend - checked by ZipEntry.setMethod)
     */
    public synchronized int read(byte[] buffer, int offset, int len)
        throws IOException {
        ensureOpen();

        if ((offset < 0) || (len < 0) || (offset > (buffer.length - len))) {
            throw new IndexOutOfBoundsException("offset or len invalid");
        } else if (len == 0) {
            return 0;
        }

        if (entry == null) {
            return -1;
        }

        switch (entry.getMethod()) {
        case DEFLATED:
            len = super.read(buffer, offset, len);

            break;

        case STORED:

            if (storedEntryRemaining == 0) {
                len = -1;

                break;
            }

            if (len > storedEntryRemaining) {
                len = (int) storedEntryRemaining;
            }

            len = readRawFully(buffer, offset, len);
            storedEntryRemaining -= len;

            break;

        default:
            throw new Error("Unknown compression method " + entry.getMethod());
        }

        if (len == -1) {
            readEnd(entry);
            entry = null;
        } else {
            crc.update(buffer, offset, len);
        }

        return len;
    }

    /**
     * Closes the ZIP input stream.
     *
     * @throws IOException if an I/O error has occurred
     */
    public synchronized void close() throws IOException {
        closed = true;
        super.close();
    }

    /**
     * Read two bytes from the given table and treat them as a little-endian short
     *
     * @param buffer The buffer to read the data from
     * @param offset The offset of the first byte
     *
     * @return The number read
     */
    private int readLEUshort(byte[] buffer, int offset) {
        return ((int) buffer[offset] & 0xff) | (((int) buffer[offset + 1] & 0xff) << 8);
    }

    /**
     * Read four bytes from the given table and treat them as a little-endian int
     *
     * @param buffer The buffer to read the data from
     * @param offset The offset of the first byte
     *
     * @return The number read
     */
    private long readLEUint(byte[] buffer, int offset) {
        return ((long) buffer[offset] & 0xff) | (((long) buffer[offset + 1] & 0xff) << 8) |
        (((long) buffer[offset + 2] & 0xff) << 16) | (((long) buffer[offset + 3] & 0xff) << 24);
    }

    /**
     * Reads local file (LOC) header for next entry.
     *
     * @return The ZipEntry object for that header
     *
     * @throws IOException - if an I/O error has occurred
     * @throws ZipException - if a ZIP file error has occurred
     */
    private ZipEntry readLOC() throws IOException {
        byte[] headerBuf = new byte[LOCHDR];

        try {
            readRawFully(headerBuf, 0, LOCHDR);
        } catch (EOFException e) {
            return null;
        }

        if (readLEUint(headerBuf, 0) != LOCSIG) {
            return null;
        }

        // the name is stored directly after the header and is needed to create
        // a ZipEntry object
        int nameLength = readLEUshort(headerBuf, LOCNAM);

        if (nameLength == 0) {
            throw new ZipException("No name supplied");
        }

        if (tmpBuffer.length < nameLength) {
            tmpBuffer = new byte[nameLength];
        }

        readRawFully(tmpBuffer, 0, nameLength);

        String entryName = getUTF8String(tmpBuffer, 0, nameLength);
        ZipEntry entry = new ZipEntry(entryName);

        // setup other fields
        entry.setVersion(readLEUshort(headerBuf, LOCVER));
        entry.setFlag(readLEUshort(headerBuf, LOCFLG));
        entry.setMethod(readLEUshort(headerBuf, LOCHOW));
        entry.setDOSTime(readLEUshort(headerBuf, LOCTIM));

        if ((entry.getFlag() & 1) != 0) { // encryption bit
            throw new ZipException("Encryption not supported");
        }

        if ((entry.getFlag() & 8) == 0) {
            // the CRC, compressed size and size is stored in the header
            entry.setCompressedSize(readLEUint(headerBuf, LOCSIZ));
            entry.setSize(readLEUint(headerBuf, LOCLEN));
            entry.setCrc(readLEUint(headerBuf, LOCCRC));
        } else if (entry.getMethod() != DEFLATED) {
            throw new ZipException("Only DEFLATE entries may have an EXT header");
        }

        // the extra data is stored immediately after the filename
        int extraLen = readLEUshort(headerBuf, LOCEXT);
        byte[] extraData = new byte[extraLen];
        readRawFully(extraData, 0, extraLen);
        entry.setExtra(extraData);

        return entry;
    }

    /**
     * Decodes a UTF8-encoded String from the specified byte array.
     *
     * @param buffer The buffer to read the string from
     * @param offset The offset where the string starts
     * @param len The number of bytes of this string
     *
     * @return The string as a Java object
     *
     * @throws IllegalArgumentException If the buffer doesn't contain a valid UTF-8 string
     */
    private static String getUTF8String(byte[] buffer, int offset, int len) {
        StringBuffer output = new StringBuffer(buffer.length);

        while (offset < len) {
            byte c = buffer[offset++];

            if ((c & 0x80) == 0) {
                output.append((char) c);

                continue;
            }

            // count the ones at the beginning of the byte
            int ones = LEADING_ONES[((int) c & 0xff) >> 4];
            int newChar;

            if ((ones == 1) || (ones == 4)) {
                throw new IllegalArgumentException("Not a valid UTF-8 string");
            }

            newChar = c & ((1 << (7 - ones)) - 1);

            for (int i = 0; i < (ones - 1); i++) {
                if (offset == len) {
                    throw new IllegalArgumentException("End of string inside an UTF-8 sequence");
                }

                byte nc = buffer[offset++];

                if ((nc & 0xc0) != 0x80) {
                    throw new IllegalArgumentException("Not a valid UTF-8 string");
                }

                newChar <<= 6;
                newChar |= (nc & 0x3f);
            }

            output.append((char) newChar);
        }

        return output.toString();
    }

    /**
     * <p>
     * Creates a new <code>ZipEntry</code> object for the specified entry name.
     * </p>
     *
     * <p>
     * Note: this method is unused and kept only for compatibility with the design
     * </p>
     *
     * @param name the ZIP file entry name
     *
     * @return The newly created entry
     */
    protected ZipEntry createZipEntry(String name) {
        return new ZipEntry(name);
    }

    /**
     * Reads end of deflated entry as well as EXT descriptor if present.
     *
     * @param zipentry The current entry
     *
     * @throws IOException - if an I/O error has occurred
     * @throws IllegalStateException If this method if called when the inflator is still working - shouldn't happend
     * @throws ZipException - if a ZIP file error has occurred
     */
    private void readEnd(ZipEntry zipentry) throws IOException {
        if (zipentry.getMethod() == DEFLATED) {
            if (!inf.finished()) {
                throw new IllegalStateException("Internal error - inflater not finished");
            }

            // make the remaing bytes available for reading
            int n = inf.getRemaining();
            pos = len - n;
        }

        if ((zipentry.getFlag() & 8) == 8) {
            // EXT descriptor present. Read the sig to check the type
            readRawFully(tmpBuffer, 0, 4);

            long sig = readLEUint(tmpBuffer, 0);

            if (sig != EXTSIG) {
                //no EXTSIG present. There are 8 more bytes
                readRawFully(tmpBuffer, 4, 8);
                zipentry.setCrc(sig);
                zipentry.setCompressedSize(readLEUint(tmpBuffer, 4));
                zipentry.setSize(readLEUint(tmpBuffer, 8));
            } else {
                // this is an EXTSIG header
                readRawFully(tmpBuffer, 4, EXTHDR - 4);
                zipentry.setCrc(readLEUint(tmpBuffer, EXTCRC));
                zipentry.setCompressedSize(readLEUint(tmpBuffer, EXTSIZ));
                zipentry.setSize(readLEUint(tmpBuffer, EXTLEN));
            }
        }

        if (entry.getMethod() != STORED) {
            // no need to check for STORED entries as we know we have read the given amount of data
            if (zipentry.getSize() != inf.getTotalOut()) {
                throw new ZipException("invalid entry size (expected " + zipentry.getSize() + " but got " +
                    inf.getTotalOut() + " bytes)");
            }

            if (zipentry.getCompressedSize() != inf.getTotalIn()) {
                throw new ZipException("invalid entry compressed size (expected " + zipentry.getCompressedSize() +
                    " but got " + inf.getTotalIn() + " bytes)");
            }
        }

        if (zipentry.getCrc() != crc.getValue()) {
            throw new ZipException("invalid entry CRC (expected 0x" + Integer.toHexString((int) zipentry.getCrc()) +
                " but got 0x" + Integer.toHexString((int) crc.getValue()) + ")");
        }
    }
}
