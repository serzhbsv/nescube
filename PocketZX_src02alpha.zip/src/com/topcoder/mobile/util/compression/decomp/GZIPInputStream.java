/*
 * Copyright (C) 2006 TopCoder Inc., All Rights Reserved.
 */
package com.topcoder.mobile.util.compression.decomp;

import com.topcoder.mobile.util.compression.CRC32;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;


/**
 * <p>
 * This class is a subclass of InflaterInputStream that reads and uncompresses data compressed in GZIP format. To
 * create a GZIPInputStream, simply specify the InputStream to read compressed data from and, optionally, a buffer
 * size for the internal decompression buffer. Once a GZIPInputStream is created, you can use the read() and close()
 * methods as you would with any input stream.
 * </p>
 *
 * <p>
 * This class is meant to be compatible with java.util.zip.GZIPInputStream from J2SE
 * </p>
 *
 * <p>
 * This class is thread-safe.
 * </p>
 *
 * @author Mafy, mikolajz
 * @version 1.0
 *
 * @see InflaterInputStream
 */
public class GZIPInputStream extends InflaterInputStream {
    /** Represents the GZIP header magic number. */
    public static final int GZIP_MAGIC = 0x8b1f;

    /** Represents the Header CRC flag of File header. */
    private static final int FHCRC = 2;

    /** Represents the Extra field flag of File header. */
    private static final int FEXTRA = 4;

    /** Represents the File name flag of File header. */
    private static final int FNAME = 8;

    /** Represents the File comment flag of File header. */
    private static final int FCOMMENT = 16;

    /** The length of the GZIP header (without the optional extra, name or comment fields) */
    private static final int HEADER_LEN = 10;

    /** The length of the GZIP trailer */
    private static final int TRAILER_LEN = 8;

    /** Indicates end of input stream has been reached */
    protected boolean eos;

    /** Represents the flag that is true when the input stream is closed. It is set on true in close() method. */
    private boolean closed = false;

    /**
     * <p>
     * Represents CRC-32 of uncompressed data.
     * </p>
     *
     * <p>
     * It is set in read(...) method and can not be null.
     * </p>
     */
    private CRC32 crc = new CRC32();

    /**
     * Creates a new input stream with the specified buffer size.
     *
     * @param in the input stream with the GZIP compressed data
     * @param size the input buffer size
     *
     * @throws IOException if an I/O error has occurred
     */
    public GZIPInputStream(InputStream in, int size) throws IOException {
        super(in, new Inflater(true), size);
        readHeader();
    }

    /**
     * Creates a new input stream with a default buffer size.
     *
     * @param in the input stream with the GZIP compressed data
     *
     * @throws IOException if an I/O error has occurred
     */
    public GZIPInputStream(InputStream in) throws IOException {
        super(in, new Inflater(true));
        readHeader();
    }

    /**
     * Check to make sure that this stream has not been closed.
     *
     * @throws IOException - if an I/O error has occurred
     */
    private void ensureOpen() throws IOException {
        if (closed) {
            throw new IOException("The stream is closed");
        }
    }

    /**
     * Reads and uncompresses data into an array of bytes - b that can not be null, from the start offset of the data -
     * off and with the maximum number of bytes read - len. Blocks until some input is available for decompression.
     *
     * @param buffer the buffer into which the data is read
     * @param offset the start offset of the data
     * @param len the maximum number of bytes read
     *
     * @return the actual number of bytes read, or -1 if the end of the compressed input stream is reached
     *
     * @throws IOException if an I/O error has occurred or the compressed input data is corrupt
     */
    public synchronized int read(byte[] buffer, int offset, int len)
        throws IOException {
        ensureOpen();

        if (eos) {
            return -1;
        }

        int readLen = super.read(buffer, offset, len);

        if (readLen == -1) {
            readTrailer();
            eos = true;
        } else {
            crc.update(buffer, offset, readLen);
        }

        return readLen;
    }

    /**
     * Closes the input stream.
     *
     * @throws IOException if an I/O error has occurred
     */
    public synchronized void close() throws IOException {
        closed = true;
        super.close();
    }

    /**
     * Read two bytes from the given table and treat them as a little-endian short
     *
     * @param buffer The buffer to read the data from
     * @param offset The offset of the first byte
     *
     * @return The number read
     */
    private int readLEUshort(byte[] buffer, int offset) {
        return ((int) buffer[offset] & 0xff) | (((int) buffer[offset + 1] & 0xff) << 8);
    }

    /**
     * Read four bytes from the given table and treat them as a little-endian int
     *
     * @param buffer The buffer to read the data from
     * @param offset The offset of the first byte
     *
     * @return The number read
     */
    private long readLEUint(byte[] buffer, int offset) {
        return ((long) buffer[offset] & 0xff) | (((long) buffer[offset + 1] & 0xff) << 8) |
        (((long) buffer[offset + 2] & 0xff) << 16) | (((long) buffer[offset + 3] & 0xff) << 24);
    }

    /**
     * Read a len bytes into the buffer. If an end-of-stream is reached, an EOFException is thrown
     *
     * @param buffer The buffer to store the content
     * @param offset Where to start the storing from
     * @param len The number of bytes to read
     *
     * @throws IOException If an error occurs (e.g. an end-of-stream is reached)
     * @throws EOFException If an end-of-stream is reached
     */
    private void readFully(byte[] buffer, int offset, int len)
        throws IOException {
        int pos = 0;

        while (pos < len) {
            int readLen = in.read(buffer, offset + pos, len - pos);

            if (readLen == -1) {
                throw new EOFException("Unexpected end of file");
            }

            pos += readLen;
        }
    }

    /**
     * Ignore a NULL-terminated string as found the header
     *
     * @throws IOException If an I/O error occurs (e.g. an end of file)
     * @throws EOFException If an end-of-stream is reached
     */
    private void ignoreHeaderString() throws IOException {
        int nextChar;

        do {
            nextChar = in.read();

            if (nextChar == -1) {
                throw new EOFException("Unexpected end of file");
            }
        } while (nextChar != 0);
    }

    /**
     * Reads GZIP member header.
     *
     * @throws IOException - if an I/O error has occurred
     */
    private void readHeader() throws IOException {
        // read the header
        byte[] header = new byte[HEADER_LEN];
        readFully(header, 0, HEADER_LEN);

        if (readLEUshort(header, 0) != GZIP_MAGIC) {
            throw new IOException("GZIP magic not found");
        }

        if (header[2] != 8) { // compression method
            throw new IOException("Unknown compression method");
        }

        int flags = header[3];

        // the rest of the header is ignored. The header variable will be used as a buffer
        if ((flags & FEXTRA) != 0) {
            // ignore the extra bytes
            readFully(header, 0, 2);

            int xlen = readLEUshort(header, 0);
            byte[] buffer;

            if (xlen > header.length) {
                buffer = new byte[xlen];
            } else {
                buffer = header;
            }

            readFully(buffer, 0, xlen);
        }

        if ((flags & FNAME) != 0) { // ignore the original name
            ignoreHeaderString();
        }

        if ((flags & FCOMMENT) != 0) { // ignore the comment
            ignoreHeaderString();
        }

        if ((flags & FHCRC) != 0) { // ignore the header CRC
            readFully(header, 0, 2);
        }
    }

    /**
     * Reads GZIP member trailer.
     *
     * @throws IOException - if an I/O error has occurred
     */
    private void readTrailer() throws IOException {
        byte[] trailer = new byte[TRAILER_LEN];
        int remaining = inf.getRemaining();
        int bytesFromInflater = Math.min(TRAILER_LEN, remaining);
        System.arraycopy(buf, len - remaining, trailer, 0, bytesFromInflater);

        if (bytesFromInflater < TRAILER_LEN) {
            readFully(trailer, bytesFromInflater, TRAILER_LEN - bytesFromInflater);
        }

        long expectedCrc = ((long) readLEUint(trailer, 0)) & 0xffffffffL;
        long actualCrc = crc.getValue();

        if (expectedCrc != actualCrc) {
            throw new IOException("CRC32 mismatch in GZIP file");
        }

        long expectedSize = ((long) readLEUint(trailer, 4)) & 0xffffffffL;

        if (expectedSize != inf.getTotalOut()) {
            throw new IOException("Uncompressed file size mismatch in GZIP file");
        }
    }
}
