/*
 * Copyright (C) 2006 TopCoder Inc., All Rights Reserved.
 */
package com.topcoder.mobile.util.compression.decomp;

import com.topcoder.mobile.util.compression.DataFormatException;


/**
 * <p>
 * This class implements the general ZLIB data-decompression algorithm used by gzip, PKZip, and other data-compression
 * applications. It decompresses or inflates data compressed through the Deflater class. The important methods of this
 * class are setInput(), which specifies input data to be decompressed, and inflate(), which decompresses the input
 * data into an output buffer. A number of other methods exist so that this class can be used for stream-based
 * decompression, as it is in the higher-level classes, such as GZIPInputStream and ZipInputStream. These stream-based
 * classes are sufficient in most cases. Most applications do not need to use Inflater directly.
 * </p>
 *
 * <p>
 * This class is meant to be compatible with java.util.zip.Inflater from J2SE
 * </p>
 *
 * <p>
 * This class is thread-safe
 * </p>
 *
 * @author Mafy, mikolajz
 * @version 1.0
 */
public class Inflater {
    /**
     * <p>
     * A constant on the beginning of each block meaning this block is not compressed
     * </p>
     *
     * <p>
     * The DEFLATE standard defines it as 0
     * </p>
     */
    private static final int DEFLATE_NO_COMPRESSION = 0;

    /**
     * <p>
     * A constant on the beginning of each block meaning this block is compressed with fixed Huffman codes
     * </p>
     *
     * <p>
     * The DEFLATE standard defines it as 1
     * </p>
     */
    private static final int DEFLATE_FIXED_HUFFMAN = 1;

    /**
     * <p>
     * A constant on the beginning of each block meaning this block is compressed with dynamic Huffman codes
     * </p>
     *
     * <p>
     * The DEFLATE standard defines it as 2
     * </p>
     */
    private static final int DEFLATE_DYNAMIC_HUFFMAN = 2;

    /**
     * <p>
     * The code that marks the end of a fixed/dynamic Huffman block
     * </p>
     *
     * <p>
     * The DEFLATE standard defines it as 256
     * </p>
     */
    private static final int DEFLATE_EOB_CODE = 256;

    /**
     * <p>
     * The first code that means a length and not a literal
     * </p>
     *
     * <p>
     * The DEFLATE standard defines it as 257
     * </p>
     */
    private static final int DEFLATE_FIRST_LENGTH_CODE = 257;

    /**
     * <p>
     * The last valid literal/distance code
     * </p>
     *
     * <p>
     * The DEFLATE standard defines it as 285
     * </p>
     */
    private static final int DEFLATE_LAST_CODE = 285;

    /**
     * <p>
     * The last valid distance code
     * </p>
     *
     * <p>
     * The DEFLATE standard defines it as 29
     * </p>
     */
    private static final int DEFLATE_LAST_DISTANCE_CODE = 29;

    /**
     * <p>
     * The maximum length of a Huffman code
     * </p>
     *
     * <p>
     * In the DEFLATE standard it is 19 (maybe even 16 but it's safer to use a bigger value)
     * </p>
     */
    private static final int DEFLATE_HUFFMAN_CODE_LENGTHS = 19;

    /** The amount of extra bits for each length code, as defined in the DEFLATE standard */
    private static final int[] DEFLATE_LENGTH_EXTA_BITS = new int[] {
            0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0
        };

    /** The first length value for each length code, as defined in the DEFLATE standard */
    private static final int[] DEFLATE_LENGTH_BASE = new int[] {
            3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227,
            258
        };

    /** The first distance value for each distance code, as defined by the DEFLATE standard */
    private static final int[] DEFLATE_DIST_BASE = new int[] {
            1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097,
            6145, 8193, 12289, 16385, 24577
        };

    /** The order in which the code lengths are stored in the header, as defined in the DEFLATER standard */
    private static final int[] DEFLATE_HUFFMAN_CODE_LENGTHS_ORDER = new int[] {
            16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15
        };

    /**
     * This table maps each number 0..15 to it's value after treating it as a four bit value and reversing the bits.
     * E.g. 0101 after reversing is 1010, so REVERSE_BITS[5] == 10
     */
    private static final int[] REVERSE_BITS = new int[] { 0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 13, 3, 11, 7, 15 };

    /**
     * This state means we are at the beginning of the file and are expecting the ID, FLG header
     *
     * @see #state
     */
    private static final int STATE_FILE_HEADER = 0;

    /**
     * This state means we have read the file header, the FDICT is set and we want to read the four DICTID bytes.
     * stateDictIdBytesRead bytes are already read
     *
     * @see #state
     */
    private static final int STATE_READ_DICT_ID = 1;

    /**
     * This state means that we are expecting to read a block header (BFINAL, BTYPE)
     *
     * @see #state
     */
    private static final int STATE_BLOCK_HEADER = 2;

    /**
     * This state means we are about to read the LEN field of a block in the COPY compression mode
     *
     * @see #state
     */
    private static final int STATE_COPY_DATA_LEN = 3;

    /**
     * This state means we are about to read the NLEN field of a block in the COPY compression mode. The LEN is read
     * and stored in stateUncompressedDataLength
     *
     * @see #state
     */
    private static final int STATE_COPY_DATA_NLEN = 4;

    /**
     * This state means we are about to copy data from a block in the COPY mode. The uncompressedDataLength stores the
     * number of bytes to be copies
     *
     * @see #state
     */
    private static final int STATE_COPY_DATA = 5;

    /**
     * This state means we are about to read the header of a dynamic Huffman block
     *
     * @see #state
     */
    private static final int STATE_DYN_HUFFMAN_HEADER = 6;

    /**
     * This state means we are about to read the code lengths codes for the literal and distance codes.
     * stateCodeLengthsCodesCount is the number of codes lengths that are yet to be read. The
     * stateReadHuffmanCodeCounter stores the id of the next code length to read. The lengths are used to build the
     * stateCodeLengthsHuffmanTree.
     *
     * @see #state
     */
    private static final int STATE_DYN_HUFFMAN_READ_CODE_LENGTHS = 7;

    /**
     * This state means we are about to read the code lengths for literal/length codes. The stateReadHuffmanCodeCounter
     * stores the id of the next code to read. The code length are stored in stateLiteralCodeLengths and are used to
     * build the stateLiteralsHuffmanTree.
     *
     * @see #state
     */
    private static final int STATE_DYN_HUFFMAN_READ_LITERAL_CODES = 8;

    /**
     * This state means we are about to read the code lengths for distance codes. The stateReadHuffmanCodeCounter
     * stores the id of the next code to read. The code length are stored in stateDistanceCodeLengths and are used to
     * build the stateDistanceHuffmanTree.
     *
     * @see #state
     */
    private static final int STATE_DYN_HUFFMAN_READ_DISTANCE_CODES = 9;

    /**
     * This state means we are reading a fixed/dynamic Huffman encoded block and we are about to read a literal/length
     * code.
     *
     * @see #state
     */
    private static final int STATE_READ_CODE = 10;

    /**
     * This state means we are reading a fixed/dynamic Huffman encoded block and we are about to read a distance code.
     *
     * @see #state
     */
    private static final int STATE_READ_DIST = 11;

    /**
     * This state means we are reading a fixed/dynamic Huffman and we have encounted a (length, distance) pair. We are
     * now copying the data from the window to the output
     *
     * @see #state
     */
    private static final int STATE_DIST_COPY = 12;

    /** The total number of bytes output so far */
    private int totalOut;

    /** The total number of bytes input so far */
    private int totalIn;

    /**
     * The decoder manager the input and allows to read some specified number of bytes even across bytes boundaries
     *
     * @see #state
     */
    private Decoder decoder = new Decoder();

    /** This flag is true if the end of the compressed data stream has been reached. */
    private boolean finished;

    /** This flag is true if the decompression have stopped because a preset dictionary is needed */
    private boolean needDict;

    /** This variable is true is the ZLIB header and checksum fields will be ignored */
    private boolean noWrap;

    /**
     * <p>
     * The state of the decompression engine. The problem with inflating is that the input may end at every moment - e.g.
     * in the middle of decoding a Huffman code. This is handled by throwing a DecoderNoMoreDataExcpetion. This
     * exception is caught in the inflate() method the method returns.
     * </p>
     *
     * <p>
     * The problem is that after inflate returned the user may overwrite the input table with some new data. That means
     * the first part of the Huffman code will get overwritten.
     * </p>
     *
     * <p>
     * To solve this problem we keep the state of the inflater in the object variables. However updating the state
     * after reading each bit would kill the performance so we allow up to 24 bits to be read but "uncommitted". Such
     * bits are stored in the decoder (so they want be overwritten by the caller) and will be reread after an
     * end-of-input happens.
     * </p>
     *
     * @see #decoder
     */
    private int state;

    /** Used then parsing the file header - the number of DICTID bytes that are already read */
    private int stateDictIdBytesRead;

    /**
     * Is the block we are processing the last block?
     *
     * @see #state
     */
    private boolean stateIsLastBlock;

    /**
     * Does the block we are processing use fixed Huffman codes (value undefined for COPY blocks)?
     *
     * @see #state
     */
    private boolean stateBlockFixedCodes;

    /** Used for COPY block. The number of bytes that are yet to read. */
    private int stateUncompressedDataLength;

    /**
     * Used in the STATE_DIST_COPY. The number of bytes we are yet to copy because of a (length, distance) pair.
     *
     * @see #STATE_DIST_COPY
     * @see #state
     */
    private int stateCopyLength;

    /**
     * Used in the STATE_DIST_COPY. The distance we are using to copy after encounting a (length, distance) pair.
     *
     * @see #STATE_DIST_COPY
     * @see #state
     */
    private int stateCopyDistance;

    /**
     * Used in dynamic Huffman blocks. The number of literal/length codes used in this block
     *
     * @see #state
     */
    private int stateLiteralCodesCount;

    /**
     * Used in dynamic Huffman blocks. The number of distance codes used in this block
     *
     * @see #state
     */
    private int stateDistanceCodesCount;

    /**
     * Used in dynamic Huffman blocks. The number of code length codes used in this block
     *
     * @see #state
     */
    private int stateCodeLengthsCodesCount;

    /**
     * Used while reading dynamic Huffman codes. The number of code lengths that are already read
     *
     * @see #state
     */
    private int stateReadHuffmanCodeCounter;

    /** The Huffman tree constructed for the code lengths codes */
    private HuffmanTree stateCodeLengthsHuffmanTree = new HuffmanTree(DEFLATE_HUFFMAN_CODE_LENGTHS);

    /** The Huffman tree constructed for the literal/length codes */
    private HuffmanTree stateLiteralsHuffmanTree = new HuffmanTree(DEFLATE_LAST_CODE + 1);

    /** The Huffman tree constructed for the distance codes */
    private HuffmanTree stateDistanceHuffmanTree = new HuffmanTree(DEFLATE_LAST_DISTANCE_CODE + 1);

    /** Used to store the retrieved values while reading the code lengths lengths */
    private int[] stateBlockCodeLengths = new int[DEFLATE_HUFFMAN_CODE_LENGTHS];

    /** Used to store the retrieved values while reading the listeral/length code lengths */
    private int[] stateBlockLiteralCodes = new int[DEFLATE_LAST_CODE + 1];

    /** Used to store the retrieved values while reading the distance code lengths */
    private int[] stateBlockDistanceCodes = new int[DEFLATE_LAST_DISTANCE_CODE + 1];

    /**
     * The window used by the DEFLATE algorithm. It stores the last 32.768 bytes of output data. It is needed to handle
     * the (length, distance) pairs.
     */
    private byte[] windowData = new byte[32768];

    /** The position at which the next byte should be stored in the window */
    private int windowPos = 0;

    /**
     * <p>
     * Creates a new decompressor. If the parameter 'nowrap' is true then the ZLIB header and checksum fields will not
     * be used. This provides compatibility with the compression format used by both GZIP and PKZIP.
     * </p>
     *
     * @param nowrap if true then support GZIP compatible compression
     */
    public Inflater(boolean nowrap) {
        this.noWrap = nowrap;
        reset();
    }

    /**
     * Creates a new decompressor that uses the ZLIB header and checksum field
     */
    public Inflater() {
        this(false);
    }

    /**
     * <p>
     * Read a fixed literal/length code as defined in the DEFLATER standard
     * </p>
     *
     * <p>
     * This method is marked as final as this may help the VM optimizer
     * </p>
     *
     * @return The code that was read
     *
     * @throws DecoderNoMoreDataException If the input data was finished while decoding
     */
    private final int readFixedCode() throws DecoderNoMoreDataException {
        int bits = decoder.readBits(7);
        bits = (REVERSE_BITS[bits & 0xf] << 4) | REVERSE_BITS[bits >>> 4];

        if ((bits & 0xf0) < 0x30) {
            return (bits >>> 1) + 0x100;
        }

        bits |= decoder.readBit();

        if ((bits & 0xc0) != 0xc0) {
            return bits - 0x30;
        }

        if ((bits & 0xf1) == 0xc) {
            return bits - 0xc0 + 280;
        }

        bits = (bits << 1) | decoder.readBit();

        return bits - 0x190 + 0x90;
    }

    /**
     * <p>
     * Read a literal/length code. Depending on the block type the Huffman tree or the Huffman code is used
     * </p>
     *
     * <p>
     * This method is marked as final as this may help the VM optimizer
     * </p>
     *
     * @return The read code
     *
     * @throws DecoderNoMoreDataException If the input data was finished while decoding
     * @throws DataFormatException If the input data doesn't contain a valid code
     */
    private final int readCode() throws DecoderNoMoreDataException, DataFormatException {
        if (stateBlockFixedCodes) {
            return readFixedCode();
        } else {
            return stateLiteralsHuffmanTree.readCode(decoder);
        }
    }

    /**
     * <p>
     * Read a fixed distance code as defined in the DEFLATER standard
     * </p>
     *
     * <p>
     * This method is marked as final as this may help the VM optimizer
     * </p>
     *
     * @return The code that was read
     *
     * @throws DecoderNoMoreDataException If the input data was finished while decoding
     * @throws DataFormatException If the input data doesn't contain a valid code
     */
    private final int readFixedDistanceCode() throws DecoderNoMoreDataException, DataFormatException {
        int bits = decoder.readBits(5);
        bits = (REVERSE_BITS[bits & 0xf] << 1) | ((bits >>> 4) & 0x1);

        return bits;
    }

    /**
     * <p>
     * Read a distance value. Depending on the block type the Huffman tree or the Huffman code is used. The extra
     * bits are read and the code is translated to a distance value
     * </p>
     *
     * <p>
     * This method is marked as final as this may help the VM optimizer
     * </p>
     *
     * @return The read code
     *
     * @throws DecoderNoMoreDataException If the input data was finished while decoding
     * @throws DataFormatException If the input data doesn't contain a valid code
     */
    private final int readDistance() throws DecoderNoMoreDataException, DataFormatException {
        int code;

        if (stateBlockFixedCodes) {
            code = readFixedDistanceCode();
        } else {
            code = stateDistanceHuffmanTree.readCode(decoder);
        }

        if (code > DEFLATE_LAST_DISTANCE_CODE) {
            throw new DataFormatException("Distance code out of range");
        }

        int extrabits = (code / 2) - 1;
        int extradata = 0;

        if (extrabits > 0) {
            extradata = decoder.readBits(extrabits);
        }

        return DEFLATE_DIST_BASE[code] + extradata;
    }

    /**
     * Sets input data for decompression from the input data bytes - b, from the start offset of the data - off and
     * with the length len. Should be called whenever needsInput() returns true indicating that more input data is
     * required.
     *
     * @param b the input data bytes
     * @param off the start offset of the input data
     * @param len the length of the input data
     *
     * @throws NullPointerException - if an null argument is received
     * @throws ArrayIndexOutOfBoundsException - if the array index is less than the offset
     *
     * @see Inflater#needsInput
     */
    public synchronized void setInput(byte[] b, int off, int len) {
        if (b == null) {
            throw new NullPointerException("b is null");
        }

        if ((off < 0) || ((off + len) > b.length) || (len < 0)) {
            throw new ArrayIndexOutOfBoundsException("off or len invalid");
        }

        decoder.setInput(b, off, len);
    }

    /**
     * Sets input data for decompression. Should be called whenever needsInput() returns true indicating that more
     * input data is required.
     *
     * @param b the input data bytes
     *
     * @see Inflater#needsInput
     */
    public void setInput(byte[] b) {
        setInput(b, 0, b.length);
    }

    /**
     * Sets the preset dictionary to the given array of bytes from the dictionary data bytes - b that can not be null,
     * from the start offset of the data - off and with the length len. Should be called when inflate() returns 0 and
     * needsDictionary() returns true indicating that a preset dictionary is required.
     *
     * @param b the dictionary data bytes
     * @param off the start offset of the data
     * @param len the length of the data
     *
     * @throws NullPointerException - if an invalid argument is received
     * @throws ArrayIndexOutOfBoundsException - if the offset is larger than the array index
     * @throws IllegalStateException When trying to call this method when no dictionary is needed
     *
     * @see Inflater#needsDictionary
     */
    public synchronized void setDictionary(byte[] b, int off, int len) {
        if (b == null) {
            throw new NullPointerException("parameter byte[] b should not be null");
        }

        if ((off < 0) || (len < 0) || ((off + len) > b.length)) {
            throw new ArrayIndexOutOfBoundsException("off or len invalid");
        }

        if (needsDictionary() == false) {
            throw new IllegalStateException("No dictionary needed");
        }

        int copy = Math.min(len, windowData.length);
        System.arraycopy(b, off + len - copy, windowData, 0, copy);
        windowPos = copy;
        needDict = false;
    }

    /**
     * Sets the preset dictionary to the given array of bytes. Should be called when inflate() returns 0 and
     * needsDictionary() returns true indicating that a preset dictionary is required.
     *
     * @param b the dictionary data bytes
     *
     * @see Inflater#needsDictionary
     */
    public void setDictionary(byte[] b) {
        setDictionary(b, 0, b.length);
    }

    /**
     * <p>
     * Returns true if a preset dictionary is needed for decompression.
     * A bit in the ZLIB header can mark that this file uses a dictionary.
     * In such a case for the decompression to start a dictionary should
     * be preloaded with this method
     * </p>
     *
     * @return true if a preset dictionary is needed for decompression
     *
     * @see Inflater#setDictionary(byte[])
     */
    public synchronized boolean needsDictionary() {
        return needDict;
    }

    /**
     * Returns the total number of bytes remaining in the input buffer. This can be used to find
     * out what bytes still remains in the input buffer after decompression has finished.
     *
     * @return the total number of bytes remaining in the input buffer
     */
    public synchronized int getRemaining() {
        return decoder.getRemaining();
    }

    /**
     * Returns true if no data remains in the input buffer. This can be used to determine if setInput should be called
     * in order to provide more input.
     *
     * @return true if no data remains in the input buffer
     *
     * @see #setInput(byte[])
     * @see #setInput(byte[], int, int)
     */
    public synchronized boolean needsInput() {
        return decoder.needsInput() || finished;
    }

    /**
     * Return true if the end of the compressed data stream has been reached.
     *
     * @return true if the end of the compressed data stream has been reached
     */
    public synchronized boolean finished() {
        return finished;
    }

    /**
     * <p>
     * Read the code lengths. The Huffman codes for the literal and distance alphabets are encoded by providing lengths
     * of the codes. The lengths are encoded with a special Huffman code. This function reads the code lengths.
     * </p>
     *
     * <p>
     * The result will be stored in the output variable. The <code>stateReadHuffmanCodeCounter</code> variable will
     * keep the number of codes read so far. After reading each code the data in the decoder will be commit.
     * </p>
     *
     * @param output The table to store the lengths in
     * @param numcodes The number of codes to read
     *
     * @throws DataFormatException If the input file is invalid
     * @throws DecoderNoMoreDataException If there is no more data in the decoder
     */
    private void readLengths(int[] output, int numcodes)
        throws DataFormatException, DecoderNoMoreDataException {
        while (stateReadHuffmanCodeCounter < numcodes) {
            int code = stateCodeLengthsHuffmanTree.readCode(decoder);

            if (code < 15) {
                output[stateReadHuffmanCodeCounter++] = code;
            } else if (code == 16) {
                if (stateReadHuffmanCodeCounter == 0) {
                    throw new DataFormatException("Repeat Huffman code found when no previous code");
                }

                int prevCode = output[stateReadHuffmanCodeCounter - 1];
                int count = decoder.readBits(2) + 3;

                if ((count + stateReadHuffmanCodeCounter) > numcodes) {
                    throw new DataFormatException("Repeat Huffman code throws out of bounds");
                }

                for (int i = 0; i < count; i++)
                    output[stateReadHuffmanCodeCounter++] = prevCode;
            } else if ((code == 17) || (code == 18)) {
                int count;

                if (code == 17) {
                    count = decoder.readBits(3) + 3;
                } else {
                    count = decoder.readBits(7) + 11;
                }

                if ((count + stateReadHuffmanCodeCounter) > numcodes) {
                    throw new DataFormatException("Repeat Huffman code throws out of bounds");
                }

                for (int i = 0; i < count; i++)
                    output[stateReadHuffmanCodeCounter++] = 0;
            } else {
                throw new DataFormatException("Invalid code length Huffman code " + code);
            }

            decoder.commit();
        }

        for (int i = stateReadHuffmanCodeCounter; i < output.length; i++)
            output[i] = 0;
    }

    /**
     * Uncompresses bytes into specified buffer <code>b</code>.
     * The start offset of the data is passed in <code>off</code> and the maximum number of uncompressed
     * bytes to write in <code>len</code>. Returns the actual
     * number of uncompressed bytes. After the return from this function you may check with needsInput() or
     * needsDictionary() if more input data or a preset dictionary is needed to proceed with the decompression.
     *
     * @param output the buffer for the uncompressed data
     * @param outputOffset the start offset of the data
     * @param outputLen the maximum number of uncompressed bytes
     *
     * @return the actual number of uncompressed bytes
     *
     * @throws DataFormatException if the compressed data format is invalid
     * @throws NullPointerException - if an invalid argument is received
     * @throws ArrayIndexOutOfBoundsException - if the array index is less than the offset
     *
     * @see Inflater#needsInput
     * @see Inflater#needsDictionary
     */
    public synchronized int inflate(byte[] output, int outputOffset, int outputLen)
        throws DataFormatException {
        if (output == null) {
            throw new NullPointerException("output is null");
        }

        if ((outputOffset < 0) || ((outputOffset + outputLen) > output.length) || (outputLen < 0)) {
            throw new ArrayIndexOutOfBoundsException("outputOffset or outputLen invalid");
        }

        /*
         * The inflate function is implemented as a state machine to keep the number
         * of uncommitted bits below 24. See the documentation for 'state' to read more
         * about the machine
         */
        int remaingWhenStarted = decoder.getRemaining();
        int outputPos = outputOffset;
        int outputEnd = outputOffset + outputLen;

        try {
            while ((!this.finished) && (outputPos < outputEnd) && (!this.needDict)) {
                switch (state) {
                case STATE_FILE_HEADER:

                    int header = decoder.readBits(16);
                    decoder.commit();

                    // the header in big endian order
                    int headerBE = ((header >> 8) & 0xff) | ((header & 0xff) << 8);

                    if ((headerBE % 31) != 0) { // the checksum
                        throw new DataFormatException("header checksum invalid");
                    }

                    int fileMethod = header & 0xf;

                    if (fileMethod != 8) {
                        throw new DataFormatException("Unknown compressions method");
                    }

                    int windowSize = (header >> 4) & 0xf;

                    if (windowSize >= 8) {
                        throw new DataFormatException("Window size too large");
                    }

                    if ((header & 0x2000) != 0) {
                        state = STATE_READ_DICT_ID;
                        stateDictIdBytesRead = 0;
                    } else {
                        state = STATE_BLOCK_HEADER;
                    }

                    // the compression level is ignored
                    break;

                case STATE_READ_DICT_ID:

                    while (stateDictIdBytesRead < 4) {
                        // read and ignore the DICTID as there is no API to retrieve it
                        decoder.readBits(8);
                        decoder.commit();
                        stateDictIdBytesRead++;
                    }

                    needDict = true;
                    state = STATE_BLOCK_HEADER;

                //fall through
                case STATE_BLOCK_HEADER:

                    int isLast = decoder.readBit();
                    int method = decoder.readBits(2);
                    decoder.commit();
                    stateIsLastBlock = (isLast == 1);

                    switch (method) {
                    case DEFLATE_NO_COMPRESSION:
                        state = STATE_COPY_DATA_LEN;

                        break;

                    case DEFLATE_FIXED_HUFFMAN:
                        state = STATE_READ_CODE;
                        stateBlockFixedCodes = true;

                        break;

                    case DEFLATE_DYNAMIC_HUFFMAN:
                        state = STATE_DYN_HUFFMAN_HEADER;
                        stateBlockFixedCodes = false;

                        break;

                    default:
                        throw new DataFormatException("Invalid block compression type");
                    }

                    break;

                case STATE_COPY_DATA_LEN:
                    decoder.moveToByteBoundry();
                    decoder.commit();
                    stateUncompressedDataLength = decoder.readBits(16);
                    decoder.commit();
                    state = STATE_COPY_DATA_NLEN;

                // fall through
                case STATE_COPY_DATA_NLEN:

                    int nlen = decoder.readBits(16);
                    decoder.commit();

                    if (((~nlen) & 0xffff) != stateUncompressedDataLength) {
                        throw new DataFormatException("NLEN is not a complement of len");
                    }

                    state = STATE_COPY_DATA;

                // fall through
                case STATE_COPY_DATA:

                    while ((outputPos < outputEnd) && (stateUncompressedDataLength > 0)) {
                        byte code = (byte) decoder.readBits(8);
                        decoder.commit();
                        windowData[windowPos] = (byte) code;
                        windowPos = (windowPos + 1) & 0x7fff;
                        output[outputPos++] = (byte) code;
                        stateUncompressedDataLength--;
                    }

                    if (stateUncompressedDataLength == 0) {
                        if (stateIsLastBlock) {
                            this.finished = true;
                        } else {
                            state = STATE_BLOCK_HEADER;
                        }
                    }

                    break;

                case STATE_DYN_HUFFMAN_HEADER:
                    stateLiteralCodesCount = decoder.readBits(5) + 257;
                    stateDistanceCodesCount = decoder.readBits(5) + 1;
                    stateCodeLengthsCodesCount = decoder.readBits(4) + 4;
                    decoder.commit();
                    // prepare for the next state:
                    state = STATE_DYN_HUFFMAN_READ_CODE_LENGTHS;

                    for (int i = 0; i < stateBlockCodeLengths.length; i++)
                        stateBlockCodeLengths[i] = 0;

                    stateReadHuffmanCodeCounter = 0;

                // fall through
                case STATE_DYN_HUFFMAN_READ_CODE_LENGTHS:

                    while (stateCodeLengthsCodesCount > 0) {
                        int len = decoder.readBits(3);
                        decoder.commit();

                        int codeid = DEFLATE_HUFFMAN_CODE_LENGTHS_ORDER[stateReadHuffmanCodeCounter++];
                        stateBlockCodeLengths[codeid] = len;
                        stateCodeLengthsCodesCount--;
                    }

                    stateCodeLengthsHuffmanTree.buildTree(stateBlockCodeLengths);
                    // prepare for the next state:
                    state = STATE_DYN_HUFFMAN_READ_LITERAL_CODES;
                    stateReadHuffmanCodeCounter = 0;

                // fall through
                case STATE_DYN_HUFFMAN_READ_LITERAL_CODES:
                    readLengths(stateBlockLiteralCodes, stateLiteralCodesCount);
                    stateLiteralsHuffmanTree.buildTree(stateBlockLiteralCodes);

                    // prepare for next state:
                    state = STATE_DYN_HUFFMAN_READ_DISTANCE_CODES;
                    stateReadHuffmanCodeCounter = 0;

                // fall through
                case STATE_DYN_HUFFMAN_READ_DISTANCE_CODES:
                    readLengths(stateBlockDistanceCodes, stateDistanceCodesCount);
                    stateDistanceHuffmanTree.buildTree(stateBlockDistanceCodes);
                    state = STATE_READ_CODE;

                // fall through
                case STATE_READ_CODE:

                    while (outputPos < outputEnd) {
                        int code = readCode();

                        if (code > DEFLATE_LAST_CODE) {
                            throw new DataFormatException("Invalid code");
                        }

                        if (code >= DEFLATE_FIRST_LENGTH_CODE) {
                            int lengthCode = code - DEFLATE_FIRST_LENGTH_CODE;
                            int lengthBits = decoder.readBits(DEFLATE_LENGTH_EXTA_BITS[lengthCode]);
                            stateCopyLength = DEFLATE_LENGTH_BASE[lengthCode] + lengthBits;
                            decoder.commit();
                            state = STATE_READ_DIST;

                            break;
                        }

                        decoder.commit();

                        if (code == DEFLATE_EOB_CODE) {
                            if (stateIsLastBlock) {
                                this.finished = true;
                            } else {
                                state = STATE_BLOCK_HEADER;
                            }

                            break;
                        }

                        windowData[windowPos] = (byte) code;
                        windowPos = (windowPos + 1) & 0x7fff;
                        output[outputPos++] = (byte) code;
                    }

                    break;

                case STATE_READ_DIST:
                    stateCopyDistance = readDistance();
                    decoder.commit();
                    state = STATE_DIST_COPY;

                // fall through
                case STATE_DIST_COPY:

                    int copyFrom = (windowPos - stateCopyDistance + 32768) % 32768;

                    while ((stateCopyLength > 0) && (outputPos != outputEnd)) {
                        int code = windowData[copyFrom];
                        windowData[windowPos] = (byte) code;
                        windowPos = (windowPos + 1) & 0x7fff;
                        copyFrom = (copyFrom + 1) & 0x7fff;
                        stateCopyLength--;
                        output[outputPos++] = (byte) code;
                    }

                    if (stateCopyLength == 0) {
                        state = STATE_READ_CODE;
                    }

                    break;

                default:
                    throw new IllegalStateException("Invalid state " + state);
                }
            }
        } catch (DecoderNoMoreDataException e) {
            // no more data to decode - return from this function
        }

        totalOut += (outputPos - outputOffset);
        totalIn += (remaingWhenStarted - decoder.getRemaining());

        return outputPos - outputOffset;
    }

    /**
     * Uncompresses bytes into specified buffer <code>b</code>. Returns the actual
     * number of uncompressed bytes. After the return from this function you may check with needsInput() or
     * needsDictionary() if more input data or a preset dictionary is needed to proceed with the decompression.
     *
     * @param b the buffer for the uncompressed data
     *
     * @return the actual number of uncompressed bytes
     *
     * @throws DataFormatException if the compressed data format is invalid
     *
     * @see Inflater#needsInput
     * @see Inflater#needsDictionary
     */
    public int inflate(byte[] b) throws DataFormatException {
        return inflate(b, 0, b.length);
    }

    /**
     * Returns the total number of bytes input so far.
     *
     * @return the total number of bytes input so far
     */
    public synchronized int getTotalIn() {
        return totalIn;
    }

    /**
     * Returns the total number of bytes output so far.
     *
     * @return the total number of bytes output so far
     */
    public synchronized int getTotalOut() {
        return totalOut;
    }

    /**
     * Resets inflater so that a new set of input data can be processed.
     */
    public synchronized void reset() {
        finished = false;
        decoder.reset();
        totalIn = 0;
        totalOut = 0;
        windowPos = 0;

        if (noWrap) {
            state = STATE_BLOCK_HEADER;
        } else {
            state = STATE_FILE_HEADER;
        }
    }

    /**
     * Closes the decompressor and discards any unprocessed input. Once this method is
     * called, the behavior of the Inflater object is undefined.
     */
    public synchronized void end() {
        windowData = null; // free memory
    }
}
